// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {

  const wxContext = cloud.getWXContext()
  console.log("获取用户微信信息成功")
  console.log(wxContext)

  // 实例化数据库
  const db = cloud.database()
  switch (event.type) {
    case "get": {
      return getDDnote(db);
    }
    case "view": {
      return viewDDnote(db, wxContext, event);
    }
    case "add": {
      return addDDnote(db, wxContext, event);
    }
    case "edit": {
      return editDDnote(db, wxContext, event);
    }
    case "del": {
      return delDDnote(db, wxContext, event);
    }
    default: {
      return
    }
  }
}

async function getDDnote(db) {
  // 每次至多获取多少条记录，最大100
  const MAX_LIMIT = 3
  /** 查询集合中总共有多少条记录 start **/
  var countResult = await db.collection('ddnote').count();
  console.log(countResult);
  var total = countResult.total;
  console.log('总共多少条数据:' + total);
  /** 查询集合中总共有多少条记录 end **/
  /** 计算总共可以有多少页 start **/
  const total_times = Math.ceil(total / MAX_LIMIT);
  console.log('总共可以分多少页面：' + total_times);
  /** 计算总共可以有多少页 end **/
  // 定义一个数组变量接收查询结果
  var items = []
  // 定义一个数组变量接收查询结果
  var imagelist = []
  for (var i = 0; i < total_times; i++) {
    await db.collection('ddnote')
      .orderBy('update_time', 'desc')
      .skip(i * MAX_LIMIT)
      .get()
      .then(res => {
        console.log("第" + i + "页")
        console.log(res.data)
        items = items.concat(res.data)
        imagelist = imagelist.concat(res.data[i].picture_url)
      })
  }
  //将更新时间、性别格式转化
  for (var i = 0; i < items.length; i++) {
    var date = new Date(items[i].create_time)
    items[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(items[i].create_time)
    items[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    const countResult = await db.collection('like')
      .where({
        openid: items[i].openid,
        ddnote_id: items[i].id,
      })
      .count()
    items[i].thumb_count = countResult.total
  }

  console.log(imagelist)
  var result = {}
  result.errCode = 0
  result.errMsg = '获取同学录成功'
  var data = {}
  data.dd = items
  data.imagelist = imagelist
  result.data = data
  return result
}

async function editDDnote(db, wxContext, event) {
  /** 检测用户的openid start*/
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  var age = 0;
  /** 检测用户的openid end*/
  /** 更新学神录的数据 start**/
  await db.collection('ddnote')
    .where({
      id: event.id
    })
    .update({
      data: {
        // 昵称
        nickname: event.nickname,
        //是否隐藏真实姓名
        islock_realname: event.islock_realname,
        // 真实姓名
        realname: event.realname,
        // 是否隐藏出生日期
        islock_birthday: event.birthday,
        // birthday
        birthday: event.birthday,
        // 年龄
        age: age,
        // 地址
        address: event.address,
        // 访问密码
        password: event.password,
        // 座右铭
        motto: event.motto,
        // 性别，0表示男生，1表示女生，2表示其他
        gender: event.gender,
        // 个人简介
        introduction: event.introduction,
        // 致开发者的话
        message: event.message,
        // 一問一答
        Q_A: event.Q_A,
        // 发布者的图片存储地址
        picture_url: event.picture_url,
        // 更新时间
        update_time: new Date()
      }
    })
    .then(res => {
      console.log('更新成功')
      console.log(res)
    })
  /** 更新学神录的数据 end **/
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '同学录更新成功！'
  var data = {}
  result.data = data
  return result
}

async function addDDnote(db, wxContext, event) {
  /** 检测用户的openid start*/
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  // 检测是否传了参数 start
  if (event.message == null || event.birthday == null || event.nickname == null || event.gender == null || event.picture_url == null || event.realname == null) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未传必要参数，请重试'
    var data = {}
    result.data = data
    return result
    // 检测是否传了参数 end
  }
  var age = 0
  // 构造要添加的数据
  to_add_data = {
    id: event.id,
    // 昵称
    nickname: event.nickname,
    //是否隐藏真实姓名
    islock_realname: event.islock_realname,
    // 真实姓名
    realname: event.realname,
    // 是否隐藏出生日期
    islock_birthday: event.birthday,
    // birthday
    birthday: event.birthday,
    // 年龄
    age: age,
    // 地址
    address: event.address,
    // 访问密码
    password: event.password,
    // 座右铭
    motto: event.motto,
    // 性别，0表示男生，1表示女生，2表示其他
    gender: event.gender,
    // 个人简介
    introduction: event.introduction,
    // 致开发者的话
    message: event.message,
    // 发布者的图片存储地址
    picture_url: event.picture_url,
    Q_A: event.Q_A,
    //评论数量
    review_count: 0,
    //  点赞数量
    thumb_count: 0,
    // 浏览量
    eye_count: 0,
    // 发布者的openid
    openid: wxContext.OPENID,
    // isShow
    isShow: true,
    // 创建时间
    create_time: new Date(),
    // 更新时间
    update_time: new Date()
  }
  console.log("要新增的数据")
  console.log(to_add_data)


  // 新增结果
  var add_result = {}
  await db.collection('ddnote')
    .add({
      data: to_add_data
    })
    .then(res => {
      console.log('新增成功')
      console.log(res)
      add_result = res._id
    })

  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '同学录发布成功'
  var data = {}
  data.ddnote_id = add_result
  result.data = data
  return result
}

async function viewDDnote(db, wxContext, event) {
  /** 检测用户的openid start*/
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  /** 检测是否传入参数 start **/
  if (event.id == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/

  // 定义一个数组接收查询结果
  var items = []
  // 定义一个变量存储openid
  var openid;
  // 定义一个变量存储ddnote_id
  var ddnote_id;
  await db.collection('ddnote')
    .where({
      id: Number(event.id)
    })
    .get()
    .then(res => {
      console.log(res.data)
      items = res.data
      console.log(res.data[0].openid)
      openid = res.data[0].openid
      ddnote_id = res.data[0].id
    })
  const countResult = await db.collection('like')
    .where({
      ddnote_id: ddnote_id,
      is_like: true
    })
    .count()
  await db.collection('ddnote')
    .where({
      id: Number(event.id)
    })
    .update({
      data: {
        thumb_count: countResult.total
      }
    })
    .then(res => {
      console.log('新增浏览量')
      console.log(res)
    })
  /** 更新浏览量 start **/
  if (wxContext.OPENID != openid) {
    await db.collection('ddnote')
      .where({
        id: Number(event.id)
      })
      .update({
        data: {
          eye_count: items[0].eye_count + 1
        }
      })
      .then(res => {
        console.log('新增浏览量')
        console.log(res)
      })
  }
  /** 更新浏览量 end **/
  // 将更新时间、性别格式转化
  for (var i = 0; i < items.length; i++) {
    var date = new Date(items[i].update_time)
    items[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(items[i].create_time)
    items[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }

  var result = {}
  result.errCode = 0
  result.errMsg = '获取同学录成功'
  var data = {}
  data.dd = items
  result.data = data
  return result
}

async function delDDnote(db, wxContext, event) {
  /** 检测用户的openid start*/
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  /** 检测是否传入参数 start **/
  if (event.id == undefined || event.openid == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/
  if (wxContent.OPENID == event.openid) {
    await db.collection('ddnote')
      .where({
        id: event.id
      })
      .update({
        data: {
          // 昵称
          isShow: false,
        }
      })
      .then(res => {
        console.log('删除成功')
        console.log(res)
      })
  }
  var result = {}
  result.errCode = 0
  result.errMsg = '删除同学录成功'
  var data = {}
  data.dd = items
  result.data = data
  return result
}