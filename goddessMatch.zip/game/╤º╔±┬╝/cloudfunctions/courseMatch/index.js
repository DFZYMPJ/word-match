// 云函数入口文件
const cloud = require('wx-server-sdk')

//云开发初始化
cloud.init();

//将云开发数据库能力声明给db
const db = cloud.database();

//将云开发数据库command能力声明给 _
const _ = db.command;

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  switch (event.type) {
    case "init": {
      return initCourseMatch(db, event, wxContext, _)
    }
    case "add": {
      return addCourse(db, event, wxContext, _)
    }
    case "remove": {
      return removeCourse(db, event, wxContext, _)
    }
    case "join": {
      return joinCourse(db, event, wxContext, _)
    }
    case "find": {
      return findCourse(db, event, wxContext, _)
    }
    case "match": {
      return Match(db, event, wxContext)
    }
    default: {
      return
    }
  }
}
/**
 * 云函数：初始化课程搭配
 * 用途：根据用户的唯一openid构建数据库文档，用于存储用户的信息；每次调用时都要返回存储的信息。
 */
async function initCourseMatch(db, event, wxContext, _) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  /** 检测是否传入参数 start **/
  if (event.longtitude == undefined || event.latitude == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/
  //声明一个result，用于承载函数执行结果用于返回
  var result = {};
  // 返回执行结果的数据
  var data = {};
  try {

    //利用数据库where查找，数据集中openid为用户所属的文档
    const userdata = (await db.collection('courseMatch').where({
      openid: wxContext.OPENID
    }).get()).data;

    //如果length不等于0，则证明存在用户所属文档
    if (userdata.length != 0) {
      console.log(userdata)
      //将文档id取出，用于小程序端上传图片时的文件夹命名。由于安全性，不可以将openid传给小程序端
      data.id = userdata[0]._id;
      //正常标志errCode=0
      result.errCode = 0;
      // 返回执行结果的数据
      result.data = data

      result.errMsg = '初始化完成';
    }
    //如果length等于0，则没有用户文档需要创建
    else {
      //使用数据库add增加，根据data传入的JSON对象进行构建，返回的为构建的信息，包含文档id
      let userdata = await db.collection('courseMatch').add({
        data: {
          openid: wxContext.OPENID,
          course: [],
          match: [],
          location: db.Geo.Point(event.longtitude, event.latitude),
          create_time: new Date(),
          update_time: new Date()
        }
      });
      console.log(userdata[0])
      //将文档id取出
      data.id = userdata[0]._id;
      //正常标志errCode=0
      result.errCode = 0;
      // 结果的数据data
      result.data = data
      // 执行返回消息
      result.errMsg = '初始化完成';
    }
  } catch (e) {
    //当发生错误时，如解构FileID等，将执行此代码段，errCode=-1为异常
    console.log(e);
    result.errCode = -1;
    result.errMsg = e;
  }
  //返回result给前端
  return result;
}

/**
 * 云函数：添加课程信息
 * 用途：课程信息上传云数据库进行保存。
 */
async function addCourse(db, event, wxContext, _) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  /** 检测是否传入参数 start **/
  if (event.cover == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/

  //声明一个result，用于承载函数执行结果用于返回
  var result = {};
  //声明一个data,用于承载数据库执行结果用于返回
  var data = {};

  // 构建新增的数据
  var Lesson = {
    // 课程ID
    id: Number(event.id),
    // 课程封面
    cover: event.cover,
    // 课程价格
    price: Number(event.price),
    // 课程的问答
    Q_A: event.Q_A,
    // 课程
    name: event.name,
    // 学生列表
    student: []
  }
  console.log("要新增的数据")
  console.log(Lesson)

  try {
    if (event.longtitude == undefined) {
      var userdata = await db.collection('courseMatch').where({
        openid: wxContext.OPENID
      }).update({
        data: {
          course: _.unshift([Lesson]),
          update_time: new Date()
        }
      });
    } else {
      var userdata = await db.collection('courseMatch').where({
        openid: wxContext.OPENID
      }).update({
        data: {
          course: _.unshift([Lesson]),
          location: db.Geo.Point(event.longtitude, event.latitude),
          update_time: new Date()
        }
      });
    }
    // 新增结果
    console.log('新增成功')
    const res = userdata
    data.update = res.stats.updated
    // 返回执行结果
    result.data = data
    result.errMsg = event.name + '添加成功'
    result.errCode = 0;

  } catch (e) {
    //当发生错误时，如解构FileID等，将执行此代码段，errCode=-1为异常
    console.log(e);
    // 返回执行结果
    result.errCode = -1;
    result.errMsg = e;
  }
  //返回result给前端
  return result;
}

/**
 * 云函数: 删除课程信息
 * 用途：根据图片地址，将云数据库保存的识别图片进行删除。
 */
async function removeCourse(db, event, wxContext, _) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  /** 检测是否传入参数 start **/
  if (event.cover == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/

  //声明一个result，用于承载函数执行结果用于返回
  var result = {};
  // 声明一个data，用于承载数据库执行结果用于返回
  var data = {}
  try {
    /*【开始】=====================【代码实战位置C-3】=====================【开始】*/

    //利用数据库where查找，数据集中openid为用户所属的文档，然后使用update进行更新操作
    const userdata = await db.collection('courseMatch').where({
      openid: wxContext.OPENID
    }).update({
      data: {
        //_.pull为command能力，含义为将数组中src为event.img的元素删除
        course: _.pull({
          cover: event.cover
        })
      }
    }).then(res => {
      console.log('删除课程成功')
      data.wordcard_id = res._id
    });
    //使用云存储能力，根据列表的fileid地址删除文件
    await cloud.deleteFile({
      fileList: [event.cover]
    })

    /*【结束】=====================【代码实战位置C-3】=====================【结束】*/
    // 返回执行结果
    result.data = data
    //在处理完全后，返回自定义的errCode码，表示一定的逻辑含义；在这里errCode=0为正常成功
    result.errCode = 0;
    result.errMsg = '课程删除成功'
  } catch (e) {
    //当发生错误时，如解构FileID等，将执行此代码段，errCode=-1为异常
    console.log(e);
    result.errCode = -1;
    result.errMsg = e;
  }
  //返回result给前端
  return result;
}

/**
 * 云函数: 获取课程搭配
 * 用途：根据用户的唯一openid查询数据库文档
 */

async function Match(db, event, wxContext, _) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  /** 检测是否传入参数 start **/
  if (event.id != undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/

  //声明一个result，用于承载函数执行结果用于返回
  var result = {};
  // 声明一个data，用于承载数据库执行结果用于返回
  var data = {}

  try {
    /*【开始】=====================【代码实战位置C-2】=====================【开始】*/
    //利用数据库where查找，数据集中openid为用户所属的文档
    const userdata = (await db.collection('courseMatch').where({
      openid: wxContext.OPENID
    }).get()).data;
    //如果length不等于0，则证明存在用户所属文档
    if (userdata.length != 0) {
      // 声明一个match数组
      var match = userdata[0].match
      console.log(match)
      var doc = []
      var course = []
      var table = []
      for (var i = 0; i < match.length; i++) {
        doc = doc.concat([match[i].id])
        console.log(match[i].id)
        course = course.concat([match[i].course_id])
        console.log(doc)
        console.log(course)
        for (var j = 0; j < doc.length; j++) {
          var coursedata = (await db.collection('courseMatch').doc(doc[i]).get()).data;
          for (var k = 0; k < coursedata.course.length; k++) {
            if (coursedata.course[k].id == course[i]) {
              table = table.concat(coursedata.course[k])
              console.log('查询我的课程')
            }
          }
        }
      }
      //将用户的课程表读取出来
      data.table = table;
      //将文档id取出，用于小程序端上传图片时的文件夹命名。由于安全性，不可以将openid传给小程序端
      data.doc = doc;
    }
    //如果length等于0，则没有用户文档需要创建
    else {
      //将用户的识别列表读取出来
      data.table = [];
      //将文档id取出，用于小程序端上传图片时的文件夹命名。由于安全性，不可以将openid传给小程序端
      // data.doc = doc;
    }
    /*【结束】=====================【代码实战位置C-2】=====================【结束】*/
    result.data = data
    //在处理完全后，返回自定义的errCode码，表示一定的逻辑含义；在这里errCode=0为正常成功
    result.errCode = 0;
    result.errMsg = '获取课程表成功'
  } catch (e) {
    //当发生错误时，如解构FileID等，将执行此代码段，errCode=-1为异常
    console.log(e);
    result.errCode = -1;
    result.errMsg = e;
  }
  //返回result给前端
  return result;
}

/**
 * 云函数: 查找附近课程
 * 用途：根据用户的非唯一location查询数据库文档
 */
async function findCourse(db, event, wxContext, _) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  /** 检测是否传入参数 start **/
  if (event.longtitude == undefined || event.latitude == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/
  //声明一个result，用于承载函数执行结果用于返回
  var result = {};
  // 声明一个data，用于承载数据库执行结果用于返回
  var data = {}

  try {
    /*【开始】=====================【代码实战位置C-2】=====================【开始】*/
    //利用数据库where查找，数据集中openid为用户所属的文档
    const userdata = (await db.collection('courseMatch').where({
      location: _.geoNear({
        geometry: db.Geo.Point(event.longtitude, event.latitude),
        minDistance: 0,
        maxDistance: 5000,
      })
    }).get()).data;
    console.log(userdata)
    //如果length不等于0，则证明存在用户所属文档
    if (userdata.length != 0) {
      // 声明一个lesson变量
      var lesson = []
      var _id = []
      for (var i = 0; userdata.length > i; i++) {
        _id = _id.concat(userdata[i]._id)
        lesson = lesson.concat(userdata[i].course[0])
      }
      //将用户的课程列表读取出来
      data.lesson = lesson;
      data._id = _id;
    }
    //如果length等于0，则没有用户文档需要创建
    else {
      //将用户的识别列表设置为空
      data.lesson = [];
      data._id = [];
    }
    /*【结束】=====================【代码实战位置C-2】=====================【结束】*/
    result.data = data
    //在处理完全后，返回自定义的errCode码，表示一定的逻辑含义；在这里errCode=0为正常成功
    result.errCode = 0;
    result.errMsg = '匹配附近的课程成功'
  } catch (e) {
    //当发生错误时，如解构FileID等，将执行此代码段，errCode=-1为异常
    console.log(e);
    result.errCode = -1;
    result.errMsg = e;
  }
  //返回result给前端
  return result;
}

/**
 * 云函数: 加入课程
 * 用途：根据用户的唯一openid查询数据库文档,用户_id写入云数据库进行保存。
 */

async function joinCourse(db, event, wxContext, _) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  /** 检测是否传入参数 start **/
  if (event.id == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/

  //声明一个result，用于承载函数执行结果用于返回
  var result = {};
  //声明一个data,用于承载数据库执行结果用于返回
  var data = {};

  try {
    // 声明一个变量_id
    var _id

    const person = (await db.collection('courseMatch').where({
      openid: wxContext.OPENID
    }).get()).data;
    _id = person[0]._id
    //利用数据库where查找，数据集中id为用户所属的文档
    const userdata = (await db.collection('courseMatch').doc(event.id).get()).data;
    var course = []
    for (var i = 0; userdata.course.length > i; i++) {
      if (userdata.course[i].id == event.course_id) {
        userdata.course[i].student = userdata.course[i].student.concat([_id])
        console.log(userdata.course[i])
      }
      course = course.concat(userdata.course[i])
    }

    await db.collection('courseMatch').where({
      openid: wxContext.OPENID
    }).update({
      data: {
        course: course,
        match: _.unshift([{
          id: event.id,
          course_id: event.course_id
        }])
      }
    }).then(res => {
      console.log('加入成功')
      // 新增结果
      data.user_id = res._id
    });
    // 返回执行结果
    result.data = data
    result.errMsg = '加入课程成功'
    result.errCode = 0;

  } catch (e) {
    //当发生错误时，如解构FileID等，将执行此代码段，errCode=-1为异常
    console.log(e);
    // 返回执行结果
    result.errCode = -1;
    result.errMsg = e;
  }
  //返回result给前端
  return result;

}