module.exports = {
  AppId: '1305561666',
  SecretId: 'AKIDvf8LIxMUM0NTJsAC6j48vRgeKktlLfiU',
  SecretKey: 'jCPKyLRGn32kBLDpBH7h01lEQLzLRGo5'
};
//注意：此处的密钥信息属于展示专用，在项目结束后即失效，请不要盗用，谢谢配合！