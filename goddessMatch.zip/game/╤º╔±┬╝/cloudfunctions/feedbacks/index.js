// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  /** 检测用户的openid start*/
  const wxContext = cloud.getWXContext()
  console.log("获取用户微信信息成功")
  console.log(wxContext)
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  // 实例化数据库
  const db = cloud.database()

  switch (event.name) {
    case "get": {
      return getFeedbacks(db, wxContext);
    }
    case "remove": {
      return removeFeedbacks(db, wxContext, event);
    }
    case "add": {
      return addFeedbacks(db, wxContext, event);
    }
    default: {
      return
    }
  }


}

async function getFeedbacks(db, wxContext) {
  /** 校验用户权限，只有管理员才能调用该接口 start **/
  var user;
  await db.collection('user')
    .where({
      openid: wxContext.OPENID
    })
    .get()
    .then(res => {
      console.log('获取用户信息操作成功')
      console.log(res.data)
      user = res.data
    })
  // 判断用户的is_admin是否等0
  if (user.is_admin == 0) {
    var result = {}
    result.errCode = 1
    result.errMsg = '无权限访问，需要管理权限才能获取所有反馈'

    var data = {}
    result.data = data
    return result
  }
  /** 校验用户权限，只有管理员才能调用该接口 end **/

  // 每次至多获取多少记录，最大100
  const MAX_LIMIT = 2

  /** 查询集合中总共多少条记录 start **/
  const countResult = await db.collection('feedback').count()
  const total = countResult.total
  console.log('总共有多少条数据')
  console.log(total)
  /** 查询集合中总共多少条记录 end **/
  /** 计算总共可以为多少页 start */
  const total_times = Math.ceil(total / MAX_LIMIT)
  console.log('总共可以分多少页面')
  console.log(total_times)
  /** 计算总共可以为多少页 end */
  // 保存每次查询的结果
  var items = [];

  for (let i = 0; i < total_times; i++) {
    await db.collection('feedback')
      .orderBy('create_time', 'desc')
      .skip(i * MAX_LIMIT)
      .get()
      .then(res => {
        console.log('第' + i + '页')
        console.log(res.data)
        items = items.concat(res.data)
      })
  }
  console.log(items.length)
  // 将时间格式转换
  for (let i = 0; i < items.length; i++) {
    var date = new Date(items[i].create_time);
    items[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  console.log(items)
  var result = {}
  result.errCode = 0
  result.errMsg = '获取所有反馈成功'
  var data = {}
  data.feedbacks = items
  result.data = data
  return result
}

async function removeFeedbacks(db, wxContext, event) {
  var user;
  await db.collection('user')
    .where({
      openid: wxContext.OPENID
    })
    .get()
    .then(res => {
      console.log('获取用户信息操作成功')
      console.log(res.data)
      user = res.data
    })
  /** 检验管理权限 start **/
  if (user.is_admin == 0) {
    // 返回执行结果
    var result = {}
    result.errCOde = 2
    result.errMsg = '不具备管理权限'
    var data = {}
    result.data = data
    return result
  }
  /** 检验管理权限  end **/

  // 保存删除了多少条数据
  var total_remove = 0

  await db.collection('feedback')
    .where({
      _id: event.feedback_id
    })
    .remove()
    .then(res => {
      console.log('删除操作成功')
      console.log(res)
      total_remove = res.status
    })
  // 删除该反馈对应的图片TODO
  var result = {}
  if (total_remove.removed == 0) {
    result.errCOde = 3
    result.errMsg = '不存在该反馈'
  } else {
    result.errCode = 0
    result.errMsg = '删除成功'
  }
  var data = {}
  result.data = data
  return result
}

async function sendSubscribeMessage(event, username, content, time) {
  const {
    OPENID
  } = cloud.getWXContext()

  const {
    templateId
  } = event

  const sendResult = await cloud.openapi.subscribeMessage.send({
    touser: OPENID,
    templateId,
    miniprogram_state: 'formal', //跳转小程序类型：developer为开发版；trial为体验版；formal为正式版。
    page: 'pages/feedback/feedback',
    // 此处字段应修改为所申请模板所要求的字段
    data: {
      thing1: {
        value: username,
      },
      thing2: {
        value: content
      },
      time3: {
        value: time
      }
    }
  })

  return sendResult
}

async function addFeedbacks(db, wxContext, event) {

  // 检测是否传了参数 start
  if (event.content == undefined) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未传必要参数，请重试'
    var data = {}
    result.data = data
    return result
    // 检测是否传了参数 end
  }
  // 构造要添加的数据
  to_add_data = {
    // 内容
    content: event.content,
    // 用户的微信号
    wechat_account: event.wechat_account,
    // 邮箱
    email: event.email,
    // 类型，1表示增加词语，2表示加入我们，3商务合作，4其他，5反馈bug
    type: event.type,
    // 反馈的图片存储地址
    picture_url: event.picture_url,
    // 反馈者的openid
    openid: wxContext.OPENID,
    // 创建时间
    create_time: new Date()
  }
  console.log("要新增的数据")
  console.log(to_add_data)

  // 新增结果
  var add_result = {}
  await db.collection('feedback')
    .add({
      data: to_add_data
    })
    .then(res => {
      console.log('新增成功')
      console.log(res)
      add_result = res._id
    })
  /** 给当前用户发送微信订阅消息 start **/
  var openid = wxContext.OPENID
  var username = event.nickName
  var content2 = "管理员已经收到你的反馈，谢谢!"
  var date = new Date()

  var data = {}
  // 格式化创建时间为 2021.5.22 13:10
  var time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes()
  try {
    var mes_result = await sendSubscribeMessage(event, username, content2, time)
  } catch (e) {
    data['user_notice_msg'] = '发送消息失败'
    data['user_notice_error_tip'] = e
  }
  /** 给当前用户发送微信订阅消息 end **/

  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '反馈成功'

  data.feedback_id = add_result
  result.data = data
  return result
}