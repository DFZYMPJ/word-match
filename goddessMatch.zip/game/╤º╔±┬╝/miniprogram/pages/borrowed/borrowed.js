// pages/borrowed/borrowed.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show: true,
    loading: false,
    booklist: [{
      tags: ['小王子', '童書'],
      price: 20,
      isbn: 9787544786089,
      title: "小王子的星辰与玫瑰",
      author: "斯泰西.希夫",
      book_count: 1,
      origin_price: '105元',
      cover_url: "https://img2.doubanio.com/view/subject/l/public/s33885571.jpg"
    }, {
      tags: ['小王子', '童書'],
      price: 20,
      isbn: 9787521730340,
      title: "我们星球上的生命",
      author: " [英",
      book_count: 1,
      origin_price: '65元',
      cover_url: "https://img1.doubanio.com/view/subject/l/public/s33893008.jpg"
    }],
    borrowed_booklist: [{

    }],
    total: 20,

  },
  onClose() {
    this.setData({
      show: false
    });
  },
  borrowed: function (e) {

  },
  onChange(e) {
    this.setData({
      value: e.detail,
    });
  },

  onSearch() {
    Toast('搜索' + this.data.value);
  },

  onClick() {
    Toast('搜索' + this.data.value);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})