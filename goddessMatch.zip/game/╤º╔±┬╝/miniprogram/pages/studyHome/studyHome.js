// pages/studyHome/studyHome.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    total: 100,
    hot_words: [{
      word: 'Ok',
      hot: 10,
    }, {
      word: 'Ok',
      hot: 10,
    }, {
      word: 'Ok',
      hot: 10,
    }, {
      word: 'Ok',
      hot: 10,
    }, {
      word: 'Ok',
      hot: 10,
    }, {
      word: 'Ok',
      hot: 10,
    },]
  },
  WordCard: function () {
    wx.navigateTo({
      url: '/pages/studyCardView/studyCardView',
    })
  },

  WordList: function () {
    wx.navigateTo({
      url: '/pages/wordList/wordList',
    })
  },
  getHotWords: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'get_words',
      data: {
        type: 'en_hot',
        lesson: wx.getStorageSync('lesson')
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            hot_words: res.result.data.hot_words
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [get_words] 调用失败', err)
        // wx.navigateTo({
        //   url: '../deployFunctions/deployFunctions',
        // })
      }
    })
  },

  getEnWordTotal: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'get_words',
      data: {
        type: 'en_total',
        lesson: wx.getStorageSync('lesson')
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            total: res.result.data.total
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [get_words] 调用失败', err)
        // wx.navigateTo({
        //   url: '../deployFunctions/deployFunctions',
        // })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getHotWords()
    this.getEnWordTotal()
    wx.setNavigationBarTitle({
      title: wx.getStorageSync('name'),
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})