// pages/ranklist/ranklist.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    gender: 'female',
    ranklist: [],
    imagelist: [],
    type: 'cast'
  },

  preview: function (e) {
    var image = e.currentTarget.dataset.image
    var that = this
    wx.previewImage({
      current: image,
      urls: that.data.imagelist,
    })
  },

  cast: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'eol',
      data: {
        type: 'rank',
        gender: that.data.gender
      },
      success: res => {
        if (res.result.errCode == 0) {
          console.log("获取排行数据成功")
          wx.showToast({
            title: '请耐心等待',
            icon: 'loading',
            duration: 2000,
            mask: true
          })
          console.log(res.result.data.cast)
          that.setData({
            ranklist: res.result.data.cast,
            imagelist: res.result.data.list
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [eol] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {
        setTimeout(() => {
          wx.hideToast()
        }, 2000);
      }
    })
  },

  roles: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'faceMash',
      data: {
        type: 'rank',
        gender: that.data.gender
      },
      success: res => {
        if (res.result.errCode == 0) {
          wx.showToast({
            title: '请耐心等待',
            icon: "loading",
            duration: 2000,
            mask: true
          })
          console.log("获取排行数据成功")
          console.log(res.result.data.roles)
          that.setData({
            ranklist: res.result.data.roles,
            imagelist: res.result.data.list
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [faceMash] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {
        setTimeout(() => {
          wx.hideToast()
        }, 2000);
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.ranklist == 'roles') {
      this.roles()
      this.setData({
        type: 'roles'
      })
    } else {
      this.cast()
      this.setData({
        type: 'cast'
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    if (this.data.gender == 'male') {
      this.setData({
        gender: 'female'
      })
    } else {
      this.setData({
        gender: 'male'
      })
    }
    if (this.data.type == 'roles') {
      this.roles()
    } else {
      this.cast()
    }
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})