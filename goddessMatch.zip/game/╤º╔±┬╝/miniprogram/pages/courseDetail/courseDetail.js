// pages/courseDetail/courseDetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: '',
    course_id: 0,
    course_cover: '',
    course_name: '',
    price: 0,
    user_list: [{
      _id: '2121',
      avatar: '../../images/0.jpg',
      name: '张运鹏',
      number: '201850130636'
    }, {
      _id: '2121',
      avatar: '../../images/0.jpg',
      name: '张运鹏',
      number: '201850130636'
    }, {
      _id: '2121',
      avatar: '../../images/0.jpg',
      name: '张运鹏',
      number: '201850130636'
    }],
    course_QA: [{
      question: '采用云开发有什么优势？',
      answer: '使用云开发非常方便，借助云数据库可以进行存储json数据,以及云存储和云函数等。'
    }]
  },
  chooseCourse: function () {
    this.joinCourse(() => {}, this.data.id, this.data.course_id)
  },

  joinCourse: function (succ, id, course_id) {
    wx.cloud.callFunction({
      name: 'courseMatch',
      data: {
        type: 'join',
        id: id,
        course_id: course_id
      }
    }).then(res => {
      console.log(res)
      if (res.result.errCode == 0) {
        wx.showToast({
          title: '課程加入成功',
        })
        setTimeout(() => {
          wx.hideToast({
            success: (res) => {},
          })
        }, 2000);
      }

      succ()
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    that.setData({
      id: options.id
    })
    const eventChannel = this.getOpenerEventChannel()
    // 监听courseMatch事件，获取上一页面通过eventChannel传送到当前页面的数据
    eventChannel.on('courseMatch', function (data) {
      console.log(data)
      that.setData({
        course_cover: data.cover,
        course_name: data.name,
        course_QA: data.Q_A,
        price: data.price,
        course_id: data.id
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})