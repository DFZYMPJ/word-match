// pages/myBook/myBook.js
import Notify from '../../vant/notify/notify';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isbn: 0,
    loading: true,
    value: '',
    myBook_list: [{}, {}, {}, {}, {}, {}, {}, {}],
    search_empty: false
  },
  onOpen(event) {
    const {
      position,
      name
    } = event.detail;
    switch (position) {
      case 'left':
        Notify({
          type: 'primary',
          message: `${name}${position}部分展示open事件被触发`,
        });
        break;
      case 'right':
        Notify({
          type: 'primary',
          message: `${name}${position}部分展示open事件被触发`,
        });
        break;
    }
  },

  scanCode: function (event) {

    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      wx.showModal({
        title: '提醒',
        content: '請先登陸~',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.scanCode({
        onlyFromCamera: false,
        scanType: ['barCode', 'qrCode', 'datamatrix', 'pdf417'],
        success: res => {
          console.log(res.result)
          wx.vibrateShort({
            type: "heavy",
            success: res => {
              conosle.log('開始震動')
            },
            fail: err => {

            }
          })
          console.log(res.scanType)
          if (res.result.length == 8 || res.result.length == 13) {
            wx.setStorageSync('isbn', res.result)
            wx.cloud.callFunction({
              name: 'book',
              data: {
                type: 'add',
                isbn: res.result
              },
              success: res => {
                wx.showLoading({
                  title: '請耐心等待...',
                })
                if (res.result.errCode == 0) {
                  setTimeout(() => {
                    wx.showLoading({
                      title: '上传中...',
                    })
                    wx.navigateTo({
                      url: '/pages/bookEdit/bookEdit?type=join&isbn=' + wx.getStorageSync('isbn'),
                    })
                  }, 10000)
                } else {
                  wx.showModal({
                    title: '提醒',
                    content: res.result.errMsg,
                    confirmText: "我知道了",
                    showCancel: false,
                    success(res) {
                      if (res.confirm) {
                        console.log('用户点击确定')
                      } else if (res.cancel) {
                        console.log('用户点击取消')
                      }
                    }
                  })
                }
              },
              fail: err => {
                console.error('[云函数] [bookinfo] 调用失败', err)
                wx.navigateTo({
                  url: '../deployFunctions/deployFunctions',
                })
              },
              complete: res => {
                setTimeout(() => {
                  wx.hideLoading({
                    success: (res) => {},
                  })
                }, 10000);
              }
            })
          }
        },
        fail: err => {
          console.log(err)
        }
      })
    }

  },

  onChange(e) {
    this.setData({
      value: e.detail,
    });
  },

  onClick() {
    var that = this
    that.setData({
      search_empty: true
    })
    if (that.data.value != '') {
      // 调用云函数
      wx.cloud.callFunction({
        name: 'book',
        data: {
          type: 'query',
          query_word: that.data.value
        },
        success: res => {
          wx.showToast({
            title: ' 搜索中...',
          })
          if (res.result.errCode == 0) {
            that.setData({
              myBook_list: res.result.data.myBook_list
            })
          } else {
            wx.showModal({
              title: '提醒',
              content: res.result.errMsg,
              confirmText: "我知道了",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }
        },
        fail: err => {
          console.error('[云函数] [book] 调用失败', err)
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions',
          })
        },
        complete: res => {
          setTimeout(() => {
            wx.hideToast({})
          }, 2000)
        }
      })
    } else {
      that.myBook()
    }
  },

  myBook: function () {
    var that = this
    that.setData({
      search_empty: false
    })
    // 调用云函数
    wx.cloud.callFunction({
      name: 'book',
      data: {
        type: 'get'
      },
      success: res => {
        wx.showLoading({
          title: '請耐心等待',
        })
        if (res.result.errCode == 0) {
          that.setData({
            myBook_list: res.result.data.myBook_list
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [book] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {
        setTimeout(() => {
          wx.hideLoading({
            success: (res) => {},
          })
        }, 2000);
      }
    })
  },

  bookDetail: function (event) {
    wx.navigateTo({
      url: '/pages/bookDetail/bookDetail?isbn=' + event.currentTarget.dataset.isbn,
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.myBook()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    setTimeout(() => {
      this.setData({
        loading: false
      })
    }, 5000)
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.myBook()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})