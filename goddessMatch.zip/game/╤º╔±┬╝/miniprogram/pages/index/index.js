// pages/index/index.js
// 引入条形码、二维码生成工具
import {
  toBarcode,
  toQrcode
} from '../../utils/utils';
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ISBN: 0,
    show: false,
    code: String(2123), // 转换成条形码、二维码的数字、字符串
    showQrcode: true,
    showPopup: false,
    fileID: null,
  },

  toggle(type) {
    this.setData({
      [type]: !this.data[type],
    });
  },

  toggleActionSheet() {
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      wx.showModal({
        title: '提醒',
        content: '請先登陸~',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      var that = this
      wx.showActionSheet({
        itemList: ['扫码加书', 'AI名片识别'],
        success(res) {
          console.log(res.tapIndex)
          if (res.tapIndex == 0) {
            that.scanCode()
          } else {
            that.uploadCard()
          }
        },
        fail(res) {
          console.log(res.errMsg)
        }
      })
    }
  },

  Transition: function () {
    this.setData({
      show: true
    })
  },

  uploadCard: function () {
    var that = this
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      wx.showModal({
        title: '提醒',
        content: '請先登陸~',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.chooseImage({
        success: function (dRes) {
          wx.showLoading({
            title: '上传文件',
          })
          let cloudPath = `list/${app.globalData.id}/${Date.now()}-${Math.floor(Math.random(0, 1) * 1000)}.png`;

          /*【开始】=====================【代码实战位置A-1】=====================【开始】*/
          console.log(dRes.tempFilePaths[0])
          wx.cloud.uploadFile({
            cloudPath,
            filePath: dRes.tempFilePaths[0],
          }).then(res => {
            if (res.statusCode < 300) {

              that.setData({
                fileID: res.fileID
              },
                () => {
                  that.scanCard()
                })
            }
          }).catch(err => {
            console.log(err)
            wx.hideLoading()
            wx.showToast({
              title: '上传失败',
              icon: 'none'
            })
          })
          /*【结束】=====================【代码实战位置A-1】=====================【结束】*/
        },
        fail: err => {
          console.error('上傳失敗：', err)
        }
      })
    }
  },

  scanCard: function () {
    wx.navigateTo({
      url: '/pages/card/index?fileID=' + this.data.fileID,
    })
  },

  scanCode: function (event) {
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      wx.showModal({
        title: '提醒',
        content: '請先登陸~',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.scanCode({
        onlyFromCamera: false,
        scanType: ['barCode', 'qrCode', 'datamatrix', 'pdf417'],
        success: res => {
          console.log(res.result)
          wx.vibrateShort({
            type: "heavy",
            success: res => {
              console.log('開始震動')
            },
            fail: err => {

            }
          })
          console.log(res.scanType)
          if (res.result.length == 8 || res.result.length == 13) {
            wx.setStorageSync('isbn', res.result)
            wx.cloud.callFunction({
              name: 'book',
              data: {
                type: 'add',
                isbn: res.result
              },
              success: res => {
                wx.showLoading({
                  title: '請耐心等待...',
                })
                if (res.result.errCode == 0) {
                  setTimeout(() => {
                    wx.showLoading({
                      title: '上传中...',
                    })
                    wx.navigateTo({
                      url: '/pages/bookEdit/bookEdit?type=join&isbn=' + wx.getStorageSync('isbn'),
                    })
                  }, 10000)
                } else {
                  wx.showModal({
                    title: '提醒',
                    content: res.result.errMsg,
                    confirmText: "我知道了",
                    showCancel: false,
                    success(res) {
                      if (res.confirm) {
                        console.log('用户点击确定')
                      } else if (res.cancel) {
                        console.log('用户点击取消')
                      }
                    }
                  })
                }
              },
              fail: err => {
                console.error('[云函数] [bookinfo] 调用失败', err)
                wx.navigateTo({
                  url: '../deployFunctions/deployFunctions',
                })
              },
              complete: res => {
                setTimeout(() => {
                  wx.hideLoading({
                    success: (res) => { },
                  })
                }, 10000);
              }
            })
          }
        },
        fail: err => {
          console.log(err)
        }
      })
    }

  },

  togglePopup: function () {
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      wx.showModal({
        title: '提醒',
        content: '請先登陸~',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      this.toggle('showPopup');
    }
  },

  myCard: function () {
    wx.navigateTo({
      url: '/pages/cardList/list',
    })
  },

  myBook: function () {
    wx.navigateTo({
      url: '/pages/myBook/myBook',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) { },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // toBarcode('barcode', this.data.code, 200, 80);
    toQrcode('qrcode', this.data.code, 200, 200);
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})