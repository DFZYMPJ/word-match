// pages/customer_service.js
// 获取应用实例
const app = getApp()
var plugin = requirePlugin("chatbot");
Page({

  /**
   * 页面的初始数据
   */
  onLoad: function () {
    plugin.setWelcome("举头望明月，低头思第一。")
    wx.getSystemInfo({
      success: (res) => {
        let isIOS = res.system.indexOf('iOS') > -1
        let navHeight = 0
        if (!isIOS) {
          navHeight = 48
        } else {
          navHeight = 44
        }
        this.setData({
          status: res.statusBarHeight,
          navHeight: navHeight,
          statusBarHeight: res.statusBarHeight + navHeight
        })
      }
    })
  },
  openMiniProgram(e) {
    let { appid, pagepath } = e.detail
    if (appid) {
      wx.navigateToMiniProgram({
        appId: appid,
        path: pagepath,
        extraData: {},
        envVersion: "",
        success(res) {
          // 打开成功
        }
      });
    } else {
      wx.navigateTo({
        url: pagepath,
        fail() {
          wx.switchTab({
            url: pagepath
          });
        }
      });
    }
  },
  getQueryCallback: function (e) {

  },
  openWebview: function (e) {
    let url = e.detail.weburl
    wx.navigateTo({
      url: `/pages/webviewPage/webviewPage?url=${url}`
    })
  },
  getQueryCallback: function (e) {

  },
  goBackHome: function () {
    wx.navigateBack({
      delta: 1
    })
  },
  back: function (e) {
    this.goBackHome()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})