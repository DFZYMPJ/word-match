// pages/addCourse/addCourse.js
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    courseMatchID: app.globalData.courseMatchID,
    Q_A: [{
      question: '',
      answer: ''
    }],
    course_name: '',
    price: 0,
    location_name: '我的位置',
    longtitude: app.globalData.location.longtitude,
    latitude: app.gloabalData.location.latitude,
    isShowPic: false,
    fileID: '',
    click:0
  },
  bindKeyInputCourseName: function (e) {
    this.setData({
      course_name: e.detail.value
    })
    console.log(e.detail.value)
  },
  
  price: function (event) {
    this.setData({
      price: Number(event.detail)
    })
    console.log(event.detail)
  },

  // 上传图片
  doUpload: function (e) {
    var that = this
    // 选择图片
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        const filePath = res.tempFilePaths[0]
        wx.showLoading({
          title: '上传中',
        })
        that.setData({
          isShowPic: false
        })
        // 上传图片
        // var timestamp = new Date().getTime()
        // const cloudPath = timestamp + filePath.match(/\.[^.]+?$/)[0]
        const cloudPath = `courseMatch/${app.globalData.courseMatchID}/${Date.now()}-${Math.floor(Math.random(0, 1) * 1000)}.png`;
        console.log(cloudPath)
        console.log("filePath:", filePath, "cloudPath:", cloudPath);
        wx.cloud.uploadFile({
          cloudPath,
          filePath,
          success: res => {
            console.log('[上传文件]成功：', res)
            that.setData({
              isShowPic: true,
              fileID: res.fileID
            })
          },
          fail: error => {
            console.error('[上传文件]失败', error)
            wx.showToast({
              icon: 'none',
              title: '上传失败',
            })
          },
          complete: () => {
            wx.hideLoading({
              success: (res) => {
                console.log('upload image complete')
              },
            })
          }
        })
      },
      fail: e => {
        console.error(e)
      }
    })
  },

  bindLoaction: function () {
    var that = this
    var that = this
    wx.getLocation({
      type: 'wgs84',
      success(res) {
        const latitude = res.latitude
        const longtitude = res.longtitude
        const speed = res.speed
        const accuracy = res.accuracy
        that.setData({
          latitude: latitude,
          longtitude: longitude
        })
        wx.chooseLocation({
          latitude: latitude,
          longtitude: longtitude,
          success(res) {
            that.setData({
              location_name: res.name,
              longtitude: res.longtitude,
              latitude: res.latitude
            })
          }
        })
      }
    })

  },

  bindKeyInputQuestion: function (e) {
    var index = e.currentTarget.dataset.idx
    this.data.Q_A[index].question = e.detail.value
    this.setData({
      Q_A: this.data.Q_A
    })
  },

  bindKeyInputAnswer: function (e) {
    var index = e.currentTarget.dataset.idx
    this.data.Q_A[index].answer = e.detail.value
    this.setData({
      Q_A: this.data.Q_A
    })
  },

  push: function (e) {
    var add_data = {
      question: '',
      answer: ''
    }
    var new_data = this.data.Q_A.concat(add_data)
    this.setData({
      Q_A: new_data
    })
  },

  pop: function (e) {
    var index = this.data.Q_A
    var new_data = this.data.Q_A.slice(0, index.length - 1)
    this.setData({
      Q_A: new_data
    })
  },

  clickSubmit: function () {
    if (that.data.click == 0) {
      this.setData({
        click: 1
      })
      this.addInformation(() => {}, this.data.longtitude, this.data.latitude, this.data.course_name, this.data.fileID, this.data.price, this.data.Q_A)
    }else{

    }
  },

  addInformation: function (succ, longtitude, latitude, name, cover, price, Q_A) {
    var that = this
    wx.cloud.callFunction({
      name: 'courseMatch',
      data: {
        type: 'add',
        id: (Date.now() - Math.floor(Math.random(0, 1) * 1000)),
        name: name,
        cover: cover,
        price: price,
        Q_A: Q_A,
        longtitude: longtitude,
        latitude: latitude
      }
    }).then(res => {
      console.log(res)
      if (res.result.errCode == 0) {
        wx.showToast({
          title: '信息添加成功',
          icon: 'success',
          duration: 2000
        })
        this.setData({
          click: 0
        })
        setTimeout(() => {
          wx.hideToast({
            success: (res) => {
              wx.navigateBack({
                delta: 1,
              })
            },
          })
        }, 2000);
      } else {
        wx.showToast({
          title: '信息添加失敗',
          icon: 'error',
          duration: 2000
        })
        setTimeout(() => {
          wx.hideToast({
            success: (res) => {

            },
          })
        }, 2000);
      }
      succ()
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})