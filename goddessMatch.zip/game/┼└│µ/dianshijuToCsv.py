# -*- coding: utf-8 -*-

"""

author: dfzymj
date: 2021-06-26
description: 抓取下载电视剧字典并保存

"""

import requests,csv,random,math,time,re,os
from bs4 import BeautifulSoup

def downloader(url,FileName):
    """
    下载电影字典并保存
    """
    response = requests.get(url)

    if response.status_code != 200:
        print(f'{url} is failed!')
        return
    
    print(f'{url} is parsing')
    html = BeautifulSoup(response.content.decode('utf-8', errors='ignore'), "lxml")
    a = html.find_all('a', target="_blank")
    s = html.find_all('img',border="0")
    prefix = 'http://www.zd9999.com'
    hrefs = []
    for w in a:
        if 'movie' not in w.get('href'):
            continue
        else:
            hrefs.append(prefix + w.get('href'))
    words = [w.get('alt') for w in s][1:]
    res = []
    for i in range(0, len(words)):
        idx = re.sub(r'\D',"",hrefs[i])
        
        response = requests.get(hrefs[i])
        print(f'{[hrefs[i]]} is parsing')
        if response.status_code != 200:
            print(f'{hrefs[i]} is failed!')
            continue
        
        wordhtml = BeautifulSoup(response.content.decode('utf-8', errors='ignore').replace('<br/>', '\n').replace('<br>', '\n')\
                     , "lxml")
        try:
            cast = wordhtml.find(attrs = {'class':'nLeft I5 jy'}).text.strip()
        except Exception as e:
            cast = ''
            continue
        try:
            if wordhtml.find_all(attrs= {"class":"nLeft I5"})[0].text == '':
                introduce = wordhtml.find_all(attrs= {"class":"nLeft I5"})[1].text
            else:
                introduce = wordhtml.find_all(attrs= {"class":"nLeft I5"})[0].text
        except Exception as e:
            introduce = ''
            continue
        try:
            content = wordhtml.find(attrs={"name":"content"}).text.strip()
        except Exception as e:
            content = ''
            continue
        jpg_data = wordhtml.find_all('img')[2].get('src') # 找到图片信息
        src = ''
        if "http://img.zd9999.com" in jpg_data:
            print('下载图片')
            src = 'cloud://cloud1-2godcvt481ecec78.636c-cloud1-2godcvt481ecec78-1305561666/dianshiju/'+ idx[4:] + '.jpg'
            img = requests.get(jpg_data)
            fpath = os.path.join(FileName,idx[4:])
            with open(fpath+'.jpg','wb+')as f : # 循环写入图片
                f.write(img.content)
            print('保存成功，快去查看图片吧！！')
        res.append({'id':idx[4:],\
                    'word': words[i],\
                    'introduction':introduce.strip(),\
                    'content': content,\
                    'banner':src,\
                    'cast':cast,\
                    'hot' :0,\
                    'word_type':19,\
                    'create_time':time.time(),\
                    'update_time':time.time()
                    })
    return res

if __name__ == '__main__':
    # 创建一个文件夹名称
    FileName = 'dianshiju2'
    if not os.path.exists(os.path.join(os.getcwd(), FileName)):     # 新建文件夹   
         print(u'建了一个名字叫做', FileName, u'的文件夹！')
         os.mkdir(os.path.join(os.getcwd(),'dianshiju2'))
    else:
        print(u'名字叫做', FileName, u'的文件夹已经存在了！')
    res = downloader('http://www.zd9999.com/dianshiju/index.htm',FileName)
    headers = ('id','word','introduction','content','banner','cast','hot','word_type','create_time','update_time')
    for i in range(2, 3):
        res += downloader(f'http://www.zd9999.com/dianshiju/index_{i}.htm',FileName)
    print(len(res))
    with open("C:\dianshiju2.csv",'w+',encoding='utf-8',newline='') as fp:
        # csv.DictWriter指定需要写入的文件和表头,并未写入表头
        writer = csv.DictWriter(fp,headers)
        # .writeheader写入表头
        writer.writeheader()
        # .writerows写入多行
        writer.writerows(res)
