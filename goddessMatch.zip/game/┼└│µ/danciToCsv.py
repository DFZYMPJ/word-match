# -*- coding: utf-8 -*-

"""

author: dfzymj
date: 2021-06-26
description: 抓取下载单词字典并保存

"""

import requests,csv,random,math,time,re,os,sys
from bs4 import BeautifulSoup
from selenium import webdriver

def downloader(url,lesson):
    """
    下载单词字典并保存
    """
    driver = webdriver.Firefox()
    browsers = driver.get(url)
    word = driver.find_element_by_class_name("l5")
    print(word)
    words = []
    for w in word:
        words.append(w.text)
    print(words)
    res = []
    for i in range(0,len(words)):
        prefix = 'https://danci.911cha.com/'
        browsers = driver.get(prefix + word[i] + '.html')
        explain = driver.find_element_by_class_name("l5")
        res.append({'id':i,\
                    'word':word,\
                    'firstword':firstword,\
                    'pronunciation':pronunciation,\
                    'explain':explain,\
                    'other': other,\
                    'content':content,\
                    'hot' :0,\
                    'lesson':lesson,\
                    'create_time':time.time(),\
                    'update_time':time.time()
                    })
    return res

if __name__ == '__main__':
    res = downloader('https://danci.911cha.com/lesson_1.html',1)
    headers = ('id','word','firstword','pronunciation','explain','other','hot','lesson','create_time','update_time')
    for i in range(2,2):
        res += downloader(f'https://danci.911cha.com/lesson_{i}.html',i)
    print(len(res))
    with open("C:\yanyuan.csv",'w+',encoding='utf-8',newline='') as fp:
        # csv.DictWriter指定需要写入的文件和表头,并未写入表头
        writer = csv.DictWriter(fp,headers)
        # .writeheader写入表头
        writer.writeheader()
        # .writerows写入多行
        writer.writerows(res)
