// pages/customQuery/customQuery.js
Component({
  properties: {
    msg: Object,
    recording: Boolean
  },

  data: {},
  lifetimes: {
    ready: function () { }
  },
  methods: {}
});