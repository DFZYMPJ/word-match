// pages/movieDetail/movieDetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: 0,
    content: '',
    introduction: '',
    word: '',
    image: undefined,
    cast: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    that.setData({
      id: options.id,
      image: options.banner
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'query_word',
      data: {
        type: 'simple',
        query_type: 18,
        query_id: Number(that.data.id)
      },
      success: res => {
        wx.showLoading({
          title: '请耐心等待',
        })
        if (res.result.errCode == 0) {
          that.setData({
            content: res.result.data.content[0].content,
            introduction: res.result.data.content[0].introduction,
            word: res.result.data.content[0].word,
            cast: res.result.data.content[0].cast,
            id: res.result.data.content[0].id
          })
          wx.setNavigationBarTitle({
            title: '内容详情-' + word,
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [query_word] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {
        setTimeout(function () {
          wx.hideLoading()
        }, 2000)
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    if (res.from === 'button') {
      // 来自也页面内转发按钮
      console.log(res.target)
      return {
        title: "向你推荐一部好看的电影：" + this.data.word,
        path: "/pages/weekly/weekly",
        imageUrl: "/images/movies.png",
        success: function (res) { }
      }
    }
    return
  }
})