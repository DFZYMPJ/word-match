// pages/star/star.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    person_A: 'cloud://cloud1-2godcvt481ecec78.636c-cloud1-2godcvt481ecec78-1305561666/yanyuan/12035.jpg',
    person_B: 'cloud://cloud1-2godcvt481ecec78.636c-cloud1-2godcvt481ecec78-1305561666/yanyuan/378.jpg',
    word_A: '邓紫棋',
    word_B: '迪丽热巴',
    winner_A: 0,
    winner_B: 0,
    losser_A: 0,
    losser_B: 0,
    A_id: '12035',
    B_id: '378',
    nickName: '',
    gender: 'female',
    click: 0
  },

  ranklist: function () {
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      wx.showModal({
        title: '提醒',
        content: '請先登陸~',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.navigateTo({
        url: '../ranklist/ranklist',
      })
    }
  },

  preview: function (e) {
    var image = e.currentTarget.dataset.image
    var that = this
    wx.previewImage({
      current: image,
      urls: [that.data.person_A, that.data.person_B],
    })
  },

  match: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'eol',
      data: {
        type: 'match',
        gender: that.data.gender
      },
      success: res => {
        if (res.result.errCode == 0) {
          wx.showToast({
            title: '请耐心等待',
            icon: 'loading',
            duration: 2000,
            mask: true
          })
          console.log(res.result)
          that.setData({
            person_A: res.result.data.cast[0].avatar,
            person_B: res.result.data.cast[1].avatar,
            A_id: res.result.data.cast[0]._id,
            B_id: res.result.data.cast[1]._id,
            winner_A: res.result.data.cast[0].winner,
            losser_A: res.result.data.cast[0].losser,
            winner_B: res.result.data.cast[1].winner,
            losser_B: res.result.data.cast[1].losser,
            word_A: res.result.data.cast[0].word,
            word_B: res.result.data.cast[1].word
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [eol] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }, complete: res => {
        setTimeout(() => {
          wx.hideToast({
            success: (res) => { },
          })
        }, 2000);
      }
    })
  },

  mash_A: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'eol',
      data: {
        type: 'mash',
        gender: that.data.gender
      },
      success: res => {
        if (res.result.errCode == 0) {
          wx.showToast({
            title: '請耐心等待',
            icon: 'loading',
            duration: 2000,
            mask: true
          })
          console.log(res.result)
          that.setData({
            person_B: res.result.data.cast[0].avatar,
            B_id: res.result.data.cast[0]._id,
            winner_B: res.result.data.cast[0].winner,
            losser_B: res.result.data.cast[0].losser,
            word_B: res.result.data.cast[0].word,
            click: 0
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [eol] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }, complete: res => {
        setTimeout(() => {
          wx.hideToast({
            success: (res) => { },
          })
        }, 2000);
      }
    })

  },

  mash_B: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'eol',
      data: {
        type: 'mash',
        gender: that.data.gender
      },
      success: res => {
        if (res.result.errCode == 0) {
          wx.showToast({
            title: '请耐心等待！',
            icon: 'loading',
            duration: 2000,
            mask: true
          })
          console.log(res.result)
          that.setData({
            person_A: res.result.data.cast[0].avatar,
            A_id: res.result.data.cast[0]._id,
            winner_A: res.result.data.cast[0].winner,
            losser_A: res.result.data.cast[0].losser,
            word_A: res.result.data.cast[0].word,
            click: 0
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [eol] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }, complete: res => {
        setTimeout(() => {
          wx.hideToast({
            success: (res) => { },
          })
        }, 2000);
      }
    })
  },

  evaluation: function () {
    var that = this
    wx.setStorageSync('Sa', undefined)
    // 调用云函数
    wx.cloud.callFunction({
      name: 'eol',
      data: {
        type: 'evaluation',
        A_id: that.data.A_id,
        B_id: that.data.B_id,
        Sa: 0.5
      },
      success: res => {
        if (res.result.errCode == 0) {
          wx.showToast({
            title: '双方打平，跳过！',
            icon: 'none',
            duration: 2000,
            mask: true
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [eol] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {
        setTimeout(() => {
          wx.hideLoading()
        }, 2000);
      }
    })
  },

  evaluation_a: function (e) {
    var that = this
    if (that.data.click == 0) {
      that.setData({
        winner_A: that.data.winner_A + 1,
        click: 1
      })
      wx.setStorageSync('Sa', 1)
      // 调用云函数
      wx.cloud.callFunction({
        name: 'eol',
        data: {
          type: 'evaluation',
          A_id: that.data.A_id,
          B_id: that.data.B_id,
          Sa: 1
        },
        success: res => {
          if (res.result.errCode == 0) {
            wx.showToast({
              title: '评价成功！',
              icon: 'success',
              duration: 2000,
              mask: true
            })
            console.log("評價成功")
            that.mash_A()
          } else {
            wx.showModal({
              title: '提醒',
              content: res.result.errMsg,
              confirmText: "我知道了",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }
        },
        fail: err => {
          console.error('[云函数] [eol] 调用失败', err)
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions',
          })
        },
        complete: res => {
          setTimeout(() => {
            wx.hideToast()
          }, 2000);
        }
      })
    }
  },

  evaluation_b: function (e) {

    var that = this
    if (that.data.click == 0) {
      that.setData({
        winner_B: that.data.winner_B + 1,
        click: 1
      })
      wx.setStorageSync('Sa', 0)
      // 调用云函数
      wx.cloud.callFunction({
        name: 'eol',
        data: {
          type: 'evaluation',
          A_id: that.data.A_id,
          B_id: that.data.B_id,
          Sa: 0
        },
        success: res => {
          if (res.result.errCode == 0) {
            console.log("評價成功")
            wx.showToast({
              title: '评价成功！',
              icon: 'success',
              duration: 2000,
              mask: true
            })
            that.mash_B()
          } else {
            wx.showModal({
              title: '提醒',
              content: res.result.errMsg,
              confirmText: "我知道了",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }
        },
        fail: err => {
          console.error('[云函数] [eol] 调用失败', err)
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions',
          })
        },
        complete: res => {
          setTimeout(() => {
            wx.hideToast()
          }, 1000);
        }
      })
    }
  },

  about: function (event) {
    this.onPullDownRefresh()
  },

  avatarMash: function () {
    wx.navigateTo({
      url: '/pages/avatarMash/avatarMash',
    })
  },

  refresh: function () {
    this.onReachBottom()
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var userInfo = wx.getStorageSync('userInfo')
    this.setData({
      nickName: userInfo.nickName
    })
    this.match()
    // var Sa = wx.setStorageSync('Sa', 1)
    // if (Sa == undefined) {
    //   this.match()
    // } else if (Sa == 1) {
    //   this.mash_A()
    // } else if (Sa == 0) {
    //   this.mash_B()
    // }
    if (options.isLogin) {
      wx.setStorageSync('logged', true)
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    wx.clearStorageSync('Sa')
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    var Sa = wx.getStorageSync('Sa')
    if (Sa == undefined) {
      this.match()
      this.evaluation()
    } else if (Sa == 1) {
      this.mash_A()
    } else if (Sa == 0) {
      this.mash_B()
    }
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.gender == 'male') {
      this.setData({
        gender: 'female'
      })
      wx.setStorageSync('Sa', undefined)
      this.match()
      this.evaluation()
    } else {
      this.setData({
        gender: 'male'
      })
      wx.setStorageSync('Sa', undefined)
      this.match()
      this.evaluation()
    }
    var Sa = wx.getStorageSync('Sa')
    if (Sa == undefined) {
    } else if (Sa == 1) {
      this.mash_A()
    } else if (Sa == 0) {
      this.mash_B()
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareTimeline: function (res) {
    if (res.from === 'button') {
      // 来自也页面内转发按钮
      console.log(res.target)
      const promise = new Promise(resolve => {
        setTimeout(() => {
          resolve({
            title: "学神录：这是一个简单的游戏，谁最火爆？",
            imageUrl: "/images/gift_img.png"
          })
        }, 2000)
      })
      return {
        title: "学神录：这是一个简单的游戏，谁最火爆？",
        query: "/pages/star/star?isLogin=true",
        imageUrl: "/images/gift_img.png",
        success: function (res) { }
      }
    }
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: "学神录：这是一个简单的游戏，谁最火爆？",
          imageUrl: "/images/gift_img.png"
        })
      }, 2000)
    })
    return {
      title: "学神录：这是一个简单的游戏，谁最火爆？",
      query: "/pages/star/star?isLogin=true",
      imageUrl: "/images/gift_img.png",
      promise
    }
  },

  onShareAppMessage() {
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: '學神錄：' + this.data.nickName + "向你推荐！",
          imageUrl: "/images/gift_img.png",
        })
      }, 2000)
    })
    return {
      title: '學神錄：' + this.data.nickName + "向你推荐！",
      path: '/pages/star/star',
      promise
    }
  }
})

