// pages/courseTable/courseTable.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    doc: [],
    match: [],
    search_word: ''
  },

  bindKeyInput: function (e) {
    this.setData({
      search_word: e.detail.value
    })
    console.log('你正在输入:' + e.detail.value)
  },

  search: function () {
    var i = 0;
    var search_word = this.data.search_word
    var match = this.data.match;
    var newMatch = []
    for (; match.length > i; i++) {
      if (match[i].name == search_word) {
        newMatch = newMatch.concat([match[i]])
      }
    }
    this.setData({
      match: newMatch
    })
  },

  matchCourse: function (succ, id) {
    var that = this
    wx.cloud.callFunction({
      name: 'courseMatch',
      data: {
        type: 'match',
        id: id
      }
    }).then(res => {
      console.log(res)
      if (res.result.data.table == []) {
        that.setData({
          match: []
        })
        wx.showToast({
          title: '暂无课程',
          icon: 'error'
        })
      } else {
        that.setData({
          match: res.result.data.table,
          doc: res.result.data.doc
        })
        wx.setStorageSync('match', res.result.data.table)
        wx.showToast({
          title: res.result.errMsg,
        })
      }
      setTimeout(() => {
        wx.hideToast({
          success: (res) => { },
        })
      }, 2000);
      succ()
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options.id)
    wx.setNavigationBarTitle({
      title: options.name + '的课表',
    })
    this.matchCourse(() => { }, options.id)

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})