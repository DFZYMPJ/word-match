//app.js

App({
  onLaunch: function () {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        // env 参数说明：
        //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
        //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
        //   如不填则使用默认环境（第一个创建的环境）
        // env: 'my-env-id',
        traceUser: true,
      })
      this.userinit(() => { })

      var that = this
      wx.getLocation({
        type: 'wgs84',
        success(res) {
          const latitude = res.latitude
          const longitude = res.longitude
          const speed = res.speed
          const accuracy = res.accuracy
          that.courseMatchinit(() => { }, longitude, latitude)
          that.globalData.location = res
          console.log()
        }
      })
    }
    wx.cloud.callFunction({
      name: 'getSubscribeMessageTemplate',
      data: {
        type: "update"
      },
      success: res => {
        if (res.result.errCode == 0) {
          wx.setStorageSync('template3', res.result.data.templateId)
          console.log(res.result.data.templateId)
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [getSubscribeMessageTemplate] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })

    const updateManager = wx.getUpdateManager()
    updateManager.onCheckForUpdate(function (res) {
      // 请求完新版本信息的回调
      console.log(res.hasUpdate)
    })

    updateManager.onUpdateReady(function () {
      wx.showModal({
        title: '更新提示',
        content: '新版本已经准备好，是否重启应用？',
        success(res) {
          if (res.confirm) {
            // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
            updateManager.applyUpdate()
          }
        }
      })
    })

    updateManager.onUpdateFailed(function () {
      // 新版本下载失败
    })

    this.globalData = {
      logged: false,
      userInfo: {},
      user: {},
      uid: null,
      openid: null,
      id: null,
      list: [],
      courseMatchID: [],
      location: {}
    }
  },
  Randomsend: function (min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },

  courseMatchinit(succ, longitude, latitude) {
    // 初始化用户加载
    let that = this;
    wx.cloud.callFunction({
      name: 'courseMatch',
      data: {
        type: 'init',
        longitude: longitude,
        latitude: latitude,
      }
    }).then(res => {
      console.log(res)
      that.globalData.courseMatchID = res.result.data.id;
      succ();
    })
  },
  userinit(succ) {
    // 初始化用户加载
    let that = this;
    wx.cloud.callFunction({
      name: 'init',
      data: {
        id: that.Randomsend(1, 100000)
      }
    }).then(res => {
      console.log(res);
      that.globalData.id = res.result.id;
      that.globalData.list = res.result.list;
      succ();
    })
  }
})