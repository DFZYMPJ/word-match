// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

//将云开发数据库能力声明给db
const db = cloud.database();

//将云开发数据库command能力声明给 _
const _ = db.command;


// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  try {
    const result = await db.collection('messages').add({
      data: {
        touser: wxContext.OPENID,
        page: 'index',
        data: event.data,
        templateId: event.templateId,
        date: new Date(event.date),
        done: false,
      },
    });
    return result;
  } catch (err) {
    console.log(err);
    return err;
  }
}