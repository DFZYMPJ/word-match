// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const db = cloud.database()
  switch (event.type) {
    case "get": {
      return getCourseList(db, event)
    }
    case "find": {
      return searchCourseList(db, event, wxContext)
    }
  }
}


async function getCourseList(db, event) {
  /** 检测是否传入参数 start **/
  if (event.skip == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/
  var i = event.skip
  // 每次至多查询多少个热词
  const MAX_LIMIT = 10
  // 定义一个變量接受查询结果
  var course;
  await db.collection('course_book')
    .orderBy('lesson', 'asc')
    .limit(MAX_LIMIT)
    .skip(MAX_LIMIT * i)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      course = res.data
    })
  // 将时间格式转换
  for (let i = 0; i < course.length - 1; i++) {
    var date = new Date(course[i].update_time);
    course[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(course[i].create_time);
    course[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  var result = {}
  result.errCode = 0
  result.errMsg = '获取课本成功'
  var data = {}
  data.course = course
  result.data = data
  console.log(data)
  return result
}

async function searchCourseList(db, event, wxContext) {
  /** 检测用户的openid start*/
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  /** 检测是否传入参数 start **/
  if (event.query_word == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/

  // 定义一个變量接受查询结果
  var items;
  const _ = db.command
  var query_word = event.query_word.toString()
  await db.collection('course_book')
    .where(
      _.or([{
        version: query_word.toString()
      },
      {
        stage: query_word.toString()
      },
      {
        level: query_word.toString()
      },
      {
        lesson: Number(query_word)
      }
      ])
    )
    .orderBy('lesson', 'desc')
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      items = res.data
    })
  // 将时间格式转换
  for (let i = 0; i < items.length - 1; i++) {
    var date = new Date(items[i].update_time);
    items[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(items[i].create_time);
    items[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  var result = {}
  result.errCode = 0
  result.errMsg = '获取课本成功'
  var data = {}
  data.course = items
  result.data = data
  console.log(data)
  return result
}