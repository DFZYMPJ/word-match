# -*- coding: utf-8 -*-

"""

author: dfzymj
date: 2021-06-26
description: 抓取下载演员字典并保存

"""

import requests,csv,random,math,time,re,os
from bs4 import BeautifulSoup

def downloader(url,FileName):
    """
    下载演员字典并保存
    """
    response = requests.get(url)

    if response.status_code != 200:
        print(f'{url} is failed!')
        return
    
    print(f'{url} is parsing')
    html = BeautifulSoup(response.content.decode('utf-8', errors='ignore'), "lxml")
    a = html.find_all('a', target="_blank")
    prefix = 'http://www.zd9999.com'
    hrefs = []
    for w in a[0:18]:
        if '/yanyuan' not in w.get('href'):
            continue
        else:
            hrefs.append(prefix + w.get('href'))
    print(hrefs)
    res = []
    for i in range(0, len(hrefs),2):
        idx = re.sub(r'\D',"",hrefs[i])
        print(idx)
        response = requests.get(hrefs[i])
        print(f'{[hrefs[i]]} is parsing')
        if response.status_code != 200:
            print(f'{hrefs[i]} is failed!')
            continue
        
        wordhtml = BeautifulSoup(response.content.decode('utf-8', errors='ignore').replace('<br/>', '\n').replace('<br>', '\n')\
                     , "lxml")

        ch_name = wordhtml.find('table').find_all('tr')[1].find_all('td')[0].text.strip()
        en_name = wordhtml.find('table').find_all('tr')[1].find_all('td')[1].text.strip()
        birthday = wordhtml.find('table').find_all('tr')[2].find_all('td')[0].text.strip()
        height = wordhtml.find('table').find_all('tr')[3].find_all('td')[0].text.strip()
        weight = wordhtml.find('table').find_all('tr')[3].find_all('td')[1].text.strip()
        constellation = wordhtml.find('table').find_all('tr')[4].find_all('td')[0].text.strip()
        blood_type = wordhtml.find('table').find_all('tr')[4].find_all('td')[1].text.strip()
        introduce = wordhtml.find(class_="nLeft jshg").text.strip()
        jpg_data = wordhtml.find(class_="cImage9").get('src') # 找到图片信息
        src = ''
        if "http://img.zd9999.com" in jpg_data:
            print('下载图片')
            src = 'cloud://cloud1-2godcvt481ecec78.636c-cloud1-2godcvt481ecec78-1305561666/yanyuan/'+ idx[4:] + '.jpg'
            img = requests.get(jpg_data)
            fpath = os.path.join(FileName,idx[4:])
            with open(fpath+'.jpg','wb+')as f : # 循环写入图片
                f.write(img.content)
            print('保存成功，快去查看图片吧！！')
        res.append({'id':idx[4:],\
                    'word':ch_name[4:],\
                    'avatar':src,\
                    'ch_name':ch_name,\
                    'en_name': en_name,\
                    'birthday':birthday,\
                    'weight':weight,\
                    'height':height,\
                    'constellation':constellation,\
                    'blood_type':blood_type,\
                    'hot' :0,\
                    'word_type':20,\
                    'create_time':time.time(),\
                    'update_time':time.time()
                    })
    return res

if __name__ == '__main__':
    # 创建一个文件夹名称
    FileName = 'yanyuan'
    if not os.path.exists(os.path.join(os.getcwd(), FileName)):     # 新建文件夹   
         print(u'建了一个名字叫做', FileName, u'的文件夹！')
         os.mkdir(os.path.join(os.getcwd(),'yanyuan'))
    else:
        print(u'名字叫做', FileName, u'的文件夹已经存在了！')
    res = downloader('http://www.zd9999.com/yanyuan/index.htm',FileName)
    headers = ('id','word','avatar','ch_name','en_name','birthday','weight','height','constellation','blood_type','hot','word_type','create_time','update_time')
    for i in range(3021,3639):
        res += downloader(f'http://www.zd9999.com/yanyuan/index_{i}.htm',FileName)
    print(len(res))
    with open("C:\yanyuan.csv",'w+',encoding='utf-8',newline='') as fp:
        # csv.DictWriter指定需要写入的文件和表头,并未写入表头
        writer = csv.DictWriter(fp,headers)
        # .writeheader写入表头
        writer.writeheader()
        # .writerows写入多行
        writer.writerows(res)
