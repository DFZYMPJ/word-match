# -*- coding: utf-8 -*-

"""

author: dfzymj
date: 2021-06-19 
description: 抓取下载中药名方字典并保存

"""

import requests,csv,random,math,time,re,os
from bs4 import BeautifulSoup

def downloader(url,FileName):
    """
    下载中药名方字典并保存
    """
    response = requests.get(url)

    if response.status_code != 200:
        print(f'{url} is failed!')
        return
    
    print(f'{url} is parsing')
    html = BeautifulSoup(response.content.decode('gbk', errors='ignore'), "lxml")
    a = html.find_all('a', target="_blank")
    
    prefix = 'http://www.zd9999.com'
    words = [prefix + w.get('href') for w in a]
    href = [w.get('href') for w in a]

    res = []
    for i in range(0, len(words)):
        response = requests.get(words[i])
        print(f'{[words[i]]} is parsing')
        if response.status_code != 200:
            print(f'{words[i]} is failed!')
            continue

        wordhtml = BeautifulSoup(response.content.decode('gbk', errors='ignore').replace('<br/>', '\n').replace('<br>', '\n')\
                     , "lxml")
        td = wordhtml.find_all('table')[4].find_all('td')
        content = td[2].text.strip()
        idx = re.sub(r'\D',"",href[i])
        jpg_data = wordhtml.find_all('img')[1].get('src') # 找到图片信息
        print(jpg_data)
        src = ''
        if "/image" in jpg_data:
            print('下载图片')
            if "http://www.zd9999.com" not in jpg_data:
                jpg_data = 'http://www.zd9999.com'+jpg_data
                src = 'cloud://cloud1-2godcvt481ecec78.636c-cloud1-2godcvt481ecec78-1305561666/mf/'+ idx + '.jpg'
            img = requests.get(jpg_data)
            fpath = os.path.join(FileName,idx)
            with open(fpath+'.jpg','wb+')as f : # 循环写入图片
                f.write(img.content)
            print('保存成功，快去查看图片吧！！')
        
        res.append({'id':idx[1:],\
                    'word': td[1].text.strip(),\
                    'content': content[content.find(''):].strip(),\
                    'src':src,\
                    'hot' :0,\
                    'word_type':10,\
                    'create_time':time.time(),\
                    'update_time':time.time()
                    })
    return res

if __name__ == '__main__':
    # 创建一个文件夹名称
    FileName = 'mf'
    if not os.path.exists(os.path.join(os.getcwd(), FileName)):     # 新建文件夹   
         print(u'建了一个名字叫做', FileName, u'的文件夹！')
         os.mkdir(os.path.join(os.getcwd(),'mf'))
    else:
        print(u'名字叫做', FileName, u'的文件夹已经存在了！')
    res = downloader('http://www.zd9999.com/mf/index.htm',FileName)
    headers = ('id','word','content','src','hot','word_type','create_time','update_time')
    for i in range(2, 54):
        res += downloader(f'http://www.zd9999.com/mf/index_{i}.htm',FileName)
    print(len(res))
    with open("C:\mf.csv",'w+',encoding='utf-8',newline='') as fp:
        # csv.DictWriter指定需要写入的文件和表头,并未写入表头
        writer = csv.DictWriter(fp,headers)
        # .writeheader写入表头
        writer.writeheader()
        # .writerows写入多行
        writer.writerows(res)
