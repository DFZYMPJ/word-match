// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  /** 检测用户是否登陆 start**/
  const wxContext = cloud.getWXContext()
  if (wxContext.OPENID == undefined) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未登录，操作失败'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户是否登陆 end**/

  /** 检测是否传入了参数 start **/
  if (event.type == undefined) {
    var result = {}
    result.errCode = 1
    result.errMsg = '未传入参数，请重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入了参数 end **/
  // 实例化数据
  const db = cloud.database()

  switch (event.type) {
    case "join": {
      return joinThumb(db, event)
    }
    case "remove": {
      return removeThumb(db, event)
    }
    case "has": {
      return hasThumb(db, event)
    }
    case "add": {
      return addLike(db, event.uid, event.word_id, event.word_type)
    }
    case "del": {
      return delLike(db, event.uid, event.word_id, event.word_type)
    }
    case "total": {
      return totalLike(db, event.word_id, event.word_type)
    }
    case "is": {
      return isLike(db, event.uid, event.word_id, event.word_type)
    }
    case "query": {
      return
    }
    default: {
      return
    }
  }
}

async function joinThumb(db, event) {
  /** 是否传入必要参数 start **/
  if (event.openid == undefined || event.ddnote_id == undefined) {
    var result = {}
    result.errCode = 3
    result.errMsg = '未传入必要参数：openid or ddnote_id'
    var data = {}
    result.data = data
    return result
  }
  /** 是否传入必要参数 end **/
  //构建要添加的参数
  const to_add_data = {
    openid: event.openid,
    ddnote_id: event.ddnote_id,
    is_like: true,
    create_time: new Date(),
    update_time: new Date()
  }
  // 新增数据
  var add_result = []
  await db.collection('like')
    .add({
      data: to_add_data
    })
    .then(res => {
      console.log("点赞成功")
      console.log(res)
      add_result = res.data
    })
  // 返回执行结果
  var result = {}
  result.errCode = 0;
  result.errMsg = '操作成功2';
  var data = {}
  data.add_result = add_result
  result.data = data
  return result
}

async function removeThumb(db, event) {
  /** 检测是否传入必要参数 start */
  if (event.ddnote_id == undefined) {
    var result = {}
    result.errCode = 3
    result.errMsg = '未传入必要参数：ddnote_id'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入必要参数 end **/
  // 更新数据
  await db.collection("like")
    .where({
      openid: event.openid,
      ddnote_id: Number(event.ddnote_id)
    })
    .update({
      data: {
        is_like: false
      }
    })
    .then(res => {
      console.log("取消点赞")
      console.log(res)
    })
  // 返回执行结果
  var result = {}
  result.errCode = 0;
  result.errMsg = '操作成功3';
  var data = {}
  result.data = data
  return result
}

async function addLike(db, uid, word_id, word_type) {
  /** 是否传入必要参数 start **/
  if (uid == undefined || word_id == undefined) {
    var result = {}
    result.errCode = 3
    result.errMsg = '未传入必要参数：uid or word_id'
    var data = {}
    result.data = data
    return result
  }
  /** 是否传入必要参数 end **/
  //构建要添加的参数
  const to_add_data = {
    uid: uid,
    word_id: word_id,
    word_type: word_type,
    is_like: true,
    create_time: new Date(),
    update_time: new Date()
  }
  // 新增数据
  var add_result = {}
  await db.collection('like')
    .add({
      data: to_add_data
    })
    .then(res => {
      console.log("点赞成功")
      console.log(res)
      add_result = res.data
    })
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '操作成功'
  var data = {}
  result.data = add_result
  return result
}

async function delLike(db, uid, word_id, word_type) {
  /** 检测是否传入必要参数 start */
  if (word_id == undefined) {
    var result = {}
    result.errCode = 3
    result.errMsg = '未传入必要参数：word_id'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入必要参数 end **/
  // 更新数据
  await db.collection("like")
    .where({
      uid: uid,
      word_id: word_id,
      word_type: word_type
    })
    .update({
      data: {
        is_like: false
      }
    })
    .then(res => {
      console.log("取消点赞")
      console.log(res)
    })
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '操作成功'
  var data = {}
  result.data = data
  return result
}

async function totalLike(db, word_id, word_type) {
  /** 检测是否传入必要参数 start */
  if (word_id == undefined) {
    var result = {}
    result.errCode = 3
    result.errMsg = '未传入必要参数：word_id'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入必要参数 end **/
  // 定义一个变量存储该词的点赞量
  const count = await db.collection("like")
    .where({
      word_id: word_id,
      word_type: word_type,
      is_like: true
    })
    .count()

  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '成功获取点赞量'
  var data = {}
  data.total = count.total
  result.data = data
  return result
}

async function isLike(db, uid, word_id, word_type) {
  /** 是否传入必要参数 start **/
  if (uid == undefined || word_id == undefined || word_type == undefined) {
    var result = {}
    result.errCode = 3
    result.errMsg = '未传入必要参数：uid or word_id or word_type'
    var data = {}
    result.data = data
    return result
  }
  /** 是否传入必要参数 end **/
  // 定义一个变量存储点赞的状态
  var status = false;
  const countResult = await db.collection('like')
    .where({
      uid: Number(uid),
      word_id: Number(word_id),
      word_type: word_type,
      is_like: true
    })
    .count()
  if (countResult.total == 1) {
    status = true
  }

  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '成功获取状态'
  var data = {}
  data.status = status
  result.data = data
  return result
}

async function hasThumb(db, event) {
  /** 是否传入必要参数 start **/
  if (event.openid == undefined || event.ddnote_id == undefined) {
    var result = {}
    result.errCode = 3
    result.errMsg = '未传入必要参数：openid or ddnote_id'
    var data = {}
    result.data = data
    return result
  }
  /** 是否传入必要参数 end **/
  // 定义一个变量存储点赞的状态
  var statu;
  const countResult = await db.collection('like')
    .where({
      ddnote_id: Number(event.ddnote_id),
      openid: event.openid,
      is_like: true
    }).count()
  if (countResult.total > 0) {
    statu = true
  } else {
    statu = false
  }
  // 返回执行结果
  var result = {}
  result.errCode = 0;
  result.errMsg = '获取状态成功';
  var data = {}
  data.status = statu
  result.data = data
  return result

}