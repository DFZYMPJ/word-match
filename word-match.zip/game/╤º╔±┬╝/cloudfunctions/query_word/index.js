// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {

  // 实例化数据库连接
  const db = cloud.database()
  switch (event.type) {
    case "similar": {
      var query_word = event.query_word.toString()
      console.log(query_word)
      return querySimilarWord(db, query_word);
    }
    case "simple": {
      return querySimpleWord(db, event.query_id, event.query_type);
    }
    default: {
      return
    }
  }
}

async function querySimilarWord(db, query_word) {
  /** 传递必要的参数 start **/
  console.log(query_word)
  if (query_word.toString() == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '为传递参数，请重试'

    var data = {}
    result.data = data
    return result
  } else {
    var query_word = query_word.toString()
  }
  /** 是否存在该词 start **/
  // 定义查询指令 
  const _ = db.command
  // 定義數組變量接收查詢結果
  var word;
  var idiom;
  var food_drink;
  var healthy;
  var mathematics_chemistry;
  var finance;
  var microbe;
  var movie;
  var cast;
  var TV_Play;
  var Chinese_herbal_medicine;
  var wine_method;
  var sports;
  var famous_method;
  var Porridge_spectrum;
  var computer_network;
  var plant;
  var zoom;
  var natural_astronomy;
  var patt1 = new RegExp("[\\u4e00-\\u9fa5-zA-Z]", 'i');
  if (!patt1.test(query_word)) {
    // 查询成语词典
    await db.collection('idiom')
      .where(
        _.or([{
          id: Number(query_word)
        },
        {
          index: Number(query_word)
        }
        ]))
      .field({
        _id: false,
        id: true,
        hot: true,
        index: true,
        pinyin: true,
        word_type: true,
        explanation: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询dictionary成功')
        idiom = res.data
      })
    // 查询单词库
    await db.collection('word')
      .where(
        _.or([{
          id: Number(query_word)
        },
        {
          idx: Number(query_word)
        }
        ]))
      .field({
        _id: false,
        id: true,
        hot: true,
        index: true,
        word: true,
        word_type: true,
        pinyin: true,
        explanation: true,
      })
      .get()
      .then(res => {
        console.log('查询成功')
        word = res.data
      })
    // 查询饮食词库
    await db.collection('food_drink')
      .where(
        _.or([{
          id: Number(query_word)
        },
        {
          index: Number(query_word)
        }
        ]))
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询food_drink成功')
        food_drink = res.data
      })
    // 查询健康词库
    await db.collection('healthy')
      .where(
        _.or([{
          id: Number(query_word)
        },
        {
          index: Number(query_word)
        }
        ]))
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询healthy成功')
        healthy = res.data
      })
    // 查询数理化词库
    await db.collection('mathematics_chemistry')
      .where(
        _.or([{
          id: Number(query_word)
        },
        {
          index: Number(query_word)
        }
        ]))
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询mathematics_chemistry成功')
        mathematics_chemistry = res.data
      })
    // 查询zoom词库
    await db.collection('zoom')
      .where(
        _.or([{
          id: Number(query_word)
        },
        {
          index: Number(query_word)
        }
        ]))
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询mathematics_chemistry成功')
        zoom = res.data
      })

    // 查询microbe词库
    await db.collection('microbe')
      .where(
        _.or([{
          id: Number(query_word)
        },
        {
          index: Number(query_word)
        }
        ]))
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询microbe成功')
        microbe = res.data
      })

    // 查询plant词库
    await db.collection('plant')
      .where(
        _.or([{
          id: Number(query_word)
        },
        {
          index: Number(query_word)
        }
        ]))
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询plant成功')
        plant = res.data
      })
  } else {
    var query_word = query_word
    // 查询字符串长度是否为4
    if (query_word.length == 4) {
      await db.collection('idiom')
        .where(
          _.or([{
            abbreviation: query_word.toString()
          },
          {
            word: query_word.toString()
          }
          ]))
        .field({
          _id: false,
          word: true,
          id: true,
          index: true,
          hot: true,
          explanation: true,
          pinyin: true,
          word_type: true,
          create_time: true,
          update_time: true
        })
        .get()
        .then(res => {
          console.log(query_word + '成语查询成功')
          idiom = res.data
        })
    } else if (query_word.length == 1) {
      // 查詢漢字
      await db.collection('word')
        .where(
          _.or([{
            abbreviation: query_word.toString()
          }, {
            word: query_word.toString()
          }]))
        .field({
          _id: false,
          id: true,
          index: true,
          hot: true,
          word: true,
          word_type: true,
          explanation: true,
          pinyin: true,
          more: true,
          update_time: true
        })
        .get()
        .then(res => {
          console.log('查询word集合成功')
          word = res.data
        })
      // 查詢字典
      await db.collection('idiom')
        .where(
          _.or([{
            firstword: query_word
          }, {
            wholeword: query_word
          }])
        )
        .field({
          _id: false,
          id: true,
          index: true,
          hot: true,
          pinyin: true,
          explanation: true,
          create_time: true,
          update_time: true,
          word_type: true,
          word: true

        })
        .get()
        .then(res => {
          console.log('以' + query_word + '开头或结尾的字的成语查询成功')
          idiom = res.data
        })
    }

    // 查询饮食词库
    await db.collection('food_drink')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询food_drink成功')
        food_drink = res.data
      })
    // 查询健康词库
    await db.collection('healthy')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询healthy成功')
        healthy = res.data
      })
    // 查询数理化词库
    await db.collection('mathematics_chemistry')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询mathematics_chemistry成功')
        mathematics_chemistry = res.data
      })
    // 查询電腦網絡词库
    await db.collection('computer_network')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询computer_network成功')
        computer_network = res.data
      })

    // 查询自然天文词库
    await db.collection('natural_astronomy')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询natural_astronomy成功')
        natural_astronomy = res.data
      })
    // 查询名方词库
    await db.collection('famous_method')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询famous_method成功')
        famous_method = res.data
      })
    // 查询動物词库
    await db.collection('zoom')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询zoom成功')
        zoom = res.data
      })
    // 查询植物词库
    await db.collection('plant')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询plant成功')
        plant = res.data
      })
    // 查询體育词库
    await db.collection('sports')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询sport成功')
        sports = res.data
      })
    // 查询酒方词库
    await db.collection('wine_method')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询wine_method成功')
        wine_method = res.data
      })
    // 查询金融词库
    await db.collection('finance')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询finance成功')
        finance = res.data
      })
    //查询微生物词库
    await db.collection('microbe')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询microbe成功')
        microbe = res.data
      })
    //查询中草藥词库
    await db.collection('Chinese_herbal_medicine')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询Chinese_herbal_medicine成功')
        Chinese_herbal_medicine = res.data
      })
    //查询偏方词库
    await db.collection('Folk_prescription')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询Folk_prescription成功')
        Folk_prescription = res.data
      })
    //查询粥譜词库
    await db.collection('Porridge_spectrum')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        src: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询Porridge_spectrum成功')
        Porridge_spectrum = res.data
      })
    //查询電影词库
    await db.collection('movie')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        introduction: true,
        banner: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询movie成功')
        movie = res.data
      })
    // 查找電視劇詞庫
    await db.collection('TV_Play')
      .where({
        word: query_word
      })
      .field({
        _id: false,
        id: true,
        hot: true,
        word_type: true,
        content: true,
        introduction: true,
        banner: true,
        word: true
      })
      .get()
      .then(res => {
        console.log('查询TV_Play成功')
        TV_Play = res.data
      })
    //查询演員词库
    await db.collection('cast')
      .where({
        word: query_word
      })
      .get()
      .then(res => {
        console.log('查询cast成功')
        microbe = res.data
      })
  }

  /** 是否存在该词 end **/
  if (idiom == undefined && word == undefined && food_drink == undefined && healthy == undefined && mathematics_chemistry == undefined && finance == undefined && microbe == undefined && movie == undefined && cast == undefined && Porridge_spectrum == undefined && Folk_prescription == undefined && wine_method == undefined && TV_Play == undefined && famous_method == undefined && zoom == undefined && plant == undefined && Chinese_herbal_medicine == undefined && natural_astronomy == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 3
    result.errMsg = '不存在该词,可联系我们添加'

    var data = {}
    result.data = data
    return result

  } else if (word == undefined || idiom == undefined) {
    if (food_drink != undefined) {
      if (food_drink.length == 1) {
        console.log()
        await db.collection('food_drink')
          .where({
            id: food_drink[0].id
          })
          .update({
            data: {
              hot: food_drink[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }
    } else {
      food_drink = []
    }
    if (mathematics_chemistry != undefined) {
      if (mathematics_chemistry.length == 1) {
        await db.collection('mathematics_chemistry')
          .where({
            id: mathematics_chemistry[0].id
          })
          .update({
            data: {
              hot: mathematics_chemistry[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }
    } else {
      mathematics_chemistry = []
    }
    if (healthy != undefined) {
      if (healthy.length == 1) {
        await db.collection('healthy')
          .where({
            id: healthy[0].id
          })
          .update({
            data: {
              hot: healthy[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }
    } else {
      healthy = []
    }
    if (finance != undefined) {
      if (finance.length == 1) {
        await db.collection('finance')
          .where({
            id: finance[0].id
          })
          .update({
            data: {
              hot: finance[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      finance = []
    }
    if (microbe != undefined) {
      if (microbe.length == 1) {
        await db.collection('microbe')
          .where({
            id: microbe[0].id
          })
          .update({
            data: {
              hot: microbe[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      microbe = []
    }
    if (movie != undefined) {
      if (movie.length == 1) {
        await db.collection('movie')
          .where({
            id: movie[0].id
          })
          .update({
            data: {
              hot: movie[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      movie = []
    }
    if (TV_Play != undefined) {
      if (TV_Play.length == 1) {
        await db.collection('TV_Play')
          .where({
            id: TV_Play[0].id
          })
          .update({
            data: {
              hot: TV_Play[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      TV_Play = []
    }
    if (Porridge_spectrum != undefined) {
      if (Porridge_spectrum.length == 1) {
        await db.collection('Porridge_spectrum')
          .where({
            id: Porridge_spectrum[0].id
          })
          .update({
            data: {
              hot: Porridge_spectrum[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      Porridge_spectrum = []
    }
    if (famous_method != undefined) {
      if (famous_method.length == 1) {
        await db.collection('famous_method')
          .where({
            id: famous_method[0].id
          })
          .update({
            data: {
              hot: famous_method[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      famous_method = []
    }
    if (wine_method != undefined) {
      if (wine_method.length == 1) {
        await db.collection('wine_method')
          .where({
            id: wine_method[0].id
          })
          .update({
            data: {
              hot: wine_method[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      wine_method = []
    }
    if (Folk_prescription != undefined) {
      if (Folk_prescription.length == 1) {
        await db.collection('Folk_prescription')
          .where({
            id: Folk_prescription[0].id
          })
          .update({
            data: {
              hot: Folk_prescription[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      Folk_prescription = []
    }
    if (Chinese_herbal_medicine != undefined) {
      if (Chinese_herbal_medicine.length == 1) {
        await db.collection('Chinese_herbal_medicine')
          .where({
            id: Chinese_herbal_medicine[0].id
          })
          .update({
            data: {
              hot: Chinese_herbal_medicine[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      Chinese_herbal_medicine = []
    }
    if (sports != undefined) {
      if (sports.length == 1) {
        await db.collection('sports')
          .where({
            id: sports[0].id
          })
          .update({
            data: {
              hot: sports[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      sports = []
    }
    if (plant != undefined) {
      if (plant.length == 1) {
        await db.collection('plant')
          .where({
            id: plant[0].id
          })
          .update({
            data: {
              hot: plant[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      plant = []
    }
    if (zoom != undefined) {
      if (zoom.length == 1) {
        await db.collection('zoom')
          .where({
            id: zoom[0].id
          })
          .update({
            data: {
              hot: zoom[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      zoom = []
    }
    if (natural_astronomy != undefined) {
      if (natural_astronomy.length == 1) {
        await db.collection('natural_astronomy')
          .where({
            id: natural_astronomy[0].id
          })
          .update({
            data: {
              hot: natural_astronomy[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      natural_astronomy = []
    }
    if (cast != undefined) {
      if (cast.length == 1) {
        await db.collection('cast')
          .where({
            id: cast[0].id
          })
          .update({
            data: {
              hot: cast[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      cast = []
    }
    if (computer_network != undefined) {
      if (computer_network.length == 1) {
        await db.collection('computer_network')
          .where({
            id: computer_network[0].id
          })
          .update({
            data: {
              hot: computer_network[0].hot + 1
            }
          })
          .then(res => {
            console.log('修改' + query_word + '热度成功')
            console.log(res)
          })
      }

    } else {
      computer_network = []
    }

  } else {
    /** 为该词热度+1 start **/
    if (idiom != undefined && idiom.length == 1) {
      await db.collection('idiom')
        .where({
          id: idiom[0].id
        })
        .update({
          data: {
            hot: idiom[0].hot + 1
          }
        })
        .then(res => {
          console.log('修改热度成功')
          console.log(res)
        })
    } else if (word.length > 1) {
      if (word.length == 1) {
        await db.collection('word')
          .where({
            id: word.id
          })
          .update({
            data: {
              hot: word['hot'] + 1
            }
          })
          .then(res => {
            console.log('修改热度成功')
            console.log(res)
          })
      }
    }
    /** 为该词热度+1 end **/
  }

  if (word == undefined) {
    word = []
  }

  if (idiom == undefined) {
    idiom = []
  }

  /** 该词是否存在近义词、反义词关系 start */

  if (idiom.length == 1) {
    // 定义一个数组存储接受一个查询结果
    var result
    await db.collection('word_similar_relation')
      .where(
        _.or([{
          word_id: idiom[0].id
        },
        {
          word: idiom[0].word
        },
        {
          similar_word_id: idiom[0].id
        }
        ]))
      .orderBy('correlation', 'desc')
      .get()
      .then(res => {
        console.log('获取关联词关系成功')
        result = res.data
      })
    var words = idiom.concat(result)
    console.log("idiom.length == 1")
  } else if (idiom.length > 1) {

    if (word != undefined) {
      idiom.unshift(word[0])
    }
    if (healthy != undefined || food_drink != undefined || mathematics_chemistry != undefined) {
      if (healthy.length > 0) {
        for (var i = 0; i < healthy.length; i++) {
          idiom.push(healthy[i])
        }
      }
      if (food_drink.length > 0) {
        for (var i = 0; i < food_drink.length; i++) {
          idiom.push(food_drink[i])
        }
      }
      if (mathematics_chemistry.length > 0) {
        for (var i = 0; i < mathematics_chemistry.length; i++) {
          idiom.push(mathematics_chemistry[i])
        }
      }
      if (cast.length > 0) {
        for (var i = 0; i < cast.length; i++) {
          idiom.push(cast[i])
        }
      }
      if (TV_Play.length > 0) {
        for (var i = 0; i < TV_Play.length; i++) {
          idiom.push(TV_Play[i])
        }
      }
      if (finance.length > 0) {
        for (var i = 0; i < TV_Play.length; i++) {
          idiom.push(TV_Play[i])
        }
      }
      if (sports.length > 0) {
        for (var i = 0; i < sports.length; i++) {
          idiom.push(sports[i])
        }
      }
      if (plant.length > 0) {
        for (var i = 0; i < plant.length; i++) {
          idiom.push(plant[i])
        }
      }
      if (zoom.length > 0) {
        for (var i = 0; i < zoom.length; i++) {
          idiom.push(zoom[i])
        }
      }
      if (Porridge_spectrum.length > 0) {
        for (var i = 0; i < Porridge_spectrum.length; i++) {
          idiom.push(Porridge_spectrum[i])
        }
      }
      if (Folk_prescription.length > 0) {
        for (var i = 0; i < Folk_prescription.length; i++) {
          idiom.push(Folk_prescription[i])
        }
      }
      if (Chinese_herbal_medicine.length > 0) {
        for (var i = 0; i < Chinese_herbal_medicine.length; i++) {
          idiom.push(Chinese_herbal_medicine[i])
        }
      }
      if (wine_method.length > 0) {
        for (var i = 0; i < wine_method.length; i++) {
          idiom.push(wine_method[i])
        }
      }
      if (computer_network.length > 0) {
        for (var i = 0; i < computer_network.length; i++) {
          idiom.push(computer_network[i])
        }
      }
    }
    var words = idiom
    console.log("idiom.length > 1")

  } else if (idiom.length == 0 || word.length == 0) {

    if (healthy.length > 0) {
      var words = healthy
    }
    if (food_drink.length > 0) {
      var words = food_drink
    }
    if (mathematics_chemistry.length > 0) {
      var words = mathematics_chemistry
    }
    if (finance.length > 0) {
      var words = finance
    }
    if (microbe.length > 0) {
      var words = microbe
    }
    if (movie.length > 0) {
      var words = movie
    }
    if (cast.length > 0) {
      var words = cast
    }
    if (TV_Play.length > 0) {
      var words = TV_Play
    }
    if (zoom.length > 0) {
      var words = zoom
    }
    if (plant.length > 0) {
      var words = plant
    }
    if (computer_network.length > 0) {
      var words = computer_network
    }
    if (Porridge_spectrum.length > 0) {
      var words = Porridge_spectrum
    }
    if (Folk_prescription.length > 0) {
      var words = Folk_prescription
    }
    if (wine_method.length > 0) {
      var words = wine_method
    }
    if (Chinese_herbal_medicine.length > 0) {
      var words = Chinese_herbal_medicine
    }
    if (famous_method.length > 0) {
      var words = famous_method
    }
    console.log("查询非成语or汉字")
  }

  /** 该词是否存在近义词关系 end */

  if (idiom.length == 0 && word.length == 0 && food_drink.length == 0 && healthy.length == 0 && mathematics_chemistry.length == 0 && finance.length == 0 && microbe.length == 0 && movie.length == 0 && cast.length == 0 && Porridge_spectrum.length == 0 && Folk_prescription.length == 0 && wine_method.length == 0 && TV_Play.length == 0 && famous_method.length == 0 && zoom.length == 0 && plant.length == 0 && Chinese_herbal_medicine.length == 0 && natural_astronomy) {
    var result = {}
    result.errCode = 4
    result.errMsg = '没有找到' + query_word.toString() + '，可以联系我添加'

    var data = {}
    data.word = words
    result.data = data
    return result
  } else {
    var result = {}
    result.errCode = 0
    result.errMsg = '查询成功'

    var data = {}
    data.word = words
    result.data = data
    return result
  }
}

async function querySimpleWord(db, query_id, query_type) {
  /** 传入必要参数 start*/
  if (query_id == undefined) {
    var result = {}
    result.errCode = 0
    result.errMsg = '未传入必要参数：id'
    var data = {}
    result.data = data
    return result
  }
  if (query_type == undefined) {
    var result = {}
    result.errCode = 0
    result.errMsg = '未传入必要参数：word_type'
    var data = {}
    result.data = data
    return result
  }
  /** 传入必要参数 end*/
  // 定义一个数组接受查询结果
  var detail = [];
  if (query_type == 1) {
    await db.collection('idiom')
      .where({
        id: query_id
      })
      .get()
      .then(res => {
        console.log("操作成功")
        console.log(res.data)
        detail = res.data
      })
    // 将时间格式转换
    for (let i = 0; i < detail.length; i++) {
      var date = new Date(detail[i].update_time);
      detail[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
      var date = new Date(detail[i].create_time);
      detail[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    }
  } else if (query_type == 2) {
    await db.collection('word')
      .where({
        id: query_id
      })
      .get()
      .then(res => {
        console.log("操作成功")
        console.log(res.data)
        detail = res.data
      })
    // 将时间格式转换
    for (let i = 0; i < detail.length; i++) {
      var date = new Date(detail[i].update_time);
      detail[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
      var date = new Date(detail[i].create_time);
      detail[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    }
  } else if (query_type == 3) {
    await db.collection('food_drink')
      .where({
        id: query_id
      })
      .get()
      .then(res => {
        console.log("操作成功")
        console.log(res.data)
        detail = res.data
      })
    // 将时间格式转换
    for (let i = 0; i < detail.length; i++) {
      var date = new Date(detail[i].update_time);
      detail[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
      var date = new Date(detail[i].create_time);
      detail[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    }
  } else if (query_type == 4) {
    await db.collection('healthy')
      .where({
        id: query_id
      })
      .get()
      .then(res => {
        console.log("操作成功")
        console.log(res.data)
        detail = res.data
      })
    // 将时间格式转换
    for (let i = 0; i < detail.length; i++) {
      var date = new Date(detail[i].update_time);
      detail[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
      var date = new Date(detail[i].create_time);
      detail[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    }
  } else if (query_type == 6) {
    await db.collection('mathematics_chemistry')
      .where({
        id: query_id
      })
      .get()
      .then(res => {
        console.log("操作成功")
        console.log(res.data)
        detail = res.data
      })
    // 将时间格式转换
    for (let i = 0; i < detail.length; i++) {
      var date = new Date(detail[i].update_time);
      detail[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
      var date = new Date(detail[i].create_time);
      detail[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    }
  }
  else if (query_type == 18) {
    await db.collection('movie')
      .where({
        id: query_id
      })
      .get()
      .then(res => {
        console.log("操作成功")
        console.log(res.data)
        detail = res.data
      })
    // 将时间格式转换
    for (let i = 0; i < detail.length; i++) {
      var date = new Date(detail[i].update_time);
      detail[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
      var date = new Date(detail[i].create_time);
      detail[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    }

  } else if (query_type == 19) {
    await db.collection('TV_Play')
      .where({
        id: query_id
      })
      .get()
      .then(res => {
        console.log("操作成功")
        console.log(res.data)
        detail = res.data
      })
    // 将时间格式转换
    for (let i = 0; i < detail.length; i++) {
      var date = new Date(detail[i].update_time);
      detail[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
      var date = new Date(detail[i].create_time);
      detail[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    }

  }
  else if (query_type == 20) {
    await db.collection('cast')
      .where({
        id: query_id
      })
      .get()
      .then(res => {
        console.log("操作成功")
        console.log(res.data)
        detail = res.data
      })
    // 将时间格式转换
    for (let i = 0; i < detail.length; i++) {
      var date = new Date(detail[i].update_time);
      detail[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
      var date = new Date(detail[i].create_time);
      detail[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    }
    
  }

  //返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '查询成功'

  var data = {}
  data.content = detail
  result.data = data
  return result
}