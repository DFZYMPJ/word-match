// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const db = cloud.database()
  switch (event.type) {
    case "match": {
      return randCast(db)
    }
    case "evaluation": {
      return evaluationCast(db, event, wxContext)
    }
    case "rank": {
      return rankCast(db, wxContext)
    }
    default: {
      var result = {}
      result.errCode = 3
      result.errMsg = '不合法的请求！'
      var data = {}
      data.ok = false
      result.data = data
      return result
    }
  }

}

async function randCast(db) {
  // 定义一个变量存储查詢结果
  var items = [];
  // 最大数量
  var MAX_LIMIT = 1

  // Randomize select two cast from database.
  var countResult = await db.collection('cast').count()
  console.log(Math.floor((Math.random() * (countResult.total - 1))))
  for (var i = 0; i < 2; i++) {
    await db.collection('cast')
      .skip(Math.floor((Math.random() * (countResult.total - 1))))
      .limit(MAX_LIMIT)
      .field({
        _id: true,
        id: true,
        avatar: true,
        word: true,
        winner: true,
        losser: true
      })
      .get()
      .then(res => {
        console.log(res.data)
        console.log('随机从数据库中获取两条记录')
        items = items.concat(res.data)
      })
  }

  var result = {}
  result.errCode = 0
  result.errMsg = '获取演员成功'
  var data = {}
  data.cast = items
  result.data = data
  return result
}

async function evaluationCast(db, event, wxContext) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  console.log(wxContext)
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  // 检测是否传了参数 start
  if (event.Sa == undefined || event.A_id == undefined || event.B_id == undefined) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未传必要参数，请重试'
    var data = {}
    data.ok == false
    result.data = data
    return result
    // 检测是否传了参数 end
  }
  /** 評價演算法 start **/
  // 定義一個變量存儲查詢結果
  var Ra;
  var Rb;
  // 输入比赛结果Sa（1为A赢，0为B赢，-1结束）
  var Sa = Number(event.Sa);

  var count_winner;
  var count_losser;
  if (Sa == 1) {
    await db.collection('cast')
      .where({
        _id: event.A_id
      })
      .get()
      .then(res => {
        console.log(res.data)
        Ra = res.data[0].scope
        count_winner = res.data[0].winner
      })
    await db.collection('cast')
      .where({
        _id: event.B_id
      })
      .get()
      .then(res => {
        console.log(res.data)
        Rb = res.data[0].scope
        count_losser = res.data[0].losser
      })
  } else {
    await db.collection('cast')
      .where({
        _id: event.A_id
      })
      .get()
      .then(res => {
        console.log(res.data)
        Ra = res.data[0].scope
        count_losser = res.data[0].losser
      })
    await db.collection('cast')
      .where({
        _id: event.B_id
      })
      .get()
      .then(res => {
        console.log(res.data)
        Rb = res.data[0].scope
        count_winner = res.data[0].winner
      })
  }
  // getExpectations
  var Ea = 1 / (1 + Math.pow(10, (Ra - Rb) / 400));
  var Eb = 1 / (1 + Math.pow(10, (Rb - Ra) / 400));
  /** 依據當前評價有贏面的期望值 */
  //  return computeScore
  var nRa = Ra + (10 * (Sa - Ea));
  var nRb = Rb + (10 * (Math.abs(Sa - 1) - Eb));
  /** 更新演員得分數 start */
  if (Sa == 1) {
    await db.collection('cast')
      .where({
        _id: event.A_id
      })
      .update({
        data: {
          scope: nRa,
          winner: count_winner + 1,
          update_time: new Date()
        }
      })
      .then(res => {
        console.log(res.data)
      })

    await db.collection('cast')
      .where({
        _id: event.B_id
      })
      .update({
        data: {
          scope: nRb,
          losser: count_losser + 1,
          update_time: new Date()
        }
      })
      .then(res => {
        console.log(res.data)
      })
  } else {
    await db.collection('cast')
      .where({
        _id: event.A_id
      })
      .update({
        data: {
          scope: nRa,
          losser: count_losser + 1,
          update_time: new Date()
        }
      })
      .then(res => {
        console.log(res.data)
      })

    await db.collection('cast')
      .where({
        _id: event.B_id
      })
      .update({
        data: {
          scope: nRb,
          winner: count_winner + 1,
          update_time: new Date()
        }
      })
      .then(res => {
        console.log(res.data)
      })
  }
  /** 更新演員得分數 end **/
  // 返回執行結果
  var result = {}
  result.errCode = 0
  result.errMsg = '評價成功！'
  var data = {}
  data.ok = true
  result.data = data
  return result
}

async function rankCast(db, wxContext) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  console.log(wxContext)
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  // 每次至多查询多少个演員
  const MAX_LIMIT = 10
  // 定义一个變量接受查询结果
  var items;
  const _ = db.command;
  await db.collection('cast')
    .where({
      scope: _.gt(1400)
    })
    .orderBy('scope', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      items = res.data
    })
  // 将时间格式转换
  for (let i = 0; i < items.length - 1; i++) {
    var date = new Date(items[i].update_time);
    items[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(items[i].create_time);
    items[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  var result = {}
  result.errCode = 0
  result.errMsg = '获取排行榜成功'
  var data = {}
  data.cast = items
  result.data = data
  return result

}