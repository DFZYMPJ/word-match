// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const db = cloud.database()
  switch (event.type) {
    case "get": {
      return getWeeklymovie(db)
    }
    case "detail": {

    }
  }
}

async function getWeeklymovie(db) {
  // 每次至多查詢多少個電影
  const MAX_LIMIT = 10
  // 定義一個數組接受查詢結果
  var recommend = []
  var wm = db.collection('Weekly_movies')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      recommend = res.data
    })

  // 返回執行結果
  var result = {}
  result.errCode = 0
  result.errMsg = '获取推薦電影成功'
  var data = {}
  data.recommend = recommend
  result.data = data
  console.log(data)
  return result
}