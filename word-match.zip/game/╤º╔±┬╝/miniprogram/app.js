//app.js
var plugin = requirePlugin("chatbot");
App({
  onLaunch: function () {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        // env 参数说明：
        //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
        //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
        //   如不填则使用默认环境（第一个创建的环境）
        // env: 'my-env-id',
        traceUser: true,
      })
      this.userinit(() => { })
      // 初始化智能对话系统
      plugin.init({
        appid: "yhzv2fy76wORax9NTqvXgiDacZR9cm",
        openid: wx.getStorageSync('openid'),
        guideList: ["噢，什么鬼", "他都做了什么？", "学神之子是谁？能吃吗？好吃吗？", "我要查他水表，怎么办？", "使用智能问答技能？", "学神录是什么？", "它有什么用？",],
        textToSpeech: 1,
        welcome: "请问有什么需要帮助？",
        welcomeImage: 'http://inews.gtimg.com/newsapp_bt/0/10701537095/1000',
        background: "rgba(247,251,252,1)",
        guideCardHeight: 40,
        operateCardHeight: 90,
        history: true,
        navHeight: 0,
        robotHeader: 'https://thegoddessforum.com/blogs/rebot.png',
        userHeader: wx.getStorageSync('avatarUrl'),
        userName: wx.getStorageSync('nickName'),
        anonymous: false,
        hideMovableButton: false,
        success: () => { }, //非必填
        fail: (error) => { }, //非必填
      });
    }

    this.globalData = {
      logged: false,
      userInfo: {},
      user: {},
      uid: null,
      openid: null,
      id: null,
      list: []
    }
  },
  Randomsend: function (min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },
  userinit(succ) {
    // 初始化用户加载
    let that = this;
    wx.cloud.callFunction({
      name: 'init',
      data: {
        id: that.Randomsend(1, 100000)
      }
    }).then(res => {
      console.log(res);
      that.globalData.id = res.result.id;
      that.globalData.list = res.result.list;
      succ();
    })
  }
})