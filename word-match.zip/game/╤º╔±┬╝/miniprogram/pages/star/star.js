// pages/star/star.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    person_A: '',
    person_B: '',
    word_A: '',
    word_B: '',
    winner_A: 0,
    winner_A: 0,
    losser_B: 0,
    losser_B: 0,
    A_id: '',
    B_id: '',
    nickname: ''
  },
  ranklist: function () {
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      wx.showModal({
        title: '提醒',
        content: '請先登陸~',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.navigateTo({
        url: '../ranklist/ranklist',
      })
    }
  },

  preview: function (e) {
    var image = e.currentTarget.dataset.image
    var that = this
    wx.previewImage({
      current: image,
      urls: [that.data.person_A, that.data.person_B],
    })
  },

  match: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'eol',
      data: {
        type: 'match'
      },
      success: res => {
        if (res.result.errCode == 0) {
          wx.showLoading({
            title: '請耐心等待',
          })
          console.log(res.result)
          that.setData({
            person_A: res.result.data.cast[0].avatar,
            person_B: res.result.data.cast[1].avatar,
            A_id: res.result.data.cast[0]._id,
            B_id: res.result.data.cast[1]._id,
            winner_A: res.result.data.cast[0].winner,
            losser_A: res.result.data.cast[0].losser,
            winner_B: res.result.data.cast[1].winner,
            losser_B: res.result.data.cast[1].losser,
            word_A: res.result.data.cast[0].word,
            word_B: res.result.data.cast[1].word
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [eol] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }, complete: res => {
        setTimeout(() => {
          wx.hideLoading({
            success: (res) => { },
          })
        }, 2000);
      }
    })
  },

  evaluation_a: function (e) {
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      wx.showModal({
        title: '提醒',
        content: '請先登陸~',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      var that = this
      // 调用云函数
      wx.cloud.callFunction({
        name: 'eol',
        data: {
          type: 'evaluation',
          A_id: that.data.A_id,
          B_id: that.data.B_id,
          Sa: 1
        },
        success: res => {
          if (res.result.errCode == 0) {
            wx.showLoading({
              title: '評價成功！',
              icon: 'success'
            })
            console.log("評價成功")
            that.match()
          } else {
            wx.showModal({
              title: '提醒',
              content: res.result.errMsg,
              confirmText: "我知道了",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }
        },
        fail: err => {
          console.error('[云函数] [eol] 调用失败', err)
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions',
          })
        },
        complete: res => {
          setTimeout(() => {
            wx.hideLoading()
          }, 2000);
        }
      })
    }
  },

  evaluation_b: function (e) {
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      wx.showModal({
        title: '提醒',
        content: '請先登陸~',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      var that = this
      // 调用云函数
      wx.cloud.callFunction({
        name: 'eol',
        data: {
          type: 'evaluation',
          A_id: that.data.A_id,
          B_id: that.data.B_id,
          Sa: 0
        },
        success: res => {
          if (res.result.errCode == 0) {
            console.log("評價成功")
            wx.showLoading({
              title: '評價成功！',
              icon: 'success'
            })
            that.match()
          } else {
            wx.showModal({
              title: '提醒',
              content: res.result.errMsg,
              confirmText: "我知道了",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }
        },
        fail: err => {
          console.error('[云函数] [eol] 调用失败', err)
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions',
          })
        },
        complete: res => {
          setTimeout(() => {
            wx.hideLoading()
          }, 1000);
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var userInfo = wx.getStorageSync('userInfo')
    this.setData({
      nickname: userInfo.nickName
    })
    this.match()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.match()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: '學神錄：' + this.data.nickName + "向你推荐！",
          imageUrl: "/images/gift_img.png"
        })
      }, 2000)
    })
    return {
      title: '學神錄：' + this.data.nickName + "向你推荐！",
      path: '/pages/star/star',
      imageUrl: "/images/gift_img.png",
      promise
    }
  },
  onShareAppMessage() {
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: '學神錄：' + this.data.nickName + "向你推荐！",
          imageUrl: "/images/gift_img.png",
        })
      }, 2000)
    })
    return {
      title: '學神錄：' + this.data.nickName + "向你推荐！",
      path: '/pages/star/star',
      promise
    }
  }
})