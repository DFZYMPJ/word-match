// pages/home/home.js

//获取应用实例
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    avatarUrl: "/images/avatar-unlogin.png",
    nickName: "未登录",
    user: {},
    uid: null,
    is_admin: false,
    userInfo: {},
    logged: false,
    total: 0,
    hot_words: [],
    serach_word: ""
  },

  management: function () {
    if (!this.data.logged) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.navigateTo({
        url: '../management/management',
      })
    }
  },

  bindKeyInput: function (e) {
    var input = e.detail.value;
    console.log("檢查輸入:" + input)
    this.setData({
      search_word: input
    })
  },

  search: function () {
    if (!this.data.logged) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else if (this.data.search_word == "") {
      wx.showModal({
        title: "提示",
        content: '輸入不能爲空~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      var that = this;
      wx.navigateTo({
        url: '../search/search?search_word=' + that.data.search_word,
        success(res) {
          res.eventChannel.emit('search', {
            search_word: that.data.search_word,
            uid: that.data.uid
          })
        }
      })
    }
  },

  query: function (e) {
    if (this.data.uid != null) {
      var that = this;
      var word = e.currentTarget.dataset.word

      if (this.data.uid == null) {
        wx.showModal({
          title: "提示",
          content: '請先登陸哦~',
          confimText: "我知道了",
          showCancel: false,
          success(res) {
            if (res.confirm) {
              console.log('用户点击确定')
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      } else {
        wx.navigateTo({
          url: '../search/search',
          success(res) {
            res.eventChannel.emit('search', {
              uid: that.data.uid,
              search_word: word,
            })
          }
        })
      }

    }
  },

  feedback: function () {
    if (!this.data.logged) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.navigateTo({
        url: '../feedback/feedback',
      })
    }
  },

  hot_words: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'get_words',
      data: {
        type: 'hot'
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            hot_words: res.result.data.hot_words
          })
          console.log(res.result.data.hot_words)
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [get_words] 调用失败', err)
        // wx.navigateTo({
        //   url: '../deployFunctions/deployFunctions',
        // })
      }
    })
  },

  words_total: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'get_words',
      data: {
        type: 'total'
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            total: res.result.data.total
          })
          console.log(res.result.data.total)
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [get_words] 调用失败', err)
        // wx.navigateTo({
        //   url: '../deployFunctions/deployFunctions',
        // })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    app.globalData.userInfo = wx.getStorageSync('userInfo')
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      this.setData({
        logged: false
      })
    } else {
      this.setData({
        logged: logged
      })
    }
    var uid = wx.getStorageSync('uid')
    this.setData({
      uid: uid
    })
    var is_admin = wx.getStorageSync('is_admin')
    var userInfo = wx.getStorageSync('userInfo')
    var logged = wx.getStorageSync('logged')
    if (logged) {
      this.setData({
        nickName: userInfo.nickName,
        avatarUrl: userInfo.avatarUrl,
        is_admin: is_admin
      })
    }
    if (!wx.cloud) {
      wx.showModal({
        title: '初始化失败',
        content: '请使用 2.2.3 或以上的基础库使用云能力',
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      return
    }
    if (!wx.getUserProfile) {
      this.setData({
        canIUseGetUserProfile: true,
      })
      this.getUserProfile();
    }
  },

  bindGetUserInfo(e) {
    console.log(e.detail.userInfo)
  },

  getUserProfile() {
    var that = this;
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认，开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (e) => {
        that.setData({
          avatarUrl: e.userInfo.avatarUrl,
          nickName: e.userInfo.nickName,
          userInfo: e.userInfo,
          hasUserInfo: true,
        })
        wx.setStorageSync('logged', true)
        wx.setStorageSync('userInfo', e.userInfo)
        wx.setStorageSync('avatarUrl', e.userInfo.avatarUrl)
        wx.setStorageSync('nickName', e.userInfo.nickName)
        app.globalData.userInfo = e.userInfo;
        this.onGetOpenid()
      }
    })
  },

  onGetUserInfo: function (e) {
    if (!app.globalData.logged && e.detail.userInfo) {
      this.setData({
        avatarUrl: e.userInfo.avatarUrl,
        nickname: e.userInfo.nickName,
        userInfo: e.userInfo,
        hasUserInfo: true
      })
      this.onGetOpenid()
    }
  },

  Randomsend: function (min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },

  onGetOpenid: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'wechat_sign',
      data: {
        avatarUrl: that.data.avatarUrl,
        gender: that.data.gender,
        nickName: that.data.nickName,
        uid: that.Randomsend(13, 100000)
      },
      success: res => {
        if (res.result.errCode == 0) {
          app.globalData.openid = res.result.data.openid
          wx.setStorageSync('openid', res.result.data.openid)
          wx.setStorageSync('logged', true)
          if (res.result.data.user.is_admin == 0) {
            that.setData({
              is_admin: false,
              logged: true
            })
            wx.setStorageSync('is_admin', false)
          } else {
            that.setData({
              is_admin: true,
              logged: true
            })
            wx.setStorageSync('is_admin', true)
          }
          wx.setStorageSync('uid', res.result.data.uid)
          var uid = res.result.data.uid
          var user = res.result.data.user
          console.log(user)
          app.globalData.uid = uid
          app.globalData.user = user
          app.globalData.logged = true

        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [wechat_sign] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    // var eventChannel = that.getOpenerEventChannel()
    // eventChannel.on('key_word', function (data) {

    //   that.setData({
    //     search_word: data.key_word
    //   })
    //   that.search()
    // })
    this.hot_words()
    this.words_total()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自也页面内转发按钮
      console.log(res.target)
      const promise = new Promise(resolve => {
        setTimeout(() => {
          resolve({
            title: this.data.nickname + "向你推荐！",
            imageUrl: "/images/tool.png"
          })
        }, 2000)
      })
      return {
        title: this.data.nickName + "向你推荐！",
        path: "/pages/home/home",
        imageUrl: "/images/tool.png",
        success: function (res) {}
      }
    }
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: '學神錄：' + this.data.nickName + "向你推荐！",
          imageUrl: "/images/gift_img.png"
        })
      }, 2000)
    })
    return {
      title: '學神錄：' + this.data.nickName + "向你推荐！",
      path: "/pages/home/home",
      imageUrl: "/images/gift_img.png",
      promise
    }
  },
  onShareAppMessage() {
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: '學神錄：' + this.data.nickName + "向你推荐！",
          imageUrl: "/images/gift_img.png",
        })
      }, 2000)
    })
    return {
      title: '學神錄：' + this.data.nickName + "向你推荐！",
      path: '/pages/home/home',
      promise
    }
  }
})