// pages/bookEdit/bookEdit.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isShowDel: true,
    isShowSave: true,
    author: '',
    tags: [],
    book_count: 0,
    cover_url: '',
    title: '',
    origin_price: 0,
    price: 0,
    isbn: 0,
    comments: []
  },
  Save: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'book',
      data: {
        type: 'join',
        isbn: Number(that.data.isbn),
        book_count: that.data.book_count,
        price: that.data.price
      },
      success: res => {
        wx.showLoading({
          title: '請耐心等待',
        })
        console.log(res.result)
        if (res.result.errCode == 0) {
          wx.navigateBack({
            delta: 1
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [book] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {
        setTimeout(() => {
          wx.hideLoading({
            success: (res) => {},
          })
        }, 2000);
      }
    })
  },
  Del: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'book',
      data: {
        type: 'renove',
        isbn: Number(that.data.isbn)
      },
      success: res => {
        wx.showLoading({
          title: '請耐心等待',
        })
        console.log(res.result)
        if (res.result.errCode == 0) {
          wx.navigateBack({
            delta: 1
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [book] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {
        setTimeout(() => {
          wx.hideLoading({
            success: (res) => {},
          })
        }, 2000);
      }
    })
  },
  book_count: function (event) {
    this.setData({
      book_count: event.detail
    })
  },
  price: function (event) {
    this.setData({
      price: event.detail
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      isbn: options.isbn,
    })
    if (options.type == 'join') {
      this.setData({
        isShowDel: false,
        isShowSave: true
      })
    } else {
      this.setData({
        isShowDel: true,
        isShowSave: true
      })
    }
    var that = this
    wx.cloud.callFunction({
      name: 'book',
      data: {
        type: 'view',
        isbn: Number(that.data.isbn)
      },
      success: res => {
        wx.showLoading({
          title: '請耐心等待',
        })
        console.log(res.result)
        if (res.result.errCode == 0) {
          that.setData({
            cover_url: res.result.data.book[0].cover_url,
            title: res.result.data.book[0].word,
            author: res.result.data.book[0].bookinfo.作者,
            isbn: res.result.data.book[0].id,
            origin_price: res.result.data.book[0].bookinfo.定价,
            tags: res.result.data.book[0].labels
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [book] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {
        setTimeout(() => {
          wx.hideLoading({
            success: (res) => {},
          })
        }, 2000);
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})