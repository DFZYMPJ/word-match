// pages/release/release.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    islock_realname: false,
    islock_birthday: false,
    array: ["男生", "女生", "其他"],
    index: 0,
    isShowPic: false,
    fileID: "",
    realname: null,
    nickname: null,
    birthday: null,
    motto: null,
    address: null,
    password: null,
    message: '无话可说就不要去掉这句话',
    introduction: null,
    isAgreen: false,
    showModalStatus: false,
    release: 'add',
    id: null,
    Q_A: [{
      question: '',
      answer: ''
    }]
  },
  bindKeyInputQuestion: function (e) {
    var index = e.currentTarget.dataset.idx
    this.data.Q_A[index].question = e.detail.value
    this.setData({
      Q_A: this.data.Q_A
    })
  },
  bindKeyInputAnswer: function (e) {
    var index = e.currentTarget.dataset.idx
    this.data.Q_A[index].answer = e.detail.value
    this.setData({
      Q_A: this.data.Q_A
    })
  },
  push: function (e) {
    var add_data = {
      question: '',
      answer: ''
    }
    var new_data = this.data.Q_A.concat(add_data)
    this.setData({
      Q_A: new_data
    })
  },
  pop: function (e) {
    var index = this.data.Q_A
    var new_data = this.data.Q_A.slice(0, index.length - 1)
    this.setData({
      Q_A: new_data
    })
  },
  powerDrawer: function (e) {
    var currentStatu = e.currentTarget.dataset.statu
    if (currentStatu == 'open') {
      this.setData({
        showModalStatus: true
      })
    } else {
      this.setData({
        showModalStatus: false
      })
    }
  },
  yes: function (e) {
    this.setData({
      isAgreen: true
    })
  },
  islock_birthday: function (e) {
    console.log(e.detail.value)
    if (e.detail.value == true) {
      this.setData({
        islock_birthday: 1
      })
    } else {
      this.setData({
        islock_birthday: 0
      })
    }
  },
  islock_realname: function (e) {
    console.log(e.detail.value)
    if (e.detail.value == true) {
      this.setData({
        islock_realname: 1
      })
    } else {
      this.setData({
        islock_realname: 0
      })
    }
  },
  bindKeyInputRealname: function (e) {
    console.log(e.detail.value)
    this.setData({
      realname: e.detail.value
    })
  },
  bindKeyInputNickname: function (e) {
    console.log(e.detail.value)
    this.setData({
      nickname: e.detail.value
    })
  },
  bindPickerChangeGender: function (e) {
    console.log(e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  bindKeyInputBirthday: function (e) {
    console.log(e.detail.value)
    this.setData({
      birthday: e.detail.value
    })
  },
  bindBlurBirthday: function () {
    var patt1 = new RegExp("^[0-9]{4}(\/|-)[0-9]{1,2}(\/|-)[0-9]{1,2}$", 'i');
    if (!patt1.test(this.data.birthday)) {
      console.log('不符合规则')
      wx.showModal({
        title: '提醒',
        content: '不符合规则:^[0-9]{4}(\/|-)[0-9]{1,2}(\/|-)[0-9]{1,2}$',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  },
  bindKeyInputMotto: function (e) {
    console.log(e.detail.value)
    this.setData({
      motto: e.detail.value
    })
  },
  bindKeyInputAddress: function (e) {
    console.log(e.detail.value)
    this.setData({
      address: e.detail.value
    })
  },
  bindKeyInputPassword: function (e) {
    console.log(e.detail.value)
    this.setData({
      password: e.detail.value
    })
  },
  bindKeyInputIntroduction: function (e) {
    console.log(e.detail.value)
    this.setData({
      introduction: e.detail.value
    })
  },
  bindKeyInputMessage: function (e) {
    console.log(e.detail.value)
    this.setData({
      message: e.detail.value
    })
  },
  // 上传图片
  doUpload: function (e) {
    var that = this
    // 选择图片
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        const filePath = res.tempFilePaths[0]
        wx.showLoading({
          title: '上传中',
        })
        that.setData({
          isShowPic: false
        })
        // 上传图片
        var timestamp = new Date().getTime()
        const cloudPath = timestamp + filePath.match(/\.[^.]+?$/)[0]
        console.log("filePath:", filePath, "cloudPath:", cloudPath);
        wx.cloud.uploadFile({
          cloudPath,
          filePath,
          success: res => {
            console.log('[上传文件]成功：', res)
            that.setData({
              isShowPic: true,
              fileID: res.fileID,
              cloudPath: res.cloudPath
            })
          },
          fail: error => {
            console.error('[上传文件]失败', error)
            wx.showToast({
              icon: 'none',
              title: '上传失败',
            })
          },
          complete: () => {
            wx.hideLoading({
              success: (res) => {
                console.log('upload image complete')
              },
            })
          }
        })
      },
      fail: e => {
        console.error(e)
      }
    })
  },
  Randomsend: function (min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },
  completeClick: function (e) {
    if (this.data.isAgreen) {
      var that = this
      // 调用云函数
      wx.cloud.callFunction({
        name: 'ddnote',
        data: {
          type: 'edit',
          realname: that.data.realname,
          nickname: that.data.nickname,
          index: that.data.gender,
          birthday: that.data.birthday,
          motto: that.data.motto,
          address: that.data.address,
          password: that.data.password,
          message: that.data.message,
          introduction: that.data.introduction,
          islock_birthday: that.data.islock_birthday,
          islock_realname: that.data.islock_realname,
          picture_url: that.data.fileID,
          id: that.data.id,
          Q_A:that.data.Q_A
        },
        success: res => {
          if (res.result.errCode == 0) {
            console.log("更新完成")
            wx.showModal({
              title: '恭喜！',
              content: res.result.errMsg,
              confirmText: "確定",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                  wx.navigateBack({
                    delta: 1,
                  })
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          } else {
            wx.showModal({
              title: '提醒',
              content: res.result.errMsg,
              confirmText: "我知道了",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }
        },
        fail: err => {
          console.error('[云函数] [ddnote] 调用失败', err)
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions',
          })
        }
      })
    } else {
      wx.showModal({
        title: '提醒',
        content: '勾選同意同學錄内容規則',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  },
  submitClick: function (e) {
    if (this.data.isAgreen) {
      var that = this
      // 调用云函数
      wx.cloud.callFunction({
        name: 'ddnote',
        data: {
          type: 'add',
          realname: that.data.realname,
          nickname: that.data.nickname,
          gender: that.data.index,
          birthday: that.data.birthday,
          motto: that.data.motto,
          address: that.data.address,
          password: that.data.password,
          message: that.data.message,
          introduction: that.data.introduction,
          islock_birthday: that.data.islock_birthday,
          islock_realname: that.data.islock_realname,
          picture_url: that.data.fileID,
          id: that.Randomsend(1, 100000),
          Q_A:that.data.Q_A
        },
        success: res => {
          if (res.result.errCode == 0) {
            console.log("發佈成功")
            wx.showModal({
              title: '恭喜！',
              content: res.result.errMsg,
              confirmText: "確定",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                  wx.navigateBack({
                    delta: 1,
                  })
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          } else {
            wx.showModal({
              title: '提醒',
              content: res.result.errMsg,
              confirmText: "我知道了",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }
        },
        fail: err => {
          console.error('[云函数] [wechat_sign] 调用失败', err)
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions',
          })
        }
      })
    } else {
      wx.showModal({
        title: '提醒',
        content: '勾選同意同學錄内容規則',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }


  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var eventChannel = this.getOpenerEventChannel();
    eventChannel.on('edit', function (data) {
      wx.setNavigationBarTitle({
        title: '编辑同学录',
      })
      that.setData({
        release: 'edit',
        isShowPic: true,
        id: data.id,
        realname: data.realname,
        nickname: data.nickname,
        index: data.gender,
        birthday: data.birthday,
        motto: data.motto,
        address: data.address,
        password: data.password,
        introduction: data.introduction,
        islock_birthday: data.islock_birthday,
        islock_realname: data.islock_realname,
        fileID: data.picture_url,
        Q_A: data.Q_A
      })
      if (data.message == '无话可说就不要去掉这句话') {
        that.setData({
          message: '无话可说就不要去掉这句话'
        })
      } else {
        that.setData({
          message: data.message
        })
      }
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})