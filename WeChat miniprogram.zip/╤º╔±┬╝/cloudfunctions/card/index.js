// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const db = cloud.database()
  switch (event.type) {
    case "search": {
      return searchCard(db, event, wxContext)
    }
    default: {
      return
    }
  }
}

async function searchCard(db, event, wxContext) {
  /** 检测用户的openid start*/
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  /** 检测是否传入参数 start **/
  if (event.query_word == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/
  //声明一个mess，用于承载函数执行结果用于返回
  var mess = {};
  try {
    //利用数据库where查找，数据集中openid为用户所属的文档
    const userdata = (await db.collection('list').where({
      openid: wxContext.OPENID
    }).get()).data;

    //如果length不等于0，则证明存在用户所属文档
    if (userdata.length != 0) {
      // 声明一个数组
      var cardList = []
      for (var i = 0; i < userdata[0].list.length; i++) {
        if (userdata[0].list[i].name == event.query_word || userdata[0].list[i].company == event.query_word || userdata[0].list[i].mobile == event.query_word || userdata[0].list[i].en_name == event.query_word) {
          cardList = cardList.concat(userdata[0].list[i])
        }
      }
      //将用户的识别列表读取出来
      mess.list = cardList;
      //将文档id取出，用于小程序端上传图片时的文件夹命名。由于安全性，不可以将openid传给小程序端
      mess.id = userdata[0]._id;
      //正常标志code=0
      mess.code = 0;
    }
    //如果length等于0，则没有用户文档需要创建
    else {
      //将用户的识别列表读取出来
      mess.list = [];
      //将文档id取出，用于小程序端上传图片时的文件夹命名。由于安全性，不可以将openid传给小程序端
      mess.id = userdata[0]._id;
      //正常标志code=0
      mess.code = 0;
    }
  } catch (e) {
    //当发生错误时，如解构FileID等，将执行此代码段，code=-1为异常
    console.log(e);
    mess.code = -1;
    mess.err = e;
  }
  //返回mess给前端
  return mess;

}