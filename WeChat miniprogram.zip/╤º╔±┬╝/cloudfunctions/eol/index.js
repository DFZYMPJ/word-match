// 云函数入口文件
const cloud = require('wx-server-sdk')

//云开发初始化
cloud.init();

//将云开发数据库能力声明给db
const db = cloud.database();

//将云开发数据库command能力声明给 _
const _ = db.command;

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  switch (event.type) {
    case "mash": {
      return AvatarMash(db, event)
    }
    case "match": {
      return randCast(db, event)
    }
    case "evaluation": {
      return evaluationCast(db, event, wxContext)
    }
    case "rank": {
      return rankCast(db, event, wxContext, _)
    }
    default: {
      var result = {}
      result.errCode = 3
      result.errMsg = '不合法的请求！'
      var data = {}
      data.ok = false
      result.data = data
      return result
    }
  }

}
/**
 * 云函数：获取一个评分低于赢面的演员
 * 用途：根据性别，随机获取集合中该性别的演员数据
 */
async function AvatarMash(db, event) {
  // 定义一个变量存储查詢结果
  var items;
  // 最大数量
  var MAX_LIMIT = 1

  // Randomize select two cast from database.
  var countResult = await db.collection('cast').count()
  console.log(Math.floor((Math.random() * (countResult.total - 1))))
  await db.collection('cast')
    .where({
      gender: event.gender
    })
    .orderBy('scope', 'desc')
    .skip(Math.floor((Math.random() * (900 - 1))))
    .limit(MAX_LIMIT)
    .field({
      _id: true,
      id: true,
      avatar: true,
      word: true,
      winner: true,
      losser: true
    })
    .get()
    .then(res => {
      console.log(res.data)
      console.log('随机从数据库中获取两条记录')
      items = res.data
    })

  var result = {}
  result.errCode = 0
  result.errMsg = '获取演员成功'
  var data = {}
  data.cast = items
  result.data = data
  return result
}
/**
 * 云函数：随机搭配演员
 * 用途：根据性别，随机获取集合中该性别的演员数据
 */
async function randCast(db, event) {
  // 定义一个变量存储查詢结果
  var items = [];
  // 最大数量
  var MAX_LIMIT = 1

  // Randomize select two cast from database.
  var countResult = await db.collection('cast').count()
  console.log(Math.floor((Math.random() * (countResult.total - 1))))
  for (var i = 0; i < 2; i++) {
    await db.collection('cast')
      .where({
        gender: event.gender
      })
      .orderBy('create_time', 'desc')
      .skip(Math.floor((Math.random() * (300 - 1))))
      .limit(MAX_LIMIT)
      .field({
        _id: true,
        id: true,
        avatar: true,
        word: true,
        winner: true,
        losser: true
      })
      .get()
      .then(res => {
        console.log(res.data)
        console.log('随机从数据库中获取两条记录')
        items = items.concat(res.data)
      })
  }

  var result = {}
  result.errCode = 0
  result.errMsg = '获取演员成功'
  var data = {}
  data.cast = items
  result.data = data
  return result
}
/**
 * 云函数：评价演员
 * 用途：根据用户的评价，根据eol算法计算期望值
 */
async function evaluationCast(db, event, wxContext) {
  // /** 检测用户的openid start*/
  // console.log("获取用户微信信息成功")
  // console.log(wxContext)
  // if (wxContext.OPENID == undefined) {
  //   // 返回执行结果
  //   var result = {}
  //   result.errCode = 1
  //   result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
  //   var data = {}
  //   result.data = data
  //   return result
  // }
  // /** 检测用户的openid end*/
  // 检测是否传了参数 start
  if (event.Sa == undefined || event.A_id == undefined || event.B_id == undefined) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未传必要参数，请重试'
    var data = {}
    data.ok == false
    result.data = data
    return result
    // 检测是否传了参数 end
  }
  /** 評價演算法 start **/
  // 定義一個變量存儲查詢結果
  var Ra;
  var Rb;
  // 输入比赛结果Sa（1为A赢，0为B赢，-1结束）
  var Sa = Number(event.Sa);

  var count_winner;
  var count_losser;
  if (Sa == 1) {
    await db.collection('cast')
      .where({
        _id: event.A_id
      })
      .get()
      .then(res => {
        console.log(res.data)
        Ra = res.data[0].scope
        count_winner = res.data[0].winner
      })
    await db.collection('cast')
      .where({
        _id: event.B_id
      })
      .get()
      .then(res => {
        console.log(res.data)
        Rb = res.data[0].scope
        count_losser = res.data[0].losser
      })
  } else {
    await db.collection('cast')
      .where({
        _id: event.A_id
      })
      .get()
      .then(res => {
        console.log(res.data)
        Ra = res.data[0].scope
        count_losser = res.data[0].losser
      })
    await db.collection('cast')
      .where({
        _id: event.B_id
      })
      .get()
      .then(res => {
        console.log(res.data)
        Rb = res.data[0].scope
        count_winner = res.data[0].winner
      })
  }
  // getExpectations
  var Ea = 1 / (1 + Math.pow(10, (Ra - Rb) / 400));
  var Eb = 1 / (1 + Math.pow(10, (Rb - Ra) / 400));
  /** 依據當前評價有贏面的期望值 */
  //  return computeScore
  var nRa = Ra + (10 * (Sa - Ea));
  var nRb = Rb + (10 * (Math.abs(Sa - 1) - Eb));
  /** 更新演員得分數 start */
  if (Sa == 1) {
    await db.collection('cast')
      .where({
        _id: event.A_id
      })
      .update({
        data: {
          scope: nRa,
          winner: count_winner + 1,
          update_time: new Date()
        }
      })
      .then(res => {
        console.log(res.data)
      })

    await db.collection('cast')
      .where({
        _id: event.B_id
      })
      .update({
        data: {
          scope: nRb,
          losser: count_losser + 1,
          update_time: new Date()
        }
      })
      .then(res => {
        console.log(res.data)
      })
  } else {
    await db.collection('cast')
      .where({
        _id: event.A_id
      })
      .update({
        data: {
          scope: nRa,
          losser: count_losser + 1,
          update_time: new Date()
        }
      })
      .then(res => {
        console.log(res.data)
      })

    await db.collection('cast')
      .where({
        _id: event.B_id
      })
      .update({
        data: {
          scope: nRb,
          winner: count_winner + 1,
          update_time: new Date()
        }
      })
      .then(res => {
        console.log(res.data)
      })
  }
  /** 更新演員得分數 end **/
  // 返回執行結果
  var result = {}
  result.errCode = 0
  result.errMsg = '評價成功！'
  var data = {}
  data.ok = true
  result.data = data
  return result
}
/**
 * 云函数：排行榜
 * 用途：根据评分按照从大到小的方式，返回排名前十的演员数据
 */
async function rankCast(db, event, wxContext, _) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  console.log(wxContext)
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  // 检测是否传了参数 start
  if (event.gender == undefined) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未传必要参数，请重试'
    var data = {}
    data.ok == false
    result.data = data
    return result
    // 检测是否传了参数 end
  }
  // 每次至多查询多少个演員
  const MAX_LIMIT = 10
  // 定义一个變量接受查询结果
  var items = [];
  // 定义一个数组变量接收查询结果
  var imagelist = [];
  for (var i = 0; i < MAX_LIMIT; i++) {
    await db.collection('cast')
      .where({
        gender: event.gender,
        scope: _.gt(1400)
      })
      .orderBy('scope', 'desc')
      .skip(i)
      .limit(MAX_LIMIT)
      .get()
      .then(res => {
        console.log('获取top10的明星操作成功')
        console.log(res.data)
        items = items.concat(res.data[i])
        imagelist = imagelist.concat(res.data[i].avatar)

      })
  }
  console.log(imagelist)
  // 将时间格式转换
  for (let i = 0; i < items.length - 1; i++) {
    var date = new Date(items[i].update_time);
    items[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(items[i].create_time);
    items[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  var result = {}
  result.errCode = 0
  result.errMsg = '获取排行榜成功'
  var data = {}
  data.cast = items
  data.list = imagelist
  result.data = data
  return result

}