// pages/game/ganme.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    jielong_num: 0,
    rawWord: [{ word: "游戏未开始！" }],
    isShowStart: true,
    isShowInput: false,
    showModalStatus: false,
    sendIcon: "",
    enter_word: "",
    total: 0,
    nickName:''
  },
  jielong: function () {

  },

  customer: function () {
    if (!wx.getStorageSync('logged')) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.navigateTo({
        url: '../customer_service/customer_service',
      })
    }
  },

  jielongKeyInput: function (e) {
    var enter_word = e.detail.value
    this.setData({
      enter_word: enter_word
    })
  },

  send: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'api',
      data: {
        type: 'verify',
        enter_word: that.data.enter_word,
        raw_word: that.data.rawWord[0].word
      },
      success: res => {
        if (res.result.errCode == 0) {
          if (res.result.data.win == false) {
            var jielong_num = that.data.jielong_num + 1
            that.setData({
              jielong_num: jielong_num,
              rawWord: res.result.data.word,
              enter_word: ""
            })
          } else {
            wx.showModal({
              title: "恭喜",
              content: '系統都被你打敗了，牛皮！',
              confimText: "確定",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }
        } else {
          console.log(res.result.data.firstword)
          console.log(res.result.data.wholeword)
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [api] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  powerDrawer: function (e) {
    var currentStatu = e.currentTarget.dataset.statu
    if (currentStatu == 'open') {
      this.setData({
        showModalStatus: true
      })
    } else {
      this.setData({
        showModalStatus: false
      })
    }
  },

  start: function (e) {
    var that = this
    wx.cloud.callFunction({
      name: 'api',
      data: {
        type: 'start'
      },
      success: res => {
        if (res.result.errCode == 0) {
          console.log(res.result.data.idiom[0].word)
          that.setData({
            isShowStart: false,
            isShowInput: true,
            rawWord: res.result.data.idiom
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [api] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.cloud.callFunction({
      name: 'get_words',
      data: {
        type: 'total'
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            total: res.result.data.total
          })
          console.log(res.result.data.total)
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [get_words] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: '学神录：' + this.data.nickName + "向你推荐！",
          imageUrl: "/images/game_page.png",
        })
      }, 2000)
    })
    return {
      title: '学神录：' + this.data.nickName + "向你推荐！",
      path: '/pages/home/home',
      promise
    }
  }
})

