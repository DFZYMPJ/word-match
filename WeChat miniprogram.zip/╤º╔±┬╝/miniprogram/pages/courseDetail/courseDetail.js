// pages/courseDetail/courseDetail.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */

  data: {
    id: '',
    course_id: 0,
    course_cover: '',
    course_name: '',
    price: 0,
    user_list: [{
      _id: '2121',
      avatar: '../../images/0.jpg',
      name: '张运鹏',
      number: '201850130636'
    }, {
      _id: '2121',
      avatar: '../../images/0.jpg',
      name: '张运鹏',
      number: '201850130636'
    }, {
      _id: '2121',
      avatar: '../../images/0.jpg',
      name: '张运鹏',
      number: '201850130636'
    }],
    course_QA: [],
    click: 0,
    isJoin: false,
    isTeacher: false
  },

  chooseCourse: function () {
    if (this.data.click == 0) {
      this.setData({
        click: 1
      })
      this.joinCourse(() => {}, this.data.id, this.data.course_id)
    }
  },

  joinCourse: function (succ, id, course_id) {
    var that = this
    wx.cloud.callFunction({
      name: 'courseMatch',
      data: {
        type: 'join',
        id: id,
        course_id: course_id
      }
    }).then(res => {
      console.log(res)
      if (res.result.errCode == 0) {
        wx.showToast({
          title: '課程加入成功',
        })
        setTimeout(() => {
          wx.hideToast({
            success: (res) => {},
          })
        }, 2000);
        that.setData({
          click: 0,
          isJoin: true
        })
      }
    })

    succ()
  },

  viewCourse: function (succ, id, course_id) {
    var that = this
    wx.cloud.callFunction({
      name: 'courseMatch',
      data: {
        type: 'view',
        id: id,
        course_id: course_id
      }
    }).then(res => {
      console.log(res)
      if (res.result.errCode == 0) {
        wx.showToast({
          title: '获取选课情况',
        })
        setTimeout(() => {
          wx.hideToast({
            success: (res) => {},
          })
        }, 2000);
        that.setData({
          isJoin: res.result.data.isJoin,
          user_list:res.result.data.userlist
        })
      }
    })

    succ()
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    that.setData({
      id: options.id
    })
    if (options.id == app.globalData.courseMatchID) {
      that.setData({
        isTeacher: true
      })
    }
    const eventChannel = this.getOpenerEventChannel()
    // 监听courseMatch事件，获取上一页面通过eventChannel传送到当前页面的数据
    eventChannel.on('courseMatch', function (data) {
      console.log(data)
      that.setData({
        course_cover: data.cover,
        course_name: data.name,
        course_QA: data.Q_A,
        price: data.price,
        course_id: data.id
      })
      that.viewCourse(() => {}, that.data.id, that.data.course_id)
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})