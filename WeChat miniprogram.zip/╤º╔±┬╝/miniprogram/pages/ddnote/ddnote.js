// pages/ddnote/ddnote.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ddnote: [],
    logged: false,
    imagelist: []
  },

  question: function (e) {
    var that = this;
    wx.navigateTo({
      url: '../about/about',
      success(res) {
        res.eventChannel.emit('ddnote', {})
      }
    })
  },

  preview: function (e) {
    var image = e.currentTarget.dataset.image
    wx.previewImage({
      current: image, // 当前显示图片的http链接
      urls: this.data.imagelist // 需要预览的图片http链接列表
    })
  },

  content: function (e) {
    var id = e.currentTarget.dataset.id
    if (!this.data.logged) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.navigateTo({
        url: '/pages/content/content?id=' + id,
      })
    }

  },
  
  release: function (e) {
    if (!this.data.logged) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.navigateTo({
        url: '/pages/release/release',
      })
    }

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.startPullDownRefresh()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      this.setData({
        logged: false
      })
    } else {
      this.setData({
        logged: logged
      })
    }
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'ddnote',
      data: {
        type: 'get'
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            ddnote: res.result.data.dd,
            imagelist: res.result.data.imagelist
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [ddnote] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {
        
        wx.stopPullDownRefresh()
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'ddnote',
      data: {
        type: 'get'
      },
      success: res => {
        wx.showLoading({
          title: '請耐心等待',
        })
        if (res.result.errCode == 0) {
          that.setData({
            ddnote: res.result.data.dd,
            imagelist: res.result.data.imagelist
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [ddnote] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {
        setTimeout(function () {
          wx.hideLoading()
        }, 2000)
      }
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})