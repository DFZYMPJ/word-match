// pages/wordList/wordList.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    query_word: '',
    word_list: [{
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }, {
      word: 'blue'
    }]
  },
  
  join: function (e) {
    var word = e.currentTarget.dataset.word
    wx.navigateTo({
      url: '/pages/studyCard/studyCard?english=' + word,
    })
  },

  find: function () {
    var that = this
    if (that.data.query_word != '') {
      wx.cloud.callFunction({
        name: 'query_word',
        data: {
          type: 'find',
          query_word: that.data.query_word,
          lesson: wx.getStorageSync('lesson')
        },
        success: res => {
          wx.showToast({
            title: ' 搜索中...',
          })
          if (res.result.errCode == 0) {
            that.setData({
              word_list: res.result.data.query_result
            })
          } else {
            wx.showModal({
              title: '提醒',
              content: res.result.errMsg,
              confirmText: "我知道了",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }
        },
        fail: err => {
          console.error('[云函数] [query_word] 调用失败', err)
          // wx.navigateTo({
          //   url: '../deployFunctions/deployFunctions',
          // })
        }, complete: res => {
          setTimeout(() => {
            wx.hideToast({
              success: (res) => { },
            })
          }, 3000);
        }
      })
    } else {
      that.EnWord()
    }
  },

  bindKeyInput: function (e) {
    this.setData({
      query_word: e.detail.value
    })
  },

  EnWord: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'get_words',
      data: {
        type: 'en',
        lesson: wx.getStorageSync('lesson'),
        skip: 0
      },
      success: res => {
        wx.showToast({
          title: '请求成功',
        })
        if (res.result.errCode == 0) {
          that.setData({
            word_list: res.result.data.word_list
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [get_words] 调用失败', err)
        // wx.navigateTo({
        //   url: '../deployFunctions/deployFunctions',
        // })
      }, complete: res => {
        setTimeout(() => {
          wx.hideToast({
            success: (res) => { },
          })
        }, 3000);
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.EnWord()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})