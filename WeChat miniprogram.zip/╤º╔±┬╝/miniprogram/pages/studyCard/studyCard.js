// pages/studyCard/studyCard.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    release: 'add',
    array: ["名词", "动词", "形容词", "副词", "不及物动词", "不及物动词"],
    posIndex: 0,
    isShowPic: false,
    fileID: "",
    english: '',
    T_C: [{
      nlppos: 0,
      chinese: ''
    }]
  },

  push: function (e) {
    var add_data = {
      nlppos: 0,
      chinese: ''
    }
    var new_data = this.data.T_C.concat(add_data)
    this.setData({
      T_C: new_data
    })
    console.log(this.data.T_C)
  },

  pop: function (e) {
    var index = this.data.T_C
    var new_data = this.data.T_C.slice(0, index.length - 1)
    this.setData({
      T_C: new_data
    })
  },

  bindKeyInputChinese: function (e) {
    var index = e.currentTarget.dataset.idx
    this.data.T_C[index].chinese = e.detail.value
    this.setData({
      T_C: this.data.T_C
    })
  },

  bindPickerChangeNlppos: function (e) {
    var index = e.currentTarget.dataset.idx
    this.data.T_C[index].nlppos = e.detail.value
    console.log(e.detail.value)
    this.setData({
      T_C: this.data.T_C
    })
  },
  // 上传图片
  doUpload: function (e) {
    let that = this;
    if (app.globalData.id == null) {
      wx.showToast({
        title: '初始化未完成，请稍后再试',
        icon: 'none'
      });
      return;
    }
    // 选择图片
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        wx.showLoading({
          title: '上传文件',
        })
        const filePath = res.tempFilePaths[0]
        that.setData({
          isShowPic: false
        })
        // 上传图片
        let cloudPath = `card/${app.globalData.id}/${Date.now()}-${Math.floor(Math.random(0, 1) * 1000)}.png`;
        console.log("filePath:", filePath, "cloudPath:", cloudPath);
        wx.cloud.uploadFile({
          cloudPath,
          filePath: filePath,
        }).then(res => {
          if (res.statusCode < 300) {
            that.setData({
              isShowPic: true,
              fileID: res.fileID,
              cloudPath: res.cloudPath
            },
              () => {
                that.scanCard()
              })
          }
        }).catch(err => {
          console.log(err)
          wx.hideLoading()
          wx.showToast({
            title: '上传失败',
            icon: 'none'
          })
        })
      },
      fail: e => {
        console.error(e)
      }
    })
  },
  submitClick: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'word_card',
      data: {
        type: 'add',
        lesson: wx.getStorageSync('lesson'),
        cover: that.data.fileID,
        english: that.data.english,
        translation: that.data.T_C
      },
      success: res => {
        wx.showToast({
          title: '请求成功',
        })
        if (res.result.errCode == 0) {
          that.setData({
            wordcard_id: res.result.data.wordcard_id
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [Word_Card] 调用失败', err)
        // wx.navigateTo({
        //   url: '../deployFunctions/deployFunctions',
        // })
      }, complete: res => {
        setTimeout(() => {
          wx.hideToast({
            success: (res) => { },
          })
        }, 3000);
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    this.setData({
      english: options.english
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})