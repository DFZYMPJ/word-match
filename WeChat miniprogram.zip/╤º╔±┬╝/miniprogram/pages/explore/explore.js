// pages/explore/explore.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    logged: false,
    collection: [{
      name: "周周看",
      icon: "../../images/weekly.png",
      url: "/pages/weekly/weekly"
    }, {
      name: "玩玩看",
      icon: "../../images/game.png",
      url: "/pages/star/star"
    }, {
      name: "扫扫看",
      icon: "../../images/scanCode.png",
      url: "/pages/index/index"
    }, {
      name: "学学看",
      icon: "../../images/study.png",
      url: "/pages/study/study"
    }, {
      name: "选选看",
      icon: "../../images/course.png",
      url: "/pages/courseMatch/index?tab=index"
    }]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      this.setData({
        logged: false
      })
    } else {
      this.setData({
        logged: logged
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})