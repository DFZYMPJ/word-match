// pages/userinfo/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    avatarUrl: '',
    nickName: '',
    logged: false,
    userInfo: {
      realName: '',
      studentID: 5201314,
      phoneNumber: ''
    },
    click: 0
  },

  bindKeyInputRealName: function (e) {
    this.setData({
      userInfo: {
        realName: e.detail.value,
        phoneNumber: this.data.userInfo.phoneNumber,
        studentID: this.data.userInfo.studentID
      },
    })
  },

  bindKeyInputStudentID: function (e) {
    this.setData({
      userInfo: {
        realName: this.data.userInfo.realName,
        phoneNumber: this.data.userInfo.phoneNumber,
        studentID: e.detail.value
      },
    })
  },

  getUserInfo: function (succ) {
    var that = this
    wx.cloud.callFunction({
      name: 'courseMatch',
      data: {
        type: 'info'
      }
    }).then(res => {
      console.log(res)
      if (res.result.data.userInfo == []) {
        wx.showToast({
          title: '暂时没有信息',
          icon: 'error'
        })
      } else {
        that.setData({
          userInfo: res.result.data.userInfo[0]
        })
        wx.showToast({
          title: res.result.errMsg,
        })
      }
      setTimeout(() => {
        wx.hideToast({
          success: (res) => { },
        })
      }, 2000);
      succ()
    })
  },

  updateUserInfo: function (succ, userInfo) {
    var that = this
    wx.cloud.callFunction({
      name: 'courseMatch',
      data: {
        type: 'update',
        userInfo: userInfo
      }
    }).then(res => {
      console.log(res)
      wx.showToast({
        title: '请耐心等待',
        icon: 'loadding'
      })
      if (res.result.data.errCode != 0) {
        wx.showToast({
          title: '修改失败',
          icon: 'error'
        })
      } else {
        this.setData({
          click: 0
        })
        wx.showToast({
          title: res.result.errMsg,
          icon: 'success'
        })
      }
      setTimeout(() => {
        wx.hideToast({
          success: (res) => { },
        })
      }, 2000);
    })
    succ()
  },

  sure: function () {
    if (click == 0) {
      this.setData({
        click: 1
      })
      this.updateUserInfo(() => { }, this.data.userInfo)
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      this.setData({
        logged: false
      })
    } else {
      this.setData({
        logged: logged
      })
    }
    var userInfo = wx.getStorageSync('userInfo')
    var logged = wx.getStorageSync('logged')
    console.log(userInfo)
    if (logged) {
      this.setData({
        nickName: userInfo.nickName,
        avatarUrl: userInfo.avatarUrl,
        userInfo: {
          realName: userInfo.nickName,
          phoneNumber: this.data.userInfo.phoneNumber,
          studentID: this.data.userInfo.studentID
        },
      })
      this.getUserInfo(() => { })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    this.updateUserInfo(() => { }, this.data.userInfo)
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})