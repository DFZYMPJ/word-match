//获取应用实例
const app = getApp()

Page({

  data: {
    loading: true,
    value: null,
    search_empty: false,
    list: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
  },

  onChange(e) {
    this.setData({
      value: e.detail,
    });
  },

  onClick() {
    var that = this
    that.setData({
      search_empty: true
    })
    if (that.data.value != '') {
      // 调用云函数
      wx.cloud.callFunction({
        name: 'card',
        data: {
          type: 'search',
          query_word: that.data.value
        },
        success: res => {
          wx.showToast({
            title: ' 搜索中...',
          })
          if (res.result.code == 0) {
            that.setData({
              list: res.result.list,
              id: res.result.id
            })
          } else {
            wx.showModal({
              title: '提醒',
              content: res.result.err,
              confirmText: "我知道了",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }
        },
        fail: err => {
          console.error('[云函数] [book] 调用失败', err)
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions',
          })
        },
        complete: res => {
          setTimeout(() => {
            wx.hideToast({})
          }, 2000)
        }
      })
    } else {
      that.myBook()
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getData();
  },
  onReady: function () {
    setTimeout(() => {
      this.setData({
        loading: false
      })
    }, 5000)
  },
  uploadCard: function () {
    var that = this
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      wx.showModal({
        title: '提醒',
        content: '請先登陸~',
        confirmText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.chooseImage({
        success: function (dRes) {
          wx.showLoading({
            title: '上传文件',
          })
          let cloudPath = `list/${app.globalData.id}/${Date.now()}-${Math.floor(Math.random(0, 1) * 1000)}.png`;

          /*【开始】=====================【代码实战位置A-1】=====================【开始】*/
          console.log(dRes.tempFilePaths[0])
          wx.cloud.uploadFile({
            cloudPath,
            filePath: dRes.tempFilePaths[0],
          }).then(res => {
            if (res.statusCode < 300) {

              that.setData({
                fileID: res.fileID
              },
                () => {
                  that.scanCard()
                })
            }
          }).catch(err => {
            console.log(err)
            wx.hideLoading()
            wx.showToast({
              title: '上传失败',
              icon: 'none'
            })
          })
          /*【结束】=====================【代码实战位置A-1】=====================【结束】*/
        },
        fail: err => {
          console.error('上傳失敗：', err)
        }
      })
    }
  },
  /**
   *   preview: function (e) {
    var image = e.currentTarget.dataset.image
    wx.previewImage({
      current: image, // 当前显示图片的http链接
      urls: [image] // 需要预览的图片http链接列表
    })
  },
   * 获取文章列表数据
   */
  getData() {
    let that = this;
    app.userinit(() => {
      that.setData({
        list: app.globalData.list
      })
    });
  },
  /**
   * 跳转至名片详情
   */
  getDetail(e) {
    wx.navigateTo({
      url: '../cardDetail/detail?i=' + e.currentTarget.dataset.i,
    })
  }
})