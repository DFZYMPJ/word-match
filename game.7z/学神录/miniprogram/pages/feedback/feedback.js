// pages/feedback/feedback.js
// 获取应用实例
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    content: "",
    index: 0,
    wechatNo: "",
    email: "",
    fileID: "",
    isShowPic: false,
    array: ['增加词语', '加入我们', '商务合作', '其他', 'BUG'],
    templateId: ""
  },
  
  bindTextArea: function (e) {
    console.log(e.detail.value)
    this.setData({
      content: e.detail.value
    })
  },

  bindKeyInputWechat: function (e) {
    console.log(e.detail.value)
    this.setData({
      wechatNo: e.detail.value
    })
  },

  bindKeyInputEmail: function (e) {
    this.setData({
      email: e.detail.value
    })
  },

  submitClick: function (e) {
    var that = this
    if (this.data.content == "") {
      wx.showModal({
        title: "提示",
        content: '反馈成功',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.requestSubscribeMessage({
        tmplIds: [that.data.templateId],
        success: (res) => {
          if (res[that.data.templateId] === 'accept') {
            console.log('成功')
          } else {
            console.log(`失败(${res[that.data.templateId]})`)
          }
        },
        fail: (err) => {
          console.log(`失败（${JSON.stringify(err)}）`)
        },
        complete: function(){
          that.add_feedback()
        }
      })
    }
  },

  add_feedback:function(){
    var that = this
    console.log(Number(that.data.index) + 1)
          console.log(app.globalData.userInfo.nickName)
          // 调用云函数
          wx.cloud.callFunction({
            name: 'feedbacks',
            data: {
              name:"add",
              nickName: app.globalData.userInfo.nickName,
              content: that.data.content,
              wechat_account:that.data.wechatNo,
              email: that.data.email,
              type: Number(that.data.index) + 1,
              picture_url: that.data.fileID
            },
            success: res => {
              if (res.result.errCode == 0) {
                wx.showModal({
                  title: '提醒',
                  content: '反馈成功！',
                  confirmText: "我知道了",
                  showCancel: false,
                  success(res) {
                    if (res.confirm) {
                      console.log('用户点击确定')
                    } else if (res.cancel) {
                      console.log('用户点击取消')
                    }
                  }
                })
                wx.navigateBack({
                  delta: 1,
                })
              } else {
                wx.showModal({
                  title: '抱歉，出错了呢~',
                  content: res.result.errMsg,
                  confirmText: "我知道了",
                  showCancel: false,
                  success(res) {
                    if (res.confirm) {
                      console.log('用户点击确定')
                    } else if (res.cancel) {
                      console.log('用户点击取消')
                    }
                  }
                })
              }
            },
            fail: err => {
              console.error('[云函数] [add_feedback] 调用失败', err)
              wx.navigateTo({
                url: '../deployFunctions/deployFunctions',
              })
            }
          })
  },
  
  // 上传图片
  doUpload: function (e) {
    var that = this
    // 选择图片
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        const filePath = res.tempFilePaths[0]
        wx.showLoading({
          title: '上传中',
        })
        that.setData({
          isShowPic: false
        })
        // 上传图片
        var timestamp = new Date().getTime()
        const cloudPath = timestamp + filePath.match(/\.[^.]+?$/)[0]
        console.log("filePath:", filePath, "cloudPath:", cloudPath);
        wx.cloud.uploadFile({
          cloudPath,
          filePath,
          success: res => {
            console.log('[上传文件]成功：', res)
            that.setData({
              isShowPic: true,
              fileID: res.fileID,
              cloudPath: res.cloudPath
            })
          },
          fail: error => {
            console.error('[上传文件]失败', error)
            wx.showToast({
              icon: 'none',
              title: '上传失败',
            })
          },
          complete: () => {
            wx.hideLoading({
              success: (res) => {
                console.log('upload image complete')
              },
            })
          }
        })
      }, fail: e => {
        console.error(e)
      }
    })
  },

  bindPickerChange: function (e) {
    this.setData({
      index: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.cloud.callFunction({
      name: 'getSubscribeMessageTemplate',
      data: {
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            templateId: res.result.data.templateId
          })
          console.log(res.result.data.templateId)
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [getSubscribeMessageTemplate] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    if (res.from === 'button') {
      // 来自也页面内转发按钮
      console.log(res.target)
    }
    var userInfo = wx.getStorageSync('userInfo')
    return {
      title: userInfo.nickName + "向你推荐！",
      path: "/pages/home/home",
      imageUrl: "/images/gift_img.png",
      success: function (res) { }
    }
  }
})