// pages/detail/detail.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    uid: null,
    id: null,
    hot: 10,
    is_like: false,
    pinyin: "yī xīn yī yì",
    word: "一心一意",
    explanation: "只有一个心眼儿，没有别的考虑。",
    derivation: "《三国志·魏志·杜恕传》免为庶人，徙章武郡，是岁嘉平元年。”裴松之注引《杜氏新书》故推一心，任一意，直而行之耳。",
    example: "所以彭官保便～的料理防守事宜，庄制军便～料理军需器械。★清·张春帆《宦海》第四回",
    heart: 1,
    update_time: null
  },

  search: function () {
    if (this.data.uid == undefined) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else if (this.data.search_word == "") {
      wx.showModal({
        title: "提示",
        content: '輸入不能爲空~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      var that = this;

      wx.navigateBack({
        delta: 1,
        success(res) {
          console.log("返回上一页")
          var eventChannel = that.getOpenerEventChannel()
          eventChannel.emit('search_word', {
            search_word: that.data.word
          })
        }
      })
    }
  },

  bindKeyInput: function (e) {
    var input = e.detail.value;
    console.log("檢查輸入:" + input)
    this.setData({
      search_word: input
    })
  },

  nolike: function () {
    var uid = this.data.uid
    var word_id = this.data.id
    var heart = this.data.heart + 1
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'like',
      data: {
        type: "del",
        uid: uid,
        word_id: word_id
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            is_like: true,
            heart: heart
          })
        } else {
          wx.showModal({
            title: '抱歉，出错了呢~',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [like] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  like: function () {
    var uid = this.data.uid
    var word_id = this.data.id
    var heart = this.data.heart - 1
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'like',
      data: {
        type: "del",
        uid: uid,
        word_id: word_id
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            is_like: false,
            heart: heart
          })
        } else {
          wx.showModal({
            title: '抱歉，出错了呢~',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [like] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  query: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'query_word',
      data: {
        type: 'simple',
        query_id: this.data.id
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            word: res.result.data.content[0].word,
            id: res.result.data.content[0].id,
            pinyin: res.result.data.content[0].pinyin,
            derivation: res.result.data.content[0].derivation,
            example: res.result.data.content[0].example,
            explanation: res.result.data.content[0].explanation,
            update_time: res.result.data.content[0].update_time,
            hot: res.result.data.content[0].hot
          })
          console.log(res.result.data.content[0].word)
        } else {

          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [query_word] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var eventChannel = this.getOpenerEventChannel();
    eventChannel.on('detail', function (data) {
      console.log(data.uid);
      that.setData({
        id: data.id,
        uid: data.uid,
        word: data.word,
        pinyin: data.pinyin,
        explanation: data.explanation,
        example: data.example,
        derivation: data.derivation,
        hot: data.hot,
        update_time: data.update_time,
        search_word: ""
      })
    })
    eventChannel.on('more', function (data) {
      console.log(data.uid);
      that.setData({
        id: data.id,
        uid: data.uid,
      })
      that.query()
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this

  },
  thumb: function () {
    var that = this // 调用云函数
    wx.cloud.callFunction({
      name: 'like',
      data: {
        type: "add",
        uid: that.data.uid,
        word_id: that.data.id,
      },
      success: res => {
        if (res.result.errCode == 0) {
          wx.setStorageSync('is_like', res.result.data.is_like)
          that.setData({
            is_like: res.result.data.is_like
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自也页面内转发按钮
      console.log(res.target)
      return {
        title: "学神录",
        path: "/pages/detail/detail",
        imageUrl: "/images/feedback_page.png",
        success: function (res) { }
      }
    }
  }
})