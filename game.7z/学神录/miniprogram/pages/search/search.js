// pages/search/search.js
// 获取应用实例
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    search_word: "",
    similar_words: [],
    uid: null
  },
  loveClick: function (e) {
    console.log(e)
    var id = e.target.id;
    var idx = e.target.dataset.idx
    if (this.data.similar_words[idx].isClick) {
      wx.showModal({
        title: "提示",
        content: '您已经点过赞辣，不能更赞~~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      var tmp_click = "similar_word[" + idx + "].isClick";
      var tem_correlation = "similar_words[" + idx + "].tem_correlation";
      this.setData({
        [tem_click]: true,
        [tmp_correlation]: (this.data.similar_words[idx].correlation + 1)
      })
      wx.showModal({
        title: "恭喜",
        content: '点赞成功~~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  },

  more: function (e) {
    if (this.data.uid != null) {
      var that = this;
      var id = e.currentTarget.dataset.id
      var uid = that.data.uid
      if (this.data.uid == null) {
        wx.showModal({
          title: "提示",
          content: '請先登陸哦~',
          confimText: "我知道了",
          showCancel: false,
          success(res) {
            if (res.confirm) {
              console.log('用户点击确定')
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      } else {
        wx.navigateTo({
          url: '../detail/detail?id=' + id,
          success(res) {
            res.eventChannel.emit('more', {
              id: id,
              uid: that.data.uid
            })
          }
        })
      }
    }
  },
  search: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'query_word',
      data: {
        type: 'similar',
        query_word: this.data.search_word
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            similar_words: res.result.data.word.similar_words
          })
          console.log(res.result.data.word.similar_words)
        } else {
          that.setData({
            similar_words: []
          })
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [query_words] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  bindKeyInput: function (e) {
    var input = e.detail.value;
    console.log("檢查輸入:" + input)
    this.setData({
      search_word: input
    })
  },

  feedback: function () {
    if (this.data.logged) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.navigateTo({
        url: '../feedback/feedback',
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var eventChannel = this.getOpenerEventChannel();
    eventChannel.on('search', function (data) {
      console.log(data.search_word);
      that.setData({
        search_word: data.search_word,
        uid: data.uid
      })
      console.log(data.uid)
      that.search()
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    var eventChannel = that.getOpenerEventChannel()
    eventChannel.on('search_word', function (data) {
      console.log(data.search_word);
      that.setData({
        search_word: data.search_word
      })
      that.search()
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    var that = this
    var eventChannel = that.getOpenerEventChannel()
    eventChannel.emit('key_word',{
      key_word:that.data.search_word
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自也页面内转发按钮
      console.log(res.target)
      return {
        title: "学神录：我正在搜索"+ this.data.search_word,
        path: "/pages/feedback/feedback",
        imageUrl: "/images/feedback_page.png",
        success: function (res) { }
      }
    }
  }
})