// 云函数入口文件
const cloud = require('wx-server-sdk')

// 初始化 cloud
cloud.init({
  // API 调用都保持和云函数当前所在环境一致
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 云函数入口函数
exports.main = async (event, context) => {
  // 实例化数据库连接
  const db = cloud.database()
  var type = event.type
  switch (type) {
    case "hot": {
      return getHotWords(db)
    }
    case "total": {
      return getWordsTotal(db)
    }
    default: {
      return
    }
  }
}
async function getHotWords(db) {
  // 每次至多查询多少个热词
  const MAX_LIMIT = 6
  // 定义一个数组接受查询结果
  var hot_words;
  /** 查找热词 */
  await db.collection('dictionary')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      hot_words = res.data

    })
  // 将时间格式转换
  for (let i = 0; i < hot_words.length; i++) {
    var date = new Date(hot_words[i].update_time);
    hot_words[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(hot_words[i].create_time);
    hot_words[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  var result = {}
  result.errCode = 0
  result.errMsg = '获取热词成功'
  var data = {}
  data.hot_words = hot_words
  result.data = data
  console.log(data)
  return result
}
async function getWordsTotal(db) {
  // 定義一個變量存儲集合的總數
  const count = await db.collection('dictionary').count()
  var result = {}
  result.errCode = 0
  result.errMsg = 0
  var data = {}
  data.total = count.total
  result.data = data
  console.log(result)
  return result
}