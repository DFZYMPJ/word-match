// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  // 实例化数据库
  const db = cloud.database()

  switch (event.type) {
    case "start": {
      return randWord(db)
    }
    case "verify": {
      return verifyWord(db, event.raw_word, event.enter_word)
    }
    default: {
      var result = {}
      result.errCode = 2
      result.errMsg = '不合法的请求！'
      var data = {}
      data.ok = false
      result.data = data
      return result
    }
  }
}

async function randWord(db) {
  // 定义一个变量存储成语
  var idiom = [];
  // 最大数量
  var MAX_LIMIT = 1

  // Randomize select a word from database.
  var count = await db.collection('dictionary').count()
  console.log(Math.floor((Math.random() * (count.total - 1))))
  await db.collection('dictionary')
    .skip(Math.floor((Math.random() * (count.total - 1))))
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log(res.data)
      console.log('随机从数据库中获取成语')
      idiom = res.data
    })
  var result = {}
  result.errCode = 0
  result.errMsg = '成功获取成语'
  var data = {}
  data.idiom = idiom
  result.data = data
  return result

}

async function verifyWord(db, raw_word, enter_word) {
  /** 校验是否存在参数 start **/
  var raw_word = raw_word.toString();
  var enter_word = enter_word.toString();
  if (raw_word == undefined || enter_word == undefined) {
    var result = {}
    result.errCode = 3
    result.errMsg = '你没有提供成语！'
    var data = {}
    data.ok = false
    result.data = data
    return result
  }
  /** 校验是否存在参数 end **/
  // Verify the word and provide a new word.
  // var patt1 = new RegExp("[\\u4e00-\\u9fa5-zA-Z]", 'i');
  // if (!patt1.test(enter_word)) {
   
  // }
  if (enter_word.length != 4) {
    var result = {}
    result.errCode = 1
    result.errMsg = '输入成语必须是四个字'
    var data = {}
    data.ok = false
    result.data = data
    return result
  }

  console.log(enter_word)
  /** 判断输入成语在字典中是否存在 start **/
  var word = await db.collection('dictionary')
    .where({
      word: enter_word
    })
    .get()
    .then(res => {
      console.log('查找字典')
    })
  if (word != 0) {
    console.log(enter_word.substring(0, 1))
    console.log(raw_word.substring(3, 4))
    if (raw_word.substring(3, 4) == enter_word.substring(0, 1)) {
      /** 系统是否匹配得到提交成语最后一个字的接龙成语的数量 */
      var count_of_words = await db.collection("dictionary")
        .where({
          wholeword: enter_word.substring(3, 4)
        }).count()
      console.log(count_of_words.total)
      if (count_of_words.total > 1) {
        // 限制最大次数为1
        const MAX_LIMIT = 1
        // 定义一个变量存储新成语
        var new_word = [];
        await db.collection("dictionary")
          .where({
            firstword: enter_word.substring(3, 4)
          })
          .limit(MAX_LIMIT)
          .get()
          .then(res => {
            console.log("继续游戏")
            console.log(res)
            new_word = res.data
          })
        var result = {}
        result.errCode = 0
        result.errMsg = '匹配到有效成语！'
        var data = {}
        data.ok = true
        data.word = new_word
        data.win = false
        result.data = data
        return result
      } else {
        var result = {}
        result.errCode = 0
        result.errMsg = '匹配到有效成语！'
        var data = {}
        data.ok = true
        data.word = null
        data.win = true
        result.data = data
        return result
      }
    } else {
      var result = {}
      result.errCode = 4
      result.errMsg = '新成语首字和提交成语最后一字不相同！'
      var data = {}
      data.ok = false
      data.firstword = enter_word.substring(0, 1)
      data.wholeword = raw_word.substring(3, 4)
      result.data = data
      return result
    }
  }
  /** 判断输入成语在字典中是否存在 start **/
  else {
    var result = {}
    result.errCode = 1
    result.errMsg = '成语不存在!'
    var data = {}
    data.ok = false
    result.data = data
    return result
  }

}