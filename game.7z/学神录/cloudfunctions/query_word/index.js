// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {

  // 实例化数据库连接
  const db = cloud.database()
  switch (event.type) {
    case "similar": {
      return querySimilarWord(db, event.query_word);
    }
    case "simple": {
      return querySimpleWord(db, event.query_id);
    }
    default: {
      return
    }
  }
}

async function querySimilarWord(db, query_word) {
  /** 传递必要的参数 start **/
  if (query_word == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '为传递参数，请重试'

    var data = {}
    result.data = data
    return result
  }

  /** 是否存在该词 start **/
  var word;
  await db.collection('dictionary')
    .where({
      word: query_word
    })
    .field({
      _id: false,
      id: true,
      hot: true
    })
    .get()
    .then(res => {
      console.log('查询成功')
      word = res.data[0]
    })
  console.log(word)
  /** 是否存在该词 end **/
  if (word == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 3
    result.errMsg = '不存在该词,可联系我们添加'

    var data = {}
    result.data = data
    return result
  }
  else {
    /** 为该词热度+1 start **/
    await db.collection('dictionary')
      .where({
        id: word.id
      })
      .update({
        data: {
          hot: word['hot'] + 1
        }
      })
      .then(res => {
        console.log('修改热度成功')
        console.log(res)
      })
    /** 为该词热度+1 end **/

  }
  // 定义查询指令
  const _ = db.command
  /** 该词是否存在近义词、反义词关系 start */
  await db.collection('word_similar_relation')
    .where(
      _.or([{
        word_id: word.id
      },
      {
        similar_word_id: word.id
      }]))
    .orderBy('correlation', 'desc')
    .get()
    .then(res => {
      console.log('获取关联词关系成功')
      console.log(res.data)
      word.similar_words = res.data
    })

  // 将时间格式转换
  for (let i = 0; i < word.length; i++) {
    var date = new Date(word[i].similar_words.create_time);
    word[i].similar_words.create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  /** 该词是否存在近义词关系 end */
  if (word.similar_words.length == 0) {
    var result = {}
    result.errCode = 4
    result.errMsg = '不存在该词的关联词，可以联系我添加'

    var data = {}
    data.word = word
    result.data = data
    return result
  } else {
    var result = {}
    result.errCode = 0
    result.errMsg = '查询成功'

    var data = {}
    data.word = word
    result.data = data
    return result
  }
}

async function querySimpleWord(db, query_id) {
  /** 传入必要参数 start*/
  if (query_id == undefined) {
    var result = {}
    result.errCode = 0
    result.errMsg = '未传入必要参数：id'
    var data = {}
    result.data = data
    return result
  }
  /** 传入必要参数 end*/
  // 定义一个数组接受查询结果
  var detail = [];
  await db.collection('dictionary')
    .where({
      id: query_id
    })
    .get()
    .then(res => {
      console.log("操作成功")
      console.log(res.data)
      detail = res.data
    })
  //返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '查询成功'

  var data = {}
  data.content = detail
  result.data = data
  return result
}