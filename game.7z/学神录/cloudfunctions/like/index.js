// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  /** 检测用户是否登陆 start**/
  const wxContext = cloud.getWXContext()
  if (wxContext.OPENID == undefined) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未登录，操作失败'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户是否登陆 end**/

  /** 检测是否传入了参数 start **/
  if (event.type == undefined) {
    var result = {}
    result.errCode = 1
    result.errMsg = '未传入参数，请重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入了参数 end **/
  // 实例化数据
  const db = cloud.database()

  switch (event.type) {
    case "add": {
      return addLike(db, event.uid, event.word_id)
    }
    case "del": {
      return delLike(db, event.uid, event.word_id)
    }
    case "total": {
      return totalLike(db, event.word_id)
    }
    case "is": {
      return isLike(db, event.uid, event.word_id)
    }
    case "query": {
      return
    }
    default: {
      return
    }
  }
}

async function addLike(db, uid, word_id) {
  /** 是否传入必要参数 start **/
  if (uid == undefined || word_ == undefined) {
    var result = {}
    result.errCode = 3
    result.errMsg = '未传入必要参数：uid or word_id'
    var data = {}
    result.data = data
    return result
  }
  /** 是否传入必要参数 end **/
  //构建要添加的参数
  const to_add_data = {
    uid: uid,
    word_id: word_id,
    is_like: true,
    create_time: new Date(),
    update_time: new Date()
  }
  // 新增数据
  var add_result = {}
  await db.collection('like')
    .add({
      data: to_add_data
    })
  then(res => {
    console.log("点赞成功")
    console.log(res)
    add_result = res.data
  })
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '操作成功'
  var data = {}
  result.data = add_result
  return result
}

async function delLike(db, word_id) {
  /** 检测是否传入必要参数 start */
  if (word_id == undefined) {
    var result = {}
    result.errCode = 3
    result.errMsg = '未传入必要参数：word_id'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入必要参数 end **/
  // 更新数据
  await db.collection("like")
    .where({
      uid: uid,
      word_id: word_id
    })
    .update({
      data: {
        is_like: false
      }
    })
    .then(res => {
      console.log("取消点赞")
      console.log(res)
    })
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '操作成功'
  var data = {}
  result.data = data
  return result
}
async function totalLike(db, word_id) {
  /** 检测是否传入必要参数 start */
  if (word_id == undefined) {
    var result = {}
    result.errCode = 3
    result.errMsg = '未传入必要参数：word_id'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入必要参数 end **/
  // 定义一个变量存储该词的点赞量
  const count = await db.collection("like")
    .where({
      word_id: word_id,
      is_like: true
    })
    .count()
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '成功获取点赞量'
  var data = {}
  data.total = count.total
  result.data = data
  return result
}
async function isLike(db, uid, word_id) {
  /** 是否传入必要参数 start **/
  if (uid == undefined || word_ == undefined) {
    var result = {}
    result.errCode = 3
    result.errMsg = '未传入必要参数：uid or word_id'
    var data = {}
    result.data = data
    return result
  }
  /** 是否传入必要参数 end **/
  // 定义一个变量存储点赞的状态
  const status;
  await db.collection('like')
  .where({
    uid:uid,
    word_id:word_id
  })
  .fied({
    is_like:true
  })
  .get()
  .then( res => {
    console.log('获取该词的的点赞状态')
    console.log(res)
    status = res.data.is_like
  })
  // 返回执行结果
  var result = {}
    result.errCode = 0
    result.errMsg = '成功获取状态'
    var data = {}
    data.status = status
    result.data = data
    return result
}