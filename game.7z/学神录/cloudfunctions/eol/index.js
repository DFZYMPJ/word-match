// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  /*
  評價演算法
  */
  var Ra = event.Ra;
  var Rb = event.Rb;
  var Sa = event.Sa;
  computeScore(Ra,Rb,Sa);// 输入比赛结果（1为A赢，0为B赢，-1结束）

  return {
    event,
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
  }
}

async function getExpectations(Ra,Rb){
  return 1 / (1+Math.pow(10,(Ra-Rb)/400));
}
async function computeScore(Ra,Rb,Sa){
  var Ea = getExpectations(Ra,Ra);
  var Eb = getExpectations(Rb,Rb);
  var nRa = Ra + 10*(Sa - Ea);
  var nRb = Rb + 10*(Math.abs(Sa-1) - Eb);
}