# -*- coding: utf-8 -*-

"""

author: pwxcoo
date: 2018-02-05 
description: 抓取下载成语并保存

"""

import requests,csv,random,math,time,re
from bs4 import BeautifulSoup

def downloader(url):
    """
    下载成语并保存
    """
    response = requests.get(url)

    if response.status_code != 200:
        print(f'{url} is failed!')
        return
    
    print(f'{url} is parsing')
    html = BeautifulSoup(response.content.decode('gbk', errors='ignore'), "lxml")
    table = html.find_all('table')[-2]

    prefix = 'http://www.zd9999.com'
    words = [prefix + a.get('href') for a in table.find_all('a')]
    href = [a.get('href') for a in table.find_all('a')]
    #定义一个数组接收返回的json数据
    res = []
    
    for i in range(0, len(words)):
        response = requests.get(words[i])
        print(f'{[words[i]]} is parsing')
        if response.status_code != 200:
            print(f'{words[i]} is failed!')
            continue

        wordhtml = BeautifulSoup(response.content.decode('gbk', errors='ignore'), "lxml")
        explanation = wordhtml.find_all('table')[-3].find_all('tr')
        idiom = explanation[0].text.strip()
        idx = re.sub(r'\D',"",href[i])
        res.append({'id':idx[1:],\
                    'word':explanation[0].text.strip(),\
                    'pinyin': explanation[1].find_all('tr')[0].find_all('td')[1].text.strip(),\
                    'explanation': explanation[1].find_all('tr')[1].find_all('td')[1].text.strip(),\
                    'derivation': explanation[1].find_all('tr')[2].find_all('td')[1].text.strip(),\
                    'example': explanation[1].find_all('tr')[3].find_all('td')[1].text.strip(),\
                    'firstword':idiom[0:1],\
                    'wholeword':idiom[-1],\
                    'hot':0,\
                    'word_type':1,\
                    'create_time':time.time(),\
                    'update_time':time.time()
                    })
    return res

if __name__ == '__main__':
    res = downloader('http://www.zd9999.com/cy/')
    headers = ('id','word','pinyin','explanation','derivation','example','firstword','wholeword','hot','word_type','create_time','update_time')
    for i in range(2,198):
        res += downloader(f'http://www.zd9999.com/cy/index_{i}.htm')
    print(len(res))
    with open("C:\dictionary.csv",'w+',encoding='utf-8',newline='') as fp:
        # csv.DictWriter指定需要写入的文件和表头,并未写入表头
        writer = csv.DictWriter(fp,headers)
        # .writeheader写入表头
        writer.writeheader()
        # .writerows写入多行
        writer.writerows(res)

