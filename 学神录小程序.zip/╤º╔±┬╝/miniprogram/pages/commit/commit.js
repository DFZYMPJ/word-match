// pages/commit/commit.js
var that = null
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    detail: "",
    username: '111',
    face_url: '../../images/course.png',
    comment:'',
    user_id: 0,
    gender: 1,
    pages: ''
  },
  bindTextArea: function (e) {
    this.setData({
      detail: e.detail.value
    })
    console.log(this.data.detail)
  },

  commit: function () {
    that = this
    wx.showLoading({
      title: '加载中',
    })
    console.log(wx.getStorageSync('user_id'))
    console.log(wx.getStorageSync('password'))
    wx.request({
      url: app.globalData.server + '/Hi_Buluo/index.php/Home/Message/publish_new_message',
      data: {
        content: that.data.detail,
        user_id:wx.getStorageSync('user_id'),
        password:wx.getStorageSync('password')
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.errCode == 0) {
          wx.showToast({
            title: res.data.errMsg,
          })
          wx.navigateBack({
            delta: 1,
          })
        } else if (res.data.errCode != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.errMsg,
            showCancel: false,
            success(res) { }
          })
        }
      }
    })
    setTimeout(function () {
      wx.hideLoading({
        success: (res) => { },
      })
    }, 2000)
  },
  
  send: function () { 
    that = this
    wx.request({
      url: app.globalData.server + '/Hi_Buluo/index.php/Home/Friend/add_friend',
      data: {
        user_id: wx.getStorageSync('user_id'),
        password: wx.getStorageSync('password'),
        friend_id: that.data.friend_id
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.errCode == 0) {
          wx.showToast({
            title: '添加成功',
          })
          wx.navigateBack({
            delta: 1,
          })
        } else if (res.data.errCode != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.errMsg,
            showCancel: false,
            success(res) { }
          })
        }
      },
      complete(res) {
        wx.hideLoading({
          success: (res) => { },
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.pages == 'index') {
      this.setData({
        pages: 'index'
      })
      wx.setNavigationBarTitle({
        title: '发树洞',
      })
    } else {
      this.setData({
        pages: 'add',
        username:options.username,
        face_url:options.face_url,
        comment:options.comment,
        friend_id:options.friend_id
      })
      wx.setNavigationBarTitle({
        title: '添加好友',
      })
    }
    var facebook = wx.getStorageSync('facebook');
    that = this
    that.setData({
      user_id: facebook.user_id
    })
    console.log(facebook.user_id);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})