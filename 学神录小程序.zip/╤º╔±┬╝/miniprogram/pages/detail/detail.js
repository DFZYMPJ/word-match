// pages/detail/detail.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    uid: null,
    word_type: 0,
    id: null,
    hot: 10,
    is_like: false,
    content: null,
    pinyin: "yī xīn yī yì",
    word: "一心一意",
    explanation: "只有一个心眼儿，没有别的考虑。",
    derivation: "《三国志·魏志·杜恕传》免为庶人，徙章武郡，是岁嘉平元年。”裴松之注引《杜氏新书》故推一心，任一意，直而行之耳。",
    example: "所以彭官保便～的料理防守事宜，庄制军便～料理军需器械。★清·张春帆《宦海》第四回",
    heart: 0,
    more: null,
    redicals: null,
    strokes: null,
    update_time: '2021-6-24',
    isShowPic: true,
    src: undefined
  },

  search: function () {
    wx.showLoading({
      title: '請耐心等待',
    })
    if (this.data.uid == undefined) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else if (this.data.search_word == "") {
      wx.showModal({
        title: "提示",
        content: '輸入不能爲空~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      var that = this;

      wx.navigateBack({
        delta: 1,
        success(res) {
          console.log("返回上一页")
          var eventChannel = that.getOpenerEventChannel()
          eventChannel.emit('search_word', {
            search_word: that.data.word
          })
        }
      })
    }
  },

  bindKeyInput: function (e) {
    var input = e.detail.value;
    console.log("檢查輸入:" + input)
    this.setData({
      search_word: input
    })
  },

  like: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'like',
      data: {
        type: "add",
        uid: that.data.uid,
        word_type: that.data.word_type,
        word_id: that.data.id
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            is_like: true,
            heart: that.data.heart + 1
          })
        } else {
          wx.showModal({
            title: '抱歉，出错了呢~',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [like] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  nolike: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'like',
      data: {
        type: "del",
        uid: that.data.uid,
        word_type: that.data.word_type,
        word_id: that.data.id
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            is_like: false,
            heart: that.data.heart - 1
          })
        } else {
          wx.showModal({
            title: '抱歉，出错了呢~',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [like] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  query: function () {
    var that = this
    console.log(that.data.id)
    wx.cloud.callFunction({
      name: 'query_word',
      data: {
        type: 'simple',
        query_type: that.data.word_type,
        query_id: that.data.id
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            word: res.result.data.content[0].word,
            id: res.result.data.content[0].id,
            pinyin: res.result.data.content[0].pinyin,
            derivation: res.result.data.content[0].derivation,
            example: res.result.data.content[0].example,
            explanation: res.result.data.content[0].explanation,
            update_time: res.result.data.content[0].update_time,
            hot: res.result.data.content[0].hot,
            more: res.result.data.content[0].more,
            redicals: res.result.data.content[0].redicals,
            strokes: res.result.data.content[0].strokes,
            content: res.result.data.content[0].content,
            src: res.result.data.content[0].src,
            word_type: res.result.data.content[0].word_type
          })
          console.log(res.result.data.content[0].word_type)
          console.log(res.result.data.content[0].src)
        } else {

          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [query_word] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  is: function () {
    var that = this    // 调用云函数
    wx.cloud.callFunction({
      name: 'like',
      data: {
        type: "is",
        word_id: that.data.id,
        uid: that.data.uid,
        word_type: that.data.word_type
      },
      success: res => {
        if (res.result.errCode == 0) {
          console.log(res.result.data.status)
          that.setData({
            is_like: res.result.data.status
          })
        } else {
          wx.showModal({
            title: '抱歉，出错了呢~',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [like] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  total: function () {
    var that = this    // 调用云函数
    wx.cloud.callFunction({
      name: 'like',
      data: {
        type: "total",
        word_id: that.data.id
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            heart: res.result.data.total
          })
        } else {
          wx.showModal({
            title: '抱歉，出错了呢~',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [like] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    var eventChannel = this.getOpenerEventChannel();
    eventChannel.on('more', function (data) {

      if (data.word_type > 2) {
        that.setData({
          id: data.id,
          word:data.word,
          word_type: data.word_type,
          content: data.content,
          hot: data.hot,
          update_time: data.update_time,
          uid: wx.getStorageSync('uid')
        })
      } else {
        that.setData({
          id: data.id,
          word_type: data.word_type,
          uid: wx.getStorageSync('uid')
        })
        that.query()
      }
      that.is()
      that.total()
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自也页面内转发按钮
      console.log(res.target)
      return {
        title: "学神录",
        path: "/pages/detail/detail",
        imageUrl: "/images/feedback_page.png",
        success: function (res) { }
      }
    }
  }
})