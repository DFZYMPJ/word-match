// pages/Hole/index.js
const app = getApp();
var that = null
Page({

  /**
   * 页面的初始数据
   */
  data: {
    username: null,
    user_id: null,
    avatarUrl: app.globalData.userInfo.avatarUrl,
    search_word: null,
    TabBar: true,
    longitude: app.globalData.location.longitude,
    latitude: app.globalData.location.latitude,
    doc: [],
    tab: null,
    User: [],
    Person: [],
    HiHole: [],
    Hole:[],
    _id: [],
    loading: true,
    friend_id:null,
  },

  my: function () {
    this.select('my')
  },

  index: function () {
    this.select('index')
  },

  find: function () {
    this.select('find')
  },

  select: function (tab) {
    this.setData({
      tab: tab
    })
    if (tab == 'my') {
      wx.setNavigationBarTitle({
        title: '我的',
      })
    } else if (tab == 'index') {
      wx.setNavigationBarTitle({
        title: 'Hi社',
      })
      var that = this
      wx.getLocation({
        type: 'wgs84',
        isHighAccuracy: true,
        highAccuracyExpireTime: 3020,
        success(res) {
          const latitude = res.latitude
          const longitude = res.longitude
          const speed = res.speed
          const accuracy = res.accuracy
          console.log(longitude + ':' + latitude)
          that.Square()
        }
      })
    } else {
      wx.setNavigationBarTitle({
        title: '查找',
      })
      this.setData({
        tab: tab
      })
    }
  },

  HiHole: function () {
    that = this
    wx.request({
      url: app.globalData.server + '/Hi_Buluo/index.php/Home/Message/get_one_user_all_messages',
      data: {
        user_id: that.data.friend_id
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.errCode == 0) {
          that.setData({
            HiHole: res.data.data
          })
        } else if (res.data.errCode != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.errMsg,
            showCancel: false,
            success(res) { }
          })
        }
        that.setData({
          click: 0
        })
      },
      complete(res) {
        wx.hideLoading({
          success: (res) => { },
        })
      }
    })
  },

  Square: function () {
    that = this
    wx.request({
      url: app.globalData.server + '/Hi_Buluo/index.php/Home/Message/get_all_messages',
      data: {
        user_id: that.data.user_id
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.errCode == 0) {
          that.setData({
            Hole: res.data.data
          })
        } else if (res.data.errCode != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.errMsg,
            showCancel: false,
            success(res) { }
          })
        }
        that.setData({
          click: 0
        })
      },
      complete(res) {
        wx.hideLoading({
          success: (res) => { },
        })
      }
    })
  },

  commit: function () {
    wx.navigateTo({
      url: '/pages/commit/commit?pages=index',
    })
  },

  addFriend: function () {
    wx.navigateTo({
      url: '/pages/commit/commit?pages=add&username='+ that.data.User[0].username + '&comment=' +'&face_url='+ that.data.User[0].face_url + that.data.User[0].comment +'&friend_id='+ that.data.friend_id,
    })
  },

  latest: function () {
    that = this
    wx.request({
      url: app.globalData.server + '/Hi_Buluo/index.php/Home/User/get_latest_user',
      data: {
        user_id: wx.getStorageSync('user_id'),
        password: wx.getStorageSync('password')
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.errCode == 0) {
          that.setData({
            Person: res.data.data
          })
        } else if (res.data.errCode != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.errMsg,
            showCancel: false,
            success(res) { }
          })
        }
        that.setData({
          click: 0
        })
      },
      complete(res) {
        wx.hideLoading({
          success: (res) => { },
        })
      }
    })
  },

  search: function () {
    that = this
    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if(myreg.test(that.data.search_word)){
      var type = 'phone';
    }else{
      var type = 'username';
    }
    wx.request({
      url: app.globalData.server + '/Hi_Buluo/index.php/Home/User/search_user',
      data: {
        user_id: wx.getStorageSync('user_id'),
        password: wx.getStorageSync('password'),
        keyword: that.data.search_word,
        type:type
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.errCode == 0) {
          that.setData({
            User: [res.data.data],
            friend_id: res.data.friend.id
          })
          console.log(res.data.friend.id)
          var user_id = wx.getStorageSync('user_id')
          if(user_id != res.data.friend.id){
            that.setData({
              tab:'add'
            })
          }
          that.HiHole()
        } else if (res.data.errCode != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.errMsg,
            showCancel: false,
            success(res) { }
          })
        }
      },
      complete(res) {
        wx.hideLoading({
          success: (res) => { },
        })
      }
    })
  },

  bindKeyUsernameInput: function (e) {
    this.setData({
      search_word: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.latest()
    if (options.tab) {
      this.select(options.tab)
    } else {
      this.select('find')
    }
    var userInfo = wx.getStorageSync('userInfo')
    var logged = wx.getStorageSync('logged')
    if (logged) {
      this.setData({
        avatarUrl: userInfo.avatarUrl
      })
    }
    var facebook = wx.getStorageSync('facebook');
    this.setData({
      username: facebook.username,
      user_id: facebook.user_id
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    setTimeout(() => {
      this.setData({
        loading: false
      })
    }, 2000)
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.Square()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})