// pages/register/register.js
var app = getApp();
var that = null;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    username: "",
    phonenumber: 123,
    password: "",
    password2: "",
    tab: 'signIn',
    click: 0
  },

  register: function () {
    that = this
    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if (that.data.username == '') {
      wx.showModal({
        title: '提示',
        content: '請輸入用戶名！',
        showCancel: false,
        success(res) { }
      })
    } else if (that.data.phonenumber == '') {
      wx.showModal({
        title: '提示',
        content: '請輸入手機號！',
        showCancel: false,
        success(res) { }
      })
    } else if (that.data.phonenumber.length != 11) {
      wx.showModal({
        title: '提示',
        content: '請輸入11位手機號！',
        showCancel: false,
        success(res) { }
      })
    } else if (!myreg.test(that.data.phonenumber)) {
      wx.showModal({
        title: '提示',
        content: '請輸入正確的位手機號！',
        showCancel: false,
        success(res) { }
      })
    } else if (that.data.password == '') {
      wx.showModal({
        title: '提示',
        content: '請輸入密碼！',
        showCancel: false,
        success(res) { }
      })
    } else if (that.data.password2 == '') {
      wx.showModal({
        title: '提示',
        content: '請輸入密碼！',
        showCancel: false,
        success(res) { }
      })
    } else {
      if (that.data.password2 != that.data.password) {
        wx.showModal({
          title: '提示',
          content: '密碼不一致，請重試輸入密碼！',
          showCancel: false,
          success(res) { }
        })
      } else {
        console.log('success')
        console.log(app.globalData.userInfo.avatarUrl)
        wx.request({
          url: app.globalData.server + '/Hi_Buluo/index.php/Home/User/signUp',
          data: {
            username: that.data.username,
            password: that.data.password,
            password_again: that.data.password2,
            phone: that.data.phonenumber,
            face_url: app.globalData.userInfo.avatarUrl
          },
          method: 'POST',
          header: {
            'content-type': 'application/x-www-form-urlencoded' // 默认值
          },
          success(res) {
            console.log(res.data)
            if (res.data.errCode == 0) {
              wx.showToast({
                title: res.data.errMsg,
              })
              that.select('signIn')
            } else if (res.data.errCode != 0) {
              wx.showModal({
                title: '提示',
                content: res.data.errMsg,
                showCancel: false,
                success(res) { }
              })
            }
          }
        })
      }
    }
  },

  login: function () {
    that = this
    if (that.data.click == 0) {
      var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
      if (that.data.phonenumber == '') {
        wx.showModal({
          title: '提示',
          content: '請輸入手機號！',
          showCancel: false,
          success(res) { }
        })
      } else if (that.data.phonenumber.length != 11) {
        wx.showModal({
          title: '提示',
          content: '請輸入11位手機號！',
          showCancel: false,
          success(res) { }
        })
      } else if (!myreg.test(that.data.phonenumber)) {
        wx.showModal({
          title: '提示',
          content: '請輸入正確的位手機號！',
          showCancel: false,
          success(res) { }
        })
      } else {
        console.log('success')
        wx.showLoading({
          title: '登陆中...',
        })
        that.setData({
          click: 1
        })
        wx.request({
          url: app.globalData.server + '/Hi_Buluo/index.php/Home/User/signIn',
          data: {
            phone: that.data.phonenumber,
            password: that.data.password
          },
          method: 'POST',
          header: {
            'content-type': 'application/x-www-form-urlencoded' // 默认值
          },
          success(res) {
            console.log(res.data)
            if (res.data.errCode == 0) {
              wx.showToast({
                title: res.data.errMsg,
              })
              wx.setStorageSync('password', that.data.password)
              wx.setStorageSync('user_id', res.data.data.user_id)
              wx.setStorageSync('autoLogin', true)
              wx.reLaunch({
                url: '/pages/Hi_Buluo/index',
              })
            } else if (res.data.errCode != 0) {
              wx.showModal({
                title: '提示',
                content: res.data.errMsg,
                showCancel: false,
                success(res) { }
              })
            }
          },
          complete(res) {
            wx.hideLoading({
              success: (res) => { },
            })
            that.setData({
              click: 0
            })
          }
        })
      }
    }

  },
  signIn: function (e) {
    var tab = e.currentTarget.dataset.click;
    console.log(e.currentTarget.dataset.click)
    this.select(tab)
  },
  signUp: function (e) {
    var tab = e.currentTarget.dataset.click;
    console.log(e.currentTarget.dataset.click)
    this.select(tab)
  },

  select: function (tab) {
    this.data.tab = tab
    if (tab == 'signUp') {
      wx.setNavigationBarTitle({
        title: '注冊',
      })
      this.setData({
        tab: 'signUp'
      })
    } else {
      wx.setNavigationBarTitle({
        title: '登录',
      })
      this.setData({
        tab: 'signIn'
      })
    }
  },

  bindUserNameInput: function (e) {
    this.setData({
      username: e.detail.value
    })
    this.data.username = e.detail.value
  },

  bindPhoneInput: function (e) {
    this.setData({
      phonenumber: e.detail.value
    })
    this.data.phonenumber = e.detail.value
  },

  bindPasswordInput: function (e) {
    this.setData({
      password: e.detail.value
    })
  },

  bindPassword2Input: function (e) {
    this.setData({
      password2: e.detail.value
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.tab == 'signUp') {
      this.select('signUp')
    } else {
      this.select('signIn')
    }
    if (wx.getStorageSync('user_id') != '') {
      var auto = wx.getStorageSync('autoLogin')
      if (auto) {
        wx.reLaunch({
          url: '/pages/Hi_Buluo/index',
        })
      }
    } else {

    }

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})