// pages/explore/explore.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    logged: false,
    collection: [{
      name: "周周看",
      icon: "../../images/weekly.png",
      url: "/pages/weekly/weekly"
    }, {
      name: "玩玩看",
      icon: "../../images/Star.png",
      url: "/pages/star/star"
    }, {
      name: "扫扫看",
      icon: "../../images/scanCode.png",
      url: "/pages/index/index"
    },
      //  {
      //   name: "学学看",
      //   icon: "../../images/study.png",
      //   url: "/pages/study/study"
      // }
      , {
      name: "选选看",
      icon: "../../images/course.png",
      url: "/pages/courseMatch/index?tab=index"
    }, {
      name: "Hi社",
      icon: "../../images/Hole.png",
      url: "/pages/sign/sign?tab=signIn"
    }]
  },
  getUserProfile() {
    var that = this;
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认，开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (e) => {
        that.setData({
          avatarUrl: e.userInfo.avatarUrl,
          nickName: e.userInfo.nickName,
          userInfo: e.userInfo,
          hasUserInfo: true,
        })
        wx.setStorageSync('logged', true)
        wx.setStorageSync('userInfo', e.userInfo)
        wx.setStorageSync('avatarUrl', e.userInfo.avatarUrl)
        wx.setStorageSync('nickName', e.userInfo.nickName)
        app.globalData.userInfo = e.userInfo;
        this.onGetOpenid()
      }
    })
  },

  onGetUserInfo: function (e) {
    if (!app.globalData.logged && e.detail.userInfo) {
      this.setData({
        avatarUrl: e.userInfo.avatarUrl,
        nickname: e.userInfo.nickName,
        userInfo: e.userInfo,
        hasUserInfo: true
      })
      this.onGetOpenid()
    }
  },

  Randomsend: function (min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },

  onGetOpenid: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'wechat_sign',
      data: {
        avatarUrl: that.data.avatarUrl,
        gender: that.data.gender,
        nickName: that.data.nickName,
        uid: that.Randomsend(13, 100000)
      },
      success: res => {
        if (res.result.errCode == 0) {
          app.globalData.openid = res.result.data.openid
          wx.setStorageSync('openid', res.result.data.openid)
          wx.setStorageSync('logged', true)
          if (res.result.data.user.is_admin == 0) {
            that.setData({
              is_admin: false,
              logged: true
            })
            wx.setStorageSync('is_admin', false)
          } else {
            that.setData({
              is_admin: true,
              logged: true
            })
            wx.setStorageSync('is_admin', true)
          }
          wx.setStorageSync('uid', res.result.data.uid)
          var uid = res.result.data.uid
          var user = res.result.data.user
          console.log(user)
          app.globalData.uid = uid
          app.globalData.user = user
          app.globalData.logged = true

        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [wechat_sign] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      this.setData({
        logged: false
      })
    } else {
      this.setData({
        logged: logged
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */

  onShow: function () {
    app.globalData.userInfo = wx.getStorageSync('userInfo')
    var logged = wx.getStorageSync('logged')
    if (logged == undefined) {
      this.setData({
        logged: false
      })
    } else {
      this.setData({
        logged: logged
      })

    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})