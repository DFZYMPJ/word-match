// pages/course/course.js
const app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    avatarUrl: app.globalData.userInfo.avatarUrl,
    search_word: '',
    TabBar: true,
    longitude: app.globalData.location.longitude,
    latitude: app.globalData.location.latitude,
    doc: [],
    tab: '',
    match: [],
    course: [],
    _id: []
  },
  add: function () {
    wx.navigateTo({
      url: '/pages/addCourse/addCourse',
    })
  },

  course_detail: function (e) {
    console.log(e)
    var idx = e.currentTarget.dataset.idx;
    var that = this
    var _id = that.data._id[idx]
    var doc = that.data.doc[idx]
    if (e.currentTarget.dataset.type == 'find') {
      wx.navigateTo({
        url: '/pages/courseDetail/courseDetail?id=' + _id,
        success: function (res) {
          // 通过eventChannel向被打开页面传送数据
          res.eventChannel.emit('courseMatch', that.data.course[idx])
        }
      })
    } else {
      wx.navigateTo({
        url: '/pages/courseDetail/courseDetail?id=' + doc,
        success: function (res) {
          // 通过eventChannel向被打开页面传送数据
          res.eventChannel.emit('courseMatch', that.data.match[idx])
        }
      })
    }
  },

  search: function () {
    var i = 0;
    var search_word = this.data.search_word
    var match = this.data.match;
    var newMatch = []
    for (; match.length > i; i++) {
      if (match[i].name == search_word) {
        newMatch = newMatch.concat([match[i]])
        console.log(match[i].name)
      }
    }
    console.log(newMatch)
    this.setData({
      match: newMatch
    })
  },
  
  bindKeyInput: function (e) {
    var input = e.detail.value;
    console.log("檢查輸入:" + input)
    this.setData({
      search_word: input
    })
  },

  course: function () {
    this.select('course')
  },

  my: function () {
    this.select('my')
  },

  index: function () {
    this.select('index')
  },

  find: function () {
    this.select('find')
  },

  select: function (tab) {
    this.setData({
      tab: tab
    })
    if (tab == 'course') {
      wx.setNavigationBarTitle({
        title: '课程表',
      })
      this.matchCourse(() => { })
    } else if (tab == 'my') {
      wx.setNavigationBarTitle({
        title: '我的',
      })
    } else if (tab == 'index') {
      wx.setNavigationBarTitle({
        title: '主页',
      })
    } else {
      wx.setNavigationBarTitle({
        title: '查找',
      })
      var that = this
      wx.getLocation({
        type: 'wgs84',
        isHighAccuracy: true,
        highAccuracyExpireTime: 3020,
        success(res) {
          const latitude = res.latitude
          const longitude = res.longitude
          const speed = res.speed
          const accuracy = res.accuracy
          console.log(longitude + ':' + latitude)
          that.findCourse(() => { }, longitude, latitude)
        }
      })
    }
  },

  cost: function () {
    this.Filtter('cost')
  },

  free: function () {
    this.Filtter()
  },

  all: function () {
    this.Filtter('all')
  },

  Filtter: function (type) {
    let Data = this.data.list
    let NewData = []
    let i = 0;

    for (; i < Data.length; i++) {
      if (type == 'cost' && Data[i].price > 0) {
        NewData = NewData.push(Data[i])
      } else {
        NewData = NewData.push(Data[i])
      }
    }
    this.setData({
      list: NewData
    })
  },

  findCourse: function (succ, longitude, latitude) {
    var that = this
    wx.cloud.callFunction({
      name: 'courseMatch',
      data: {
        type: 'find',
        longitude: longitude,
        latitude: latitude
      }
    }).then(res => {
      console.log(res)
      if (res.result.data.lesson == undefined) {
        that.setData({
          course: [],
          id: ''
        })
        wx.showToast({
          title: '未匹配附近的课程',
          icon: 'error'
        })
      } else {
        that.setData({
          course: res.result.data.lesson,
          _id: res.result.data._id
        })
        wx.showToast({
          title: res.result.errMsg,
        })
      }


      setTimeout(() => {
        wx.hideToast({
          success: (res) => { },
        })
      }, 2000);
      succ()
    })
  },

  matchCourse: function (succ) {
    var that = this
    wx.cloud.callFunction({
      name: 'courseMatch',
      data: {
        type: 'get'
      }
    }).then(res => {
      console.log(res)
      if (res.result.data.table == []) {
        that.setData({
          match: []
        })
        wx.showToast({
          title: '暂无课程',
          icon: 'error'
        })
      } else {
        that.setData({
          match: res.result.data.table,
          doc: res.result.data.doc
        })
        wx.showToast({
          title: res.result.errMsg,
        })
      }
      setTimeout(() => {
        wx.hideToast({
          success: (res) => { },
        })
      }, 2000);
      succ()
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.tab) {
      this.select(options.tab)
    } else {
      this.select('index')
    }
    var userInfo = wx.getStorageSync('userInfo')
    var logged = wx.getStorageSync('logged')
    if (logged) {
      this.setData({
        avatarUrl: userInfo.avatarUrl
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})