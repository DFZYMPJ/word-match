// pages/weekly/weekly.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    weeklyMovieList: [],
    currentIndex: 0,
    count: 0
  },

  about: function (event) {
    var that = this;
    wx.navigateTo({
      url: '../about/about',
      success(res) {
        res.eventChannel.emit('weeklymovie', {})
      }
    })
  },
  back: function () {
    this.setData({
      currentIndex: this.data.weeklyMovieList.length - 1
    })
    console.log(this.data.currentIndex)
  },
  Preview: function (event) {
    var img = event.currentTarget.dataset.image
    wx.previewImage({
      current: img, // 当前显示图片的http链接
      urls: [img] // 需要预览的图片http链接列表
    })
  },
  details: function (event) {
    console.log(event)
    var id = event.currentTarget.dataset.id
    var banner = event.currentTarget.dataset.benner
    console.log(id)
    wx.navigateTo({
      url: '/pages/movieDetail/movieDetail?id=' + id + '&banner=' + banner,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.cloud.callFunction({
      name: 'get_words',
      data: {
        type: 'recommend'
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            weeklyMovieList: res.result.data.movie
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [get_words] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }, complete: res => {
        setTimeout(function () {
          wx.hideLoading()
        }, 2000)
      }
    })
    this.setData({
      currentIndex: this.data.weeklyMovieList.length - 1
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var userInfo = wx.getStorageSync('userInfo')
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: userInfo.nickName + "向你推荐！",
          imageUrl: "/images/weekly.png"
        })
      }, 2000)
    })
    return {
      title: userInfo.nickName + "向你推荐！",
      path: '/pages/weekly/weekly',
      imageUrl: "/images/weekly.png",
      promise
    }
  }
})