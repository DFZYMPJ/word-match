// pages/study/study.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: '',
    loading: true,
    search_empty: false,
    list: [{
      id: 0,
      name: "一年级英语单词表(上册)",
      lesson: 23,
      version: "人教版",
      level: "一年级",
      src: "../../images/study.png"
    }, {
      id: 0,
      name: "一年级英语单词表(上册)",
      lesson: 23,
      version: "人教版",
      level: "一年级",
      src: "../../images/study.png"
    }, {
      id: 0,
      name: "一年级英语单词表(上册)",
      lesson: 23,
      version: "人教版",
      level: "一年级",
      src: "../../images/study.png"
    }, {
      id: 0,
      name: "一年级英语单词表(上册)",
      lesson: 23,
      version: "人教版",
      level: "一年级",
      src: "../../images/study.png"
    }]
  },

  studyHome: function (e) {
    if (!wx.getStorageSync('logged')) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      var lesson = e.currentTarget.dataset.lesson
      var name = e.currentTarget.dataset.name
      wx.setStorageSync('lesson', lesson)
      wx.setStorageSync('name', name)
      wx.navigateTo({
        url: '/pages/studyHome/studyHome',
      })
    }
  },

  onChange(e) {
    this.setData({
      value: e.detail,
    });
  },

  onClick() {
    var that = this
    that.setData({
      search_empty: true
    })
    if (that.data.value != '') {
      // 调用云函数
      wx.cloud.callFunction({
        name: 'course',
        data: {
          type: 'find',
          query_word: that.data.value
        },
        success: res => {
          wx.showToast({
            title: '请求成功',
          })
          if (res.result.errCode == 0) {
            that.setData({
              list: res.result.data.course
            })
            console.log(res.result.data.list)
          } else {
            wx.showModal({
              title: '提醒',
              content: res.result.errMsg,
              confirmText: "我知道了",
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }
        },
        fail: err => {
          console.error('[云函数] [course] 调用失败', err)
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions',
          })
        },
        complete: res => {
          setTimeout(() => {
            wx.hideToast({})
          }, 2000)
        }
      })
    } else {
      that.Course()
    }
  },

  Course: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'course',
      data: {
        type: 'get',
        skip: 0
      },
      success: res => {
        wx.showLoading({
          title: '请耐性等待...',
        })
        if (res.result.errCode == 0) {
          that.setData({
            list: res.result.data.course
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [course] 调用失败', err)
        // wx.navigateTo({
        //   url: '../deployFunctions/deployFunctions',
        // })
      },
      complete: res => {
        setTimeout(() => {
          wx.hideLoading({
            success: (res) => { },
          })
        }, 5000);
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.Course()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    setTimeout(() => {
      this.setData({
        loading: false
      })
    }, 5000)
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log('触发上拉事件')
  },
  onPageScroll: function () {

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})