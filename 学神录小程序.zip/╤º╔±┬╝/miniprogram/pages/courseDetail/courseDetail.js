// pages/courseDetail/courseDetail.js
var app = getApp()
const lessonTmplId = 'dRbMcKOZfa8IsoTxZdORLPuqcLo3Bqj4uuTWw5vB-6I';
Page({

  /**
   * 页面的初始数据
   */

  data: {
    id: '',
    course_id: 0,
    course_cover: '',
    course_name: '',
    price: 0,
    user_list: [],
    _id: [],
    course_QA: [],
    click: 0,
    isJoin: false,
    isTeacher: false
  },
  table: function (e) {
    var index = e.currentTarget.dataset.idx
    wx.navigateTo({
      url: '/pages/courseTable/courseTable?id=' + this.data._id[index] + '&name=' + this.data.user_list[index].realName,
    })
  },

  chooseCourse: function () {
    if (this.data.click == 0) {
      this.setData({
        click: 1
      })
      // this.joinCourse(() => { }, this.data.id, this.data.course_id)
      let date = new Date(Date.parse(new Date()) + 5000);
      const item = {
        thing1: {
          value: this.data.course_name
        },
        time12: {
          value: this.formdate(date)
        }
      }
      wx.requestSubscribeMessage({
        tmplIds: [lessonTmplId],
        success(res) {
          if (res.errMsg === 'requestSubscribeMessage:ok') {
            wx.showLoading({
              title: '订阅中',
              mask: true
            })
            wx.cloud.callFunction({
              name: 'subscribe',
              data: {
                data: item,
                date: date,
                templateId: lessonTmplId,
              },
            }).then(res => {
              console.log(res)
              wx.hideLoading();
              wx.showToast({
                title: '订阅成功'
              });
            }).catch(() => {
              wx.showToast({
                title: '订阅失败',
                icon: 'none'
              });
            });
          }
        },
      });
    }
  },

  formdate: function (date) {
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var date1 = date.getDate();
    var hour = date.getHours();
    var minutes = date.getMinutes();
    return year + "年" + month + "月" + date1 + "日 " + hour + ":" + minutes;
  },

  joinCourse: function (succ, id, course_id) {
    var that = this
    wx.cloud.callFunction({
      name: 'courseMatch',
      data: {
        type: 'join',
        id: id,
        course_id: course_id
      }
    }).then(res => {
      console.log(res)
      if (res.result.errCode == 0) {
        wx.showToast({
          title: '課程加入成功',
        })
        setTimeout(() => {
          wx.hideToast({
            success: (res) => { },
          })
        }, 2000);
        that.setData({
          click: 0,
          isJoin: true
        })
      }
    })

    succ()
  },

  viewCourse: function (succ, id, course_id) {
    var that = this
    wx.cloud.callFunction({
      name: 'courseMatch',
      data: {
        type: 'view',
        id: id,
        course_id: course_id
      }
    }).then(res => {
      console.log(res)
      if (res.result.errCode == 0) {
        wx.showToast({
          title: '获取选课情况',
        })
        setTimeout(() => {
          wx.hideToast({
            success: (res) => { },
          })
        }, 2000);
        that.setData({
          isJoin: res.result.data.isJoin,
          user_list: res.result.data.userlist,
          _id: res.result.data._id
        })
      }
    })

    succ()
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    that.setData({
      id: options.id
    })
    if (options.id == app.globalData.courseMatchID) {
      that.setData({
        isTeacher: true
      })
    }
    const eventChannel = this.getOpenerEventChannel()
    // 监听courseMatch事件，获取上一页面通过eventChannel传送到当前页面的数据
    eventChannel.on('courseMatch', function (data) {
      console.log(data)
      that.setData({
        course_cover: data.cover,
        course_name: data.name,
        course_QA: data.Q_A,
        price: data.price,
        course_id: data.id
      })
      that.viewCourse(() => { }, that.data.id, that.data.course_id)
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})