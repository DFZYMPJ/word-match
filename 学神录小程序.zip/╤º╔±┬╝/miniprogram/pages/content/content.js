// pages/content/content.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    nickname: "學神錄",
    realname: "張運鵬",
    password: null,
    motto: "小學時光已經過去，害怕就此不再聯係，不要怕，趕緊在這裏留下你的同學錄吧~",
    introduction: "你好，我是像風一樣的男子，你也可以叫我瘋子。",
    message: "我喜歡你，你喜歡我嗎？",
    picture_url: "cloud://cloud1-2godcvt481ecec78.636c-cloud1-2godcvt481ecec78-1305561666/1623404466248.jpg",
    gender: 0,
    age: 20,
    birthday: "2000/06/25",
    address: "海南省儋州市洋浦經濟開發區",
    thumb_count: 0,
    isShow: false,
    id: null,
    islock_realname: 0,
    islock_birthday: 0,
    password2: null,
    isLike: false,
    openid: null,
    Q_A: []
  },

  edit: function (e) {
    var that = this;
    wx.navigateTo({
      url: '../release/release',
      success(res) {
        res.eventChannel.emit('edit', {
          id: that.data.id,
          realname: that.data.realname,
          nickname: that.data.nickname,
          gender: that.data.gender,
          birthday: that.data.birthday,
          motto: that.data.motto,
          address: that.data.address,
          password: that.data.password,
          message: that.data.message,
          introduction: that.data.introduction,
          islock_birthday: that.data.islock_birthday,
          islock_realname: that.data.islock_realname,
          picture_url: that.data.picture_url
        })
      }
    })
  },

  bindKeyInputPassword: function (e) {
    this.setData({
      password2: e.detail.value
    })
  },

  join: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'like',
      data: {
        type: 'remove',
        ddnote_id: that.data.id,
        openid: wx.getStorageSync('openid')
      },
      success: res => {
        console.log(res)
        if (res.result.errCode == 0) {
          that.setData({
            thumb_count: that.data.thumb_count - 1,
            isLike: false
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [like] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {}
    })
  },

  remove: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'like',
      data: {
        type: 'join',
        ddnote_id: that.data.id,
        openid: wx.getStorageSync('openid')
      },
      success: res => {
        console.log(res.result)
        if (res.result.errCode == 0) {
          that.setData({
            thumb_count: that.data.thumb_count + 1,
            isLike: true
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [like] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {}
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    this.setData({
      id: options.id
    })
    wx.startPullDownRefresh({
      success: (res) => {},
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.startPullDownRefresh({
      success: (res) => {},
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'ddnote',
      data: {
        type: 'view',
        id: that.data.id
      },
      success: res => {
        wx.showLoading({
          title: '請耐心等待',
        })
        if (res.result.errCode == 0) {
          that.setData({
            id: res.result.data.dd[0].id,
            picture_url: res.result.data.dd[0].picture_url,
            nickname: res.result.data.dd[0].nickname,
            realname: res.result.data.dd[0].realname,
            motto: res.result.data.dd[0].motto,
            introduction: res.result.data.dd[0].introduction,
            message: res.result.data.dd[0].message,
            picture_url: res.result.data.dd[0].picture_url,
            gender: res.result.data.dd[0].gender,
            age: res.result.data.dd[0].age,
            birthday: res.result.data.dd[0].birthday,
            address: res.result.data.dd[0].address,
            thumb_count: res.result.data.dd[0].thumb_count,
            password: res.result.data.dd[0].password,
            islock_birthday: res.result.data.dd[0].islock_birthday,
            islock_realname: res.result.data.dd[0].islock_realname,
            openid: res.result.data.dd[0].openid,
            Q_A: res.result.data.dd[0].Q_A
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [ddnote] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {
        if (that.data.openid == wx.getStorageSync('openid')) {
          that.setData({
            isShow: true
          })
        } else {
          that.setData({
            isShow: false
          })
        }
        setTimeout(function () {
          wx.hideLoading()
        }, 2000)
        wx.stopPullDownRefresh({
          success: (res) => {},
        })
      }
    })

    // 调用云函数
    wx.cloud.callFunction({
      name: 'like',
      data: {
        type: 'has',
        ddnote_id: that.data.id,
        openid: wx.getStorageSync('openid')
      },
      success: res => {
        console.log(res)
        if (res.result.errCode == 0) {
          that.setData({
            isLike: res.result.data.status
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [like] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {}
    })


  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})