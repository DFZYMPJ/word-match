// pages/bookList/bookList.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    activeNames: ['1', '2', '3', '4'],
    loading: true,
    cover_url: "https://img3.doubanio.com/view/subject/l/public/s4579360.jpg",
    title: "宅男美食大作戰",
    author: "林欣浩",
    isbn: 21892180219029,
    abstract: '212',
    book_intro: '哈哈哈',
    author_intro: '暂无',
    press: '',
    published_in: '',
    catalog: '',
    star_count: 0,
    comments: [1, 2, 2]
  },
  edit: function (event) {
    wx.navigateTo({
      url: '/pages/bookEdit/bookEdit?type=change&isbn=' + this.data.isbn,
    })
  },
  onOpen(event) {
    wx.showToast({
      title: `打开:`,
    })
  },
  onClose(event) {
    wx.showToast({
      title: `关闭`,
    })
  },
  onChange(event) {
    this.setData({
      activeNames: event.detail,
    });
  },
  preview: function (e) {
    var image = e.currentTarget.dataset.image
    wx.previewImage({
      current: image, // 当前显示图片的http链接
      urls: [image] // 需要预览的图片http链接列表
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      isbn: options.isbn
    })
    console.log(options.isbn)
    var that = this
    wx.cloud.callFunction({
      name: 'book',
      data: {
        type: 'simple',
        isbn: Number(that.data.isbn)
      },
      success: res => {
        wx.showLoading({
          title: '請耐心等待',
        })
        console.log(res.result)
        if (res.result.errCode == 0) {
          that.setData({
            cover_url: res.result.data.bookDetail[0].cover_url,
            title: res.result.data.bookDetail[0].title,
            author: res.result.data.bookDetail[0].author,
            isbn: res.result.data.bookDetail[0].isbn,
            abstract: res.result.data.bookDetail[0].abstract,
            book_intro: res.result.data.bookDetail[0].book_intro,
            author_intro: res.result.data.bookDetail[0].author_intro,
            press: res.result.data.bookDetail[0].press,
            catalog: res.result.data.bookDetail[0].catelog,
            star_count: res.result.data.bookDetail[0].star_count,
            comments: res.result.data.bookDetail[0].comments
          })
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [book] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      },
      complete: res => {
        setTimeout(() => {
          wx.hideLoading({
            success: (res) => {},
          })
        }, 2000);
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    setTimeout(() => {
      this.setData({
        loading: false
      })
    }, 2000)
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})