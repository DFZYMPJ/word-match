// pages/home/home.js
var plugin = requirePlugin("chatbot");
//获取应用实例
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    avatarUrl: "/images/avatar-unlogin.png",
    nickName: "未登录",
    user: {},
    uid: null,
    is_admin: false,
    userInfo: {},
    logged: false,
    total: 0,
    hz_hot_words: [],
    cy_hot_words: [],
    serach_word: ""
  },

  management: function () {
    if (!this.data.logged) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.navigateTo({
        url: '../management/management',
      })
    }
  },

  bindKeyInput: function (e) {
    var input = e.detail.value;
    console.log("檢查輸入:" + input)
    this.setData({
      search_word: input
    })
  },

  search: function () {
    if (!this.data.logged) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else if (this.data.search_word == "") {
      wx.showModal({
        title: "提示",
        content: '輸入不能爲空~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      var that = this;
      wx.navigateTo({
        url: '../search/search?search_word=' + that.data.search_word,
        success(res) {
          res.eventChannel.emit('search', {
            search_word: that.data.search_word,
            uid: that.data.uid
          })
        }
      })
    }
  },

  query: function (e) {
    if (this.data.uid != null) {
      var that = this;
      var word = e.currentTarget.dataset.word

      if (this.data.uid == null) {
        wx.showModal({
          title: "提示",
          content: '請先登陸哦~',
          confimText: "我知道了",
          showCancel: false,
          success(res) {
            if (res.confirm) {
              console.log('用户点击确定')
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      } else {
        wx.navigateTo({
          url: '../search/search',
          success(res) {
            res.eventChannel.emit('search', {
              uid: that.data.uid,
              search_word: word,
            })
          }
        })
      }

    }
  },

  feedback: function () {
    if (!this.data.logged) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.navigateTo({
        url: '../feedback/feedback',
      })
    }
  },

  tabClick(event) {
    console.log(event.detail.name)
    if (event.detail.name == '成语') {
      if (this.data.cy_hot_words == []) {
        this.cy_hot_words()
      }
    } else {
      if (this.data.hz_hot_words == []) {
        this.hz_hot_words()
      }
    }
  },

  cy_hot_words: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'get_words',
      data: {
        type: 1,
        name: 'cy_hot'
      },
      success: res => {
        console.log(res)
        if (res.result.errCode == 0) {
          if (res.result.data.name == 'cy') {
            that.setData({
              cy_hot_words: res.result.data.hot_words
            })
            console.log(res.result.data.hot_words)
          }
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [get_words] 调用失败', err)
        // wx.navigateTo({
        //   url: '../deployFunctions/deployFunctions',
        // })
      }
    })
  },

  hz_hot_words: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'get_words',
      data: {
        type: 2,
        name: 'hz_hot'
      },
      success: res => {
        console.log(res)
        if (res.result.errCode == 0) {
          if (res.result.data.name == 'hz') {
            that.setData({
              hz_hot_words: res.result.data.hot_words
            })
            console.log(res.result.data.hot_words)
          }
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [get_words] 调用失败', err)
        // wx.navigateTo({
        //   url: '../deployFunctions/deployFunctions',
        // })
      }
    })
  },

  words_total: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'get_words',
      data: {
        name: 'total'
      },
      success: res => {
        if (res.result.errCode == 0) {
          that.setData({
            total: res.result.data.total
          })
          console.log(res.result.data.total)
        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [get_words] 调用失败', err)
        // wx.navigateTo({
        //   url: '../deployFunctions/deployFunctions',
        // })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    app.globalData.userInfo = wx.getStorageSync('userInfo')
    var logged = wx.getStorageSync('logged')

    if (logged == undefined) {
      this.setData({
        logged: false
      })
    } else {
      this.setData({
        logged: logged
      })
      var openid = wx.getStorageSync('openid')
      if (openid) {
        // 初始化智能对话系统
        plugin.init({
          appid: "yhzv2fy76wORax9NTqvXgiDacZR9cm",
          openid: wx.getStorageSync('openid'),
          guideList: ["噢，什么鬼", "他都做了什么？", "学神之子是谁？能吃吗？好吃吗？", "我要查他水表，怎么办？", "使用智能问答技能？", "学神录是什么？", "它有什么用？",],
          textToSpeech: 1,
          welcome: "请问有什么需要帮助？",
          welcomeImage: 'http://inews.gtimg.com/newsapp_bt/0/10701537095/1000',
          background: "rgba(247,251,252,1)",
          guideCardHeight: 40,
          operateCardHeight: 90,
          history: true,
          navHeight: 0,
          robotHeader: 'https://thegoddessforum.com/blogs/rebot.png',
          userHeader: wx.getStorageSync('avatarUrl'),
          userName: wx.getStorageSync('nickName'),
          anonymous: false,
          hideMovableButton: false,
          success: () => { }, //非必填
          fail: (error) => { }, //非必填
        });
      }
    }
    var uid = wx.getStorageSync('uid')
    this.setData({
      uid: uid
    })
    var is_admin = wx.getStorageSync('is_admin')
    var userInfo = wx.getStorageSync('userInfo')
    var logged = wx.getStorageSync('logged')
    if (logged) {
      this.setData({
        nickName: userInfo.nickName,
        avatarUrl: userInfo.avatarUrl,
        is_admin: is_admin
      })
    }
    if (!wx.cloud) {
      wx.showModal({
        title: '初始化失败',
        content: '请使用 2.2.3 或以上的基础库使用云能力',
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      return
    }
    if (!wx.getUserProfile) {
      this.setData({
        canIUseGetUserProfile: true,
      })
      this.getUserProfile();
    }

    wx.requestSubscribeMessage({
      tmplIds: [wx.getStorageSync('template3')],
      success: (res) => {
        console.log(res)
        console.log()
        if (res[wx.getStorageSync('template3')] === 'accept') {
          console.log('成功')
        } else {
          console.log(`失败（${res[wx.getStorageSync('template3')]}）`)
        }
      },
      fail: (err) => {
        console.log(`失败（${JSON.stringify(err)}）`)
      },
      complete: function () {

      }
    })
  },

  bindGetUserInfo(e) {
    console.log(e.detail.userInfo)
  },

  getUserProfile() {
    var that = this;
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认，开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (e) => {
        that.setData({
          avatarUrl: e.userInfo.avatarUrl,
          nickName: e.userInfo.nickName,
          userInfo: e.userInfo,
          hasUserInfo: true,
        })
        wx.setStorageSync('logged', true)
        wx.setStorageSync('userInfo', e.userInfo)
        wx.setStorageSync('avatarUrl', e.userInfo.avatarUrl)
        wx.setStorageSync('nickName', e.userInfo.nickName)
        app.globalData.userInfo = e.userInfo;
        this.onGetOpenid()
      }
    })
  },

  onGetUserInfo: function (e) {
    if (!app.globalData.logged && e.detail.userInfo) {
      this.setData({
        avatarUrl: e.userInfo.avatarUrl,
        nickname: e.userInfo.nickName,
        userInfo: e.userInfo,
        hasUserInfo: true
      })
      this.onGetOpenid()
    }
  },

  Randomsend: function (min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },

  onGetOpenid: function () {
    var that = this
    // 调用云函数
    wx.cloud.callFunction({
      name: 'wechat_sign',
      data: {
        avatarUrl: that.data.avatarUrl,
        gender: that.data.gender,
        nickName: that.data.nickName,
        uid: that.Randomsend(13, 100000)
      },
      success: res => {
        if (res.result.errCode == 0) {
          app.globalData.openid = res.result.data.openid
          wx.setStorageSync('openid', res.result.data.openid)
          wx.setStorageSync('logged', true)
          if (res.result.data.user.is_admin == 0) {
            that.setData({
              is_admin: false,
              logged: true
            })
            wx.setStorageSync('is_admin', false)
          } else {
            that.setData({
              is_admin: true,
              logged: true
            })
            wx.setStorageSync('is_admin', true)
          }
          wx.setStorageSync('uid', res.result.data.uid)
          var uid = res.result.data.uid
          var user = res.result.data.user
          console.log(user)
          app.globalData.uid = uid
          app.globalData.user = user
          app.globalData.logged = true

        } else {
          wx.showModal({
            title: '提醒',
            content: res.result.errMsg,
            confirmText: "我知道了",
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail: err => {
        console.error('[云函数] [wechat_sign] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  customer: function () {
    if (!wx.getStorageSync('logged')) {
      wx.showModal({
        title: "提示",
        content: '請先登陸哦~',
        confimText: "我知道了",
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.navigateTo({
        url: '../customer_service/customer_service',
      })
    }
  },

  game: function () {
    wx.navigateTo({
      url: '../game/game',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    app.globalData.userInfo = wx.getStorageSync('userInfo')
    var logged = wx.getStorageSync('logged')

    if (logged == undefined) {
      this.setData({
        logged: false
      })
    } else {
      this.setData({
        logged: logged
      })
      var openid = wx.getStorageSync('openid')
      if (openid) {
        // 初始化智能对话系统
        plugin.init({
          appid: "yhzv2fy76wORax9NTqvXgiDacZR9cm",
          openid: wx.getStorageSync('openid'),
          guideList: ["噢，什么鬼", "他都做了什么？", "学神之子是谁？能吃吗？好吃吗？", "我要查他水表，怎么办？", "使用智能问答技能？", "学神录是什么？", "它有什么用？",],
          textToSpeech: 1,
          welcome: "请问有什么需要帮助？",
          welcomeImage: 'http://inews.gtimg.com/newsapp_bt/0/10701537095/1000',
          background: "rgba(247,251,252,1)",
          guideCardHeight: 40,
          operateCardHeight: 90,
          history: true,
          navHeight: 0,
          robotHeader: 'https://thegoddessforum.com/blogs/rebot.png',
          userHeader: wx.getStorageSync('avatarUrl'),
          userName: wx.getStorageSync('nickName'),
          anonymous: false,
          hideMovableButton: false,
          success: () => { }, //非必填
          fail: (error) => { }, //非必填
        });
      }
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    // var eventChannel = that.getOpenerEventChannel()
    // eventChannel.on('key_word', function (data) {

    //   that.setData({
    //     search_word: data.key_word
    //   })
    //   that.search()
    // })
    this.cy_hot_words()
    this.hz_hot_words()
    this.words_total()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  /**
   * 用户点击右上角分享
   */
  onShareTimeline: function (res) {
    if (res.from === 'button') {
      // 来自也页面内转发按钮
      console.log(res.target)
      const promise = new Promise(resolve => {
        setTimeout(() => {
          resolve({
            title: this.data.nickname + "向你推荐！",
            imageUrl: "/images/gift_img.png"
          })
        }, 2000)
      })
      return {
        title: this.data.nickName + "向你推荐！",
        path: "/pages/home/home",
        imageUrl: "/images/gift_img.png",
        success: function (res) { }
      }
    }
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: '學神錄：' + this.data.nickName + "向你推荐！",
          imageUrl: "/images/gift_img.png"
        })
      }, 2000)
    })
    return {
      title: '學神錄：' + this.data.nickName + "向你推荐！",
      path: "/pages/game/game",
      imageUrl: "/images/gift_img.png",
      promise
    }
  },
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自也页面内转发按钮
      console.log(res.target)
      const promise = new Promise(resolve => {
        setTimeout(() => {
          resolve({
            title: this.data.nickname + "向你推荐！",
            imageUrl: "/images/gift_img.png"
          })
        }, 2000)
      })
      return {
        title: this.data.nickName + "向你推荐！",
        path: "/pages/home/home",
        imageUrl: "/images/gift_img.png",
        success: function (res) { }
      }
    }
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: '學神錄：' + this.data.nickName + "向你推荐！",
          imageUrl: "/images/gift_img.png"
        })
      }, 2000)
    })
    return {
      title: '學神錄：' + this.data.nickName + "向你推荐！",
      path: "/pages/game/game",
      imageUrl: "/images/gift_img.png",
      promise
    }
  }
})