// 云函数入口文件
const cloud = require('wx-server-sdk')
// 网络请求接口
const rq = require('request-promise')
const r = require('request');

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const db = cloud.database()
  switch (event.type) {
    case "add": {
      return addBook(db, event, wxContext, r)
    }
    case "delete": {
      return delBook(db, event, wxContext)
    }
    case "view": {
      return viewBook(db, event, wxContext)
    }
    case "join": {
      return joinMyBook(db, event, wxContext)
    }
    case "remove": {
      return removeMyBook(db, event, wxContext)
    }
    case "get": {
      return getMyBook(db, wxContext)
    }
    case "query": {
      return queryMyBook(db, event, wxContext)
    }
    case "simple": {
      return simpleMyBook(db, event, wxContext)
    }
  }
}

async function addBook(db, event, wxContext, r) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  console.log(wxContext)
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  // 检测是否传了参数 start
  if (event.isbn == undefined) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未传必要参数，请重试'
    var data = {}
    data.ok == false
    result.data = data
    return result
    // 检测是否传了参数 end
  }
  console.log()
  var isbn = event.isbn;
  var s = isbn.toString()

  if (s.length == 13) {
    /** 加入新書 start **/
    var options = {
      'method': 'GET',
      'url': 'https://api.feelyou.top/isbn/' + Number(event.isbn),
      'headers': {
        'apikey': 'OWHagO3Wmkt0FLaZJTtgHxCzGDxHt0Uu'
      },
      "json": true
    };
    var book = [];
    // 定义一个变量存储请求返回json数据
    var countResult;
    try {
      var s = await r(options, function (error, response) {
        if (error) {
          throw new Error(error);
        }
        book = response.body
        console.log(book)
        countResult = db.collection('book')
          .where({
            id: Number(book.isbn)
          }).get()
          .then(res => {
            console.log(res.data)
            var result = res.data

            if (result.length == 0) {
              if (book.book_intro == undefined) {
                var book_intro = ""
              } else {
                var book_intro = book.book_intro
              }
              if (book.author_intro == undefined) {
                var author_intro = ""
              } else {
                var author_intro = book.author_intro
              }
              if (book.cover_url == undefined) {
                if (book.isbn == 9787540549961) {
                  var cover_url = "https://img2.doubanio.com/view/subject/l/public/s10214402.jpg"
                } else {
                  var cover_url = "https://img2.doubanio.com/view/subject/l/public/s10214402.jpg"
                }
              } else {
                var cover_url = book.cover_url
              }
              if (book.catalog == undefined) {
                var catalog = ""
              } else {
                var catalog = book.catalog
              }
              if (book.book_info == undefined) {
                console.log('book_info not found!')
                var str = book.abstract
                console.log(book.abstract)
                var n = str.split("/")
                if (n != undefined) {
                  if (n.length == 4) {
                    var bookinfo = {
                      "ISBN": book.isbn,
                      "出版年": n[2],
                      "作者": n[0],
                      "定价": n[3],
                      "出版社": n[1],
                      "装帧": "平帧",
                      "原作名": n[0],
                      "页数": 0
                    }
                  }
                  if (n.length == 1) {
                    var bookinfo = {
                      "ISBN": book.isbn,
                      "出版年": '',
                      "作者": '',
                      "定价": n[0],
                      "出版社": '',
                      "装帧": "平帧",
                      "原作名": '',
                      "页数": 0
                    }
                  }
                  if (n.length == 5) {
                    var bookinfo = {
                      "ISBN": book.isbn,
                      "出版年": n[3],
                      "作者": n[0] + "、" + n[1],
                      "定价": n[4],
                      "出版社": n[2],
                      "装帧": "平帧",
                      "原作名": '',
                      "页数": 0
                    }
                    console.log(bookinfo)
                  }
                  if (n.length == 2) {
                    var bookinfo = {
                      "ISBN": book.isbn,
                      "出版年": n[0],
                      "作者": '',
                      "定价": n[1],
                      "出版社": '',
                      "装帧": "平帧",
                      "原作名": '',
                      "页数": 0
                    }
                  }
                  if (n.length == 3) {
                    var bookinfo = {
                      "ISBN": book.isbn,
                      "出版年": n[1],
                      "作者": n[0],
                      "定价": n[2],
                      "出版社": '',
                      "装帧": "平帧",
                      "原作名": '',
                      "页数": 0
                    }
                  }
                } else {
                  var bookinfo = {
                    "ISBN": book.isbn,
                    "出版年": '',
                    "作者": '',
                    "定价": '',
                    "出版社": '',
                    "装帧": "平帧",
                    "原作名": '',
                    "页数": 0
                  }
                }
              } else {
                if (book.book_info.作者 == undefined || book.book_info.作者 == '') {
                  var str = book.abstract
                  console.log(book.abstract)
                  var n = str.split("/")
                  if (n.length == 5) {
                    var bookinfo = {
                      "ISBN": book.isbn,
                      "出版年": book.book_info.出版年,
                      "作者": n[0] + "、" + n[1],
                      "定价": book.book_info.定价,
                      "出版社": book.book_info.出版社,
                      "装帧": book.book_info.装帧,
                      "原作名": '',
                      "页数": book.book_info.页数
                    }
                  }
                  if (n.length == 3) {
                    var bookinfo = {
                      "ISBN": book.isbn,
                      "出版年": n[1],
                      "作者": n[0],
                      "定价": n[2],
                      "出版社": '',
                      "装帧": "平帧",
                      "原作名": '',
                      "页数": book.book_info.页数
                    }
                  }
                  if (n.length == 1) {
                    var bookinfo = {
                      "ISBN": book.isbn,
                      "出版年": book.book_info.出版年,
                      "作者": '',
                      "定价": book.book_info.定价,
                      "出版社": book.book_info.出版社,
                      "装帧": book.book_info.装帧,
                      "原作名": '',
                      "页数": book.book_info.页数
                    }
                  }

                } else {
                  var bookinfo = book.book_info
                }
              }
              console.log(bookinfo)
              //构建要添加的参数
              const to_add_data = {
                id: Number(book.isbn),
                word: book.title,
                abstract: book.abstract,
                comments: book.comments,
                bookinfo: bookinfo,
                cover_url: cover_url,
                catalog: catalog,
                author_intro: author_intro,
                book_intro: book_intro,
                labels: book.labels,
                count: {
                  favorite_count: 0,
                  read_count: 0,
                  add_count: 1
                },
                rating: book.rating,
                hot: 0,
                create_time: new Date(),
                update_time: new Date()
              }
              // 新增数据
              var add_result = []
              db.collection('book')
                .add({
                  data: to_add_data
                })
                .then(res => {
                  console.log("添加图书信息成功")
                  add_result = res.data
                })


            } else {
              // 更新数据
              var update_result = []
              db.collection('book')
                .where({
                  isbn: Number(event.isbn)
                })
                .update({
                  data: {
                    count: [{
                      read_count: result[0].count.read_count,
                      favorite_count: result[0].count.favorite_count,
                      add_count: result[0].count.add_count + 1
                    }]
                  }
                })
                .then(res => {
                  console.log("更新图书信息成功")
                  update_result = res.data
                })
            }
          })
      });
      // 返回执行结果
      var result = {}
      result.errCode = 0
      result.errMsg = '拉取图书信息成功！'
      var data = {}
      data.db_result = 'success'
      result.data = data
      return result
    } catch (e) {
      // 处理出错情况
      console.log(e.message)
      // 返回执行结果
      var result = {}
      result.errCode = 8
      result.errMsg = '拉取图书信息成功！'
      var data = {}
      data.db_result = 'success'
      result.data = data
      return result
    }
  } else {
    // 返回执行结果
    var result = {}
    result.errCode = 4
    result.errMsg = '請輸入isbn是13位數'
    var data = {}
    result.data = data
    return result
  }

}

async function viewBook(db, event, wxContext) {
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  // 检测是否传了参数 start
  console.log(event.isbn)
  if (event.isbn == undefined) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未传必要参数，请重试'
    var data = {}
    data.ok == false
    result.data = data
    return result
    // 检测是否传了参数 end
  }
  // 定義一個數組變量接受查詢結果
  var Book = [];
  await db.collection('book')
    .where({
      id: Number(event.isbn)
    })
    .get()
    .then(res => {
      Book = Book.concat(res.data[0])
    })
  var result = {}
  result.errCode = 0
  result.errMsg = '查询成功'
  var data = {}
  data.book = Book
  result.data = data
  return result
}

async function joinMyBook(db, event, wxContext) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  console.log(wxContext)
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  // 检测是否传了参数 start
  if (event.isbn == undefined && event.price == undefined && event.book_count == undefined) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未传必要参数，请重试'
    var data = {}
    data.ok == false
    result.data = data
    return result
    // 检测是否传了参数 end
  }
  var countResult = await db.collection('myBook')
    .where({
      book_id: Number(event.isbn)
    })
    .count()
  if (countResult.total == 0) {
    // 新增数据
    var add_result = []
    //构建要添加的参数
    const to_add_data = {
      openid: wxContext.OPENID,
      book_id: Number(event.isbn),
      price: Number(event.price),
      status: true,
      book_count: Number(event.book_count),
      create_time: new Date(),
      update_time: new Date()
    }
    // 新增数据
    var add_result = []
    await db.collection('myBook')
      .add({
        data: to_add_data
      })
      .then(res => {
        console.log("添加我的图书成功")
        console.log(res)
        add_result = res.data
      })
    // 返回执行结果
    var result = {}
    result.errCode = 0
    result.errMsg = '圖書添加成功'
    var data = {}
    data.info = add_result
    result.data = data
    return result
  } else {
    var update_result;
    await db.collection('myBook')
      .where({
        openid: wxContext.OPENID,
        book_id: event.isbn
      }).update({
        data: {
          price: event.price,
          book_count: event.book_count
        }
      }).then(res => {
        update_result = res.data
      })
    // 返回执行结果
    var result = {}
    result.errCode = 0
    result.errMsg = '圖書更新成功'
    var data = {}
    data.info = update_result
    result.data = data
    return result
  }
}

async function removeMyBook(db, event, wxContext) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  console.log(wxContext)
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  // 检测是否传了参数 start
  if (event.isbn == undefined) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未传必要参数，请重试'
    var data = {}
    data.ok == false
    result.data = data
    return result
    // 检测是否传了参数 end
  }
  // 定義一個變量存儲更新結果
  var update_result;
  await db.collection('myBook')
    .where({
      openid: wxContext.OPENID,
      book_id: Number(event.isbn)
    })
    .update({
      status: false
    })
    .then(res => {
      update_result = res.result
    })

  var result = {}
  result.errCode = 0
  result.errMsg = '刪除圖書成功！'
  var data = {}
  data.ok == true
  result.data = data
  return result
}

async function getMyBook(db, wxContext) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  console.log(wxContext)
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  /** 查询集合中总共有多少条记录 start **/
  const countResult = await db.collection('myBook')
    .where({
      openid: wxContext.OPENID,
      status: true
    }).count()
  console.log(countResult);
  /** 查询集合中总共有多少条记录 end **/

  // 定義一個數組變量存儲查詢結果
  var ISBN = [];
  var MyBook = [];
  var Book = [];
  for (var i = 0; i < countResult.total; i++) {
    await db.collection('myBook')
      .where({
        openid: wxContext.OPENID,
        status: true
      })
      .field({
        openid: false
      })
      .get()
      .then(res => {
        console.log(res.data)
        MyBook = MyBook.concat(res.data)
      })
  }

  for (var j = 0; j < countResult.total; j++) {
    await db.collection('book')
      .where({
        id: Number(MyBook[j].book_id)
      })
      .get()
      .then(res => {
        if (res.data[0] != undefined) {
          var Booklist = [{
            title: res.data[0].word,
            tags: res.data[0].labels,
            price: MyBook[j].price,
            cover_url: res.data[0].cover_url,
            isbn: res.data[0].id,
            author: res.data[0].bookinfo.作者,
            book_count: MyBook[j].book_count,
            origin_price: res.data[0].bookinfo.定价
          }]
          Book = Booklist.concat(Book)
        }

      })
  }
  console.log(Book)
  var result = {}
  result.errCode = 0
  result.errMsg = '獲取我的圖書成功！'
  var data = {}
  data.myBook_list = Book
  result.data = data
  return result
}

async function queryMyBook(db, event, wxContext) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  console.log(wxContext)
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  // 检测是否传了参数 start
  if (event.query_word == undefined) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未传必要参数，请重试'
    var data = {}
    data.ok == false
    result.data = data
    return result
    // 检测是否传了参数 end
  }
  // 定義一個數組變量存儲查詢結果
  var MyBook = [];
  var ISBN = [];
  var Book = [];
  // 定義一個查詢指令
  const _ = db.command;
  var patt1 = new RegExp("[\\u4e00-\\u9fa5-zA-Z]", 'i');
  if (!patt1.test(event.query_word)) {
    var countResult = await db.collection('myBook').
      where({
        book_id: Number(event.query_word)
      }).count()

    for (var i = 0; i < countResult.total; i++) {
      await db.collection('myBook')
        .where(
          _.or([{
            book_id: Number(event.query_word)
          }])
        )
        .get()
        .then(res => {
          MyBook = MyBook.concat(res.data)
          ISBN = ISBN.concat(res.data[i])
          console.log(res.data[i])
        })
    }
    for (var i = 0; i < countResult.total; i++) {
      await db.collection('book')
        .where(
          _.or([{
            book_id: Number(ISBN[i])
          }])
        )
        .get()
        .then(res => {
          var Booklist = {
            isbn: ISBN[i],
            price: MyBook[i].price,
            origin_price: res.data[i].bookinfo.定价,
            title: res.data[i].word,
            author: res.data[i].bookinfo.作者,
            tags: res.data[i].labels,
            cover_url: res.data[i].cover_url,
            book_count: MyBook[i].book_count
          }
          Book = Book.concat(Booklist)
        })
    }
  } else {
    var search_id = []
    var countResult = await db.collection('book')
      .where(
        _.or([{
          word: event.query_word
        }, {
          'labels.0': event.query_word
        }, {
          'labels.1': event.query_word
        }, {
          'labels.2': event.query_word
        }, {
          'labels.3': event.query_word
        }, {
          'labels.4': event.query_word
        }, {
          'labels.5': event.query_word
        }, {
          'labels.6': event.query_word
        }, {
          'labels.7': event.query_word
        }])).count()

    console.log(countResult.total)
    for (var i = 0; i < countResult.total; i++) {
      await db.collection('book')
        .where(
          _.or([{
            word: event.query_word
          }, {
            'labels.0': event.query_word
          }, {
            'labels.1': event.query_word
          }, {
            'labels.2': event.query_word
          }, {
            'labels.3': event.query_word
          }, {
            'labels.4': event.query_word
          }, {
            'labels.5': event.query_word
          }, {
            'labels.6': event.query_word
          }, {
            'labels.7': event.query_word
          }]))
        .get()
        .then(res => {
          ISBN = ISBN.concat(res.data[i].id)
        })
    }

    for (var i = 0; i < ISBN.length; i++) {
      await db.collection('myBook')
        .where({
          book_id: ISBN[i]
        })
        .get()
        .then(res => {
          if (res.data[i] != undefined) {
            MyBook = MyBook.concat(res.data[i])
            search_id = search_id.concat(res.data[i].book_id)
          }
        })
    }
    console.log(search_id)
    for (var i = 0; i < search_id.length; i++) {
      await db.collection('book')
        .where({
          id: search_id[i]
        })
        .get()
        .then(res => {
          console.log(res.data)
          if (res.data[i] != undefined) {
            var Booklist = {
              isbn: search_id[i],
              price: MyBook[i].price,
              origin_price: res.data[i].bookinfo.定价,
              title: res.data[i].word,
              author: res.data[i].bookinfo.作者,
              tags: res.data[i].labels,
              cover_url: res.data[i].cover_url,
              book_count: MyBook[i].book_count
            }
            Book = Book.concat(Booklist)
          }
        })
    }
  }
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '查询成功！'
  var data = {}
  data.myBook_list = Book
  result.data = data
  return result
}

async function simpleMyBook(db, event, wxContext) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  console.log(wxContext)
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  // 检测是否传了参数 start
  if (event.isbn == undefined) {
    var result = {}
    result.errCode = 2
    result.errMsg = '未传必要参数，请重试'
    var data = {}
    data.ok == false
    result.data = data
    return result
    // 检测是否传了参数 end
  }
  var ISBN = [];
  var MyBook = [];
  var Book = [];
  await db.collection('myBook')
    .where({
      book_id: Number(event.isbn)
    })
    .get()
    .then(res => {
      MyBook = MyBook.concat(res.data)
      ISBN = ISBN.concat(res.data[0].book_id)
    })

  await db.collection('book')
    .where({
      id: Number(ISBN[0])
    })
    .get()
    .then(res => {
      console.log(res.data[0])
      console.log(ISBN[0])
      var Booklist = {
        title: res.data[0].word,
        tags: res.data[0].labels,
        price: MyBook[0].price,
        cover_url: res.data[0].cover_url,
        isbn: res.data[0].id,
        author: res.data[0].bookinfo.作者,
        book_count: MyBook[0].book_count,
        origin_price: res.data[0].bookinfo.定价,
        abstract: res.data[0].abstract,
        comments: res.data[0].comments,
        press: res.data[0].bookinfo.出版社,
        published_in: res.data[0].bookinfo.出版时间,
        catalog: res.data[0].catalog,
        star_count: res.data[0].rating.star_count,
        book_intro: res.data[0].book_intro,
        author_intro: res.data[0].author_intro
      }
      Book = Book.concat(Booklist)
    })
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '圖書详细获取成功'
  var data = {}
  data.bookDetail = Book
  result.data = data
  return result
}