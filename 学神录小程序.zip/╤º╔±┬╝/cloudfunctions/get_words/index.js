// 云函数入口文件
const cloud = require('wx-server-sdk')

// 初始化 cloud
cloud.init({
  // API 调用都保持和云函数当前所在环境一致
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 云函数入口函数
exports.main = async (event, context) => {
  // 实例化数据库连接
  const db = cloud.database()
  var name = event.name
  var recommend = event.type
  switch (name) {
    case "en": {
      return getEnWord(db, event)
    }
    case "hz_hot":{
      return getHotHzWord(db,event)
    }
    case "cy_hot":{
      return getHotCyWord(db,event)
    }
    case "en_hot": {
      return getHotEnWord(db, event)
    }
    case "en_total": {
      return getEnWordTotal(db, event)
    }
    case "hot": {
      return getHotWords(db)
    }
    case "total": {
      return getWordsTotal(db)
    }
    case "cy_total":{
      return getCyTotal(db)
    }
    case "recommend": {
      return getRecommendMovie(db)
    }
    default: {
      return getRecommendMovie(db)
    }
  }
}

async function getRecommendMovie(db) {
  // 每次至多查询多少个热词
  const MAX_LIMIT = 10
  // 定义一个變量接受查询结果
  var movie;
  await db.collection('movie')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      movie = res.data
    })
  // 将时间格式转换
  for (let i = 0; i < movie.length - 1; i++) {
    var date = new Date(movie[i].update_time);
    movie[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(movie[i].create_time);
    movie[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  var result = {}
  result.errCode = 0
  result.errMsg = '获取热词成功'
  var data = {}
  data.movie = movie
  result.data = data
  console.log(data)
  return result
}

async function getHotWords(db) {
  // 每次至多查询多少个热词
  const MAX_LIMIT = 3
  // 定义一个變量接受查询结果
  var word;
  var idiom;
  var food_drink;
  var healthy;
  var mathematics_chemistry;
  var finance;
  var microbe;
  var movie;
  var cast;
  var TV_Play;
  var Chinese_herbal_medicine;
  var wine_method;
  var sports;
  var famous_method;
  var Porridge_spectrum;
  var computer_network;
  var plant;
  var zoom;
  var natural_astronomy;
  var introduction;
  /** 查找热词 */
  await db.collection('idiom')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      idiom = res.data
    })

  await db.collection('word')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      word = res.data
    })

  await db.collection('food_drink')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      food_drink = res.data
    })

  await db.collection('healthy')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      healthy = res.data
    })

  await db.collection('mathematics_chemistry')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      mathematics_chemistry = res.data
    })

  await db.collection('finance')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      finance = res.data
    })


  await db.collection('movie')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      movie = res.data
    })

  await db.collection('TV_Play')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      TV_Play = res.data
    })

  // await db.collection('computer_network')
  //   .orderBy('hot', 'desc')
  //   .limit(MAX_LIMIT)
  //   .get()
  //   .then(res => {
  //     console.log('操作成功')
  //     console.log(res.data)
  //     computer_network = res.data
  //   })

  await db.collection('cast')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      cast = res.data
    })

  await db.collection('microbe')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      microbe = res.data
    })

  await db.collection('Chinese_herbal_medicine')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      Chinese_herbal_medicine = res.data
    })

  await db.collection('Porridge_spectrum')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      Porridge_spectrum = res.data
    })

  await db.collection('Folk_prescription')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      Folk_prescription = res.data
    })

  await db.collection('zoom')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      zoom = res.data
    })

  await db.collection('plant')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      plant = res.data
    })

  await db.collection('sports')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      sports = res.data
    })

  await db.collection('wine_method')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      wine_method = res.data
    })

  await db.collection('famous_method')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      famous_method = res.data
    })

  await db.collection('introduction')
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      introduction = res.data
    })

  var hot_words = idiom.concat(word, food_drink, healthy, mathematics_chemistry, finance, microbe, movie, cast, TV_Play, Chinese_herbal_medicine, wine_method, sports, famous_method, Porridge_spectrum, plant, zoom, natural_astronomy, introduction)
  var info = []
  info = hot_words.sort()
  var dictionary = []
  dictionary = info.slice(0, 53)
  var items;
  for (var j = 0; j < dictionary.length - 1; j++) {
    for (var i = 0; i < dictionary.length - 1; i++) {
      if (dictionary[i].hot != dictionary[i].hot) {
        items = dictionary[i]
        dictionary[i] = dictionary[i + 1]
        dictionary[i + 1] = items
        console.log(dictionary[i + 1])
      }
    }
  }
  console.log(dictionary)
  // 将时间格式转换
  for (let i = 0; i < dictionary.length - 1; i++) {
    var date = new Date(dictionary[i].update_time);
    dictionary[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(dictionary[i].create_time);
    dictionary[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  var result = {}
  result.errCode = 0
  result.errMsg = '获取热词成功'
  var data = {}
  data.hot_words = dictionary
  result.data = data
  console.log(data)
  return result
}

async function getWordsTotal(db) {
  // 定義一個變量存儲集合的總數
  const idiom = await db.collection('idiom').count()
  const word = await db.collection('word').count()
  const healthy = await db.collection('healthy').count()
  const food_drink = await db.collection('food_drink').count()
  const mathematics_chemistry = await db.collection('mathematics_chemistry').count()
  const finance = await db.collection('finance').count()
  const microbe = await db.collection('microbe').count()
  const plant = await db.collection('plant').count()
  const zoom = await db.collection('zoom').count()
  const natural_astronomy = await db.collection('natural_astronomy').count()
  const sports = await db.collection('sports').count()
  const wine_method = await db.collection('wine_method').count()
  const famous_method = await db.collection('famous_method').count()
  const Porridge_spectrum = await db.collection('Porridge_spectrum').count()
  const Chinese_herbal_medicine = await db.collection('Chinese_herbal_medicine').count()
  const introduction = await db.collection('introduction').count()
  const Folk_prescription = await db.collection('Folk_prescription').count()
  const cast = await db.collection('cast').count()
  const movie = await db.collection('movie').count()
  var result = {}
  result.errCode = 0
  result.errMsg = 0
  var data = {}
  data.total = ((idiom.total + word.total) + (healthy.total + food_drink.total) + (mathematics_chemistry.total + finance.total) + (plant.total + zoom.total) + (natural_astronomy.total + microbe.total) + (sports.total + introduction.total) + (wine_method.total + famous_method.total) + (Porridge_spectrum.total + Chinese_herbal_medicine.total) + (Folk_prescription.total + cast.total) + movie.total)
  result.data = data
  console.log(result)
  return result
}

async function getCyTotal(db){
   // 定義一個變量存儲集合的總數
   const idiom = await db.collection('idiom').count()
   var result = {}
   result.errCode = 0
   result.errMsg = 0
   var data = {}
   data.total = idiom.total
   result.data = data
   console.log(result)
   return result
}

async function getHotEnWord(db, event) {
  /** 检测是否传入参数 start **/
  if (event.lesson == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/
  // 每次至多查询多少个热词
  const MAX_LIMIT = 8
  // 定义一个變量接受查询结果
  var en_word;
  await db.collection('English_word')
    .where({
      lesson: Number(event.lesson)
    })
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      en_word = res.data
    })
  // 将时间格式转换
  for (let i = 0; i < en_word.length - 1; i++) {
    var date = new Date(en_word[i].update_time);
    en_word[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(en_word[i].create_time);
    en_word[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '获取热词成功'
  var data = {}
  data.hot_words = en_word
  result.data = data
  return result
}

async function getHotHzWord(db, event) {
  /** 检测是否传入参数 start **/
  if (event.type != 2) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/
  // 每次至多查询多少个热词
  const MAX_LIMIT = 6
  // 定义一个變量接受查询结果
  var word;
  await db.collection('word')
    .where({
      word_type: Number(event.type)
    })
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      word = res.data
    })
  // 将时间格式转换
  for (let i = 0; i < word.length - 1; i++) {
    var date = new Date(word[i].update_time);
    word[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(word[i].create_time);
    word[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '获取热词成功'
  var data = {}
  data.hot_words = word
  data.name = 'hz'
  result.data = data
  return result
}

async function getHotCyWord(db, event) {
  /** 检测是否传入参数 start **/
  if (event.type != 1) {
    console.log(event.type)
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数或不正确'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/
  // 每次至多查询多少个热词
  const MAX_LIMIT = 6
  // 定义一个變量接受查询结果
  var idiom;
  var type = Number(event.type)
  await db.collection('idiom')
    .where({
      word_type: type
    })
    .orderBy('hot', 'desc')
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      idiom = res.data
    })
  // 将时间格式转换
  for (let i = 0; i < idiom.length - 1; i++) {
    var date = new Date(idiom[i].update_time);
    idiom[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(idiom[i].create_time);
    idiom[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '获取热词成功'
  var data = {}
  data.hot_words = idiom
  data.name = 'cy'
  result.data = data
  return result
}

async function getEnWord(db, event) {
  /** 检测是否传入参数 start **/
  if (event.lesson == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/
  // 每次都跳过多少条
  var i = Number(event.skip)
  // 每次至多查询多少个热词
  const MAX_LIMIT = 20
  // 定义一个變量接受查询结果
  var en_word;
  await db.collection('English_word')
    .where({
      lesson: Number(event.lesson)
    })
    .limit(MAX_LIMIT)
    .skip(MAX_LIMIT * i)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      en_word = res.data
    })
  // 将时间格式转换
  for (let i = 0; i < en_word.length - 1; i++) {
    var date = new Date(en_word[i].update_time);
    en_word[i].update_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    var date = new Date(en_word[i].create_time);
    en_word[i].create_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  }
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = '获取单词列表成功'
  var data = {}
  data.word_list = en_word
  result.data = data
  return result
}

async function getEnWordTotal(db, event) {
  // 定義一個變量存儲集合的總數
  const en = await db.collection('English_word').where({ lesson: Number(event.lesson) }).count()
  var result = {}
  result.errCode = 0
  result.errMsg = 0
  var data = {}
  data.total = en.total
  result.data = data
  console.log(result)
  return result
}