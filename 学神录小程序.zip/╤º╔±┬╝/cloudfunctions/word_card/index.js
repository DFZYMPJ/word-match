// 云函数入口文件
const cloud = require('wx-server-sdk')

//云开发初始化
cloud.init();

//将云开发数据库能力声明给db
const db = cloud.database();

//将云开发数据库command能力声明给 _
const _ = db.command;

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  switch (event.type) {
    case "init": {
      return initWordCard(db, event, wxContext)
    }
    case "add": {
      return addWordCard(db, event, wxContext, _)
    }
    case "remove": {
      return removeWordCard(db, event, wxContext, _)
    }
    case "get": {
      return getWordCard(db, event, wxContext)
    }
    case "find": {
      return findWordCard(db, event, wxContext, _)
    }
    default: {
      return
    }
  }
}
/**
 * 云函数：初始化单词卡片
 * 用途：根据用户的唯一openid构建数据库文档，用于存储用户的信息；每次调用时都要返回存储的信息。
 */

async function initWordCard(db, event, wxContext) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  /** 检测是否传入参数 start **/
  if (event.id == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/

  //声明一个result，用于承载函数执行结果用于返回
  var result = {};
  // 返回执行结果的数据
  var data = {};
  try {

    //利用数据库where查找，数据集中openid为用户所属的文档
    const userdata = (await db.collection('wordCard').where({
      openid: wxContext.OPENID
    }).get()).data;

    //如果length不等于0，则证明存在用户所属文档
    if (userdata.length != 0) {

      //将用户的识别列表读取出来
      data.list = userdata[0].list;
      //将文档id取出，用于小程序端上传图片时的文件夹命名。由于安全性，不可以将openid传给小程序端
      data.id = userdata[0]._id;
      //正常标志errCode=0
      result.errCode = 0;
      // 返回执行结果的数据
      result.data = data
    }
    //如果length等于0，则没有用户文档需要创建
    else {

      //使用数据库add增加，根据data传入的JSON对象进行构建，返回的为构建的信息，包含文档id
      let result = await db.collection('wordCard').add({
        data: {
          openid: wxContext.OPENID,
          id: event.id,
          list: [],
          create_time: new Date(),
          update_time: new Date()
        }
      });

      //将文档id取出
      data.id = result._id;
      //新建则识别列表为空
      data.list = [];
      //正常标志errCode=0
      result.errCode = 0;
      // 结果的数据data
      result.data = data
    }
  } catch (e) {
    //当发生错误时，如解构FileID等，将执行此代码段，errCode=-1为异常
    console.log(e);
    result.errCode = -1;
    result.errMsg = e;
  }
  //返回result给前端
  return result;
}
/**
 * 云函数：添加单词的卡片
 * 用途：将单词图片信息上传云数据库进行保存。
 */
async function addWordCard(db, event, wxContext, _) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  /** 检测是否传入参数 start **/
  if (event.cover == undefined || event.translation == undefined || event.english == undefined || event.lesson == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/

  //声明一个result，用于承载函数执行结果用于返回
  var result = {};
  //声明一个data,用于承载数据库执行结果用于返回
  var data = {};

  // 构建新增的数据
  var wordCard = {
    // 卡片的英文单词
    english: event.english,
    // 单词的解释
    translation: event.translation,
    // 单词对应的图片
    cover: event.cover,
    // 课程id
    lesson: event.lesson
  }
  console.log("要新增的数据")
  console.log(wordCard)

  try {
    await db.collection('wordCard').where({
      openid: wxContext.OPENID
    }).update({
      data: {
        list: _.push([wordCard]),
        update_time: new Data()
      }
    }).then(res => {
      console.log('新增成功')
      // 新增结果
      data.wordcard_id = res._id
    });
    // 返回执行结果
    result.data = data
    result.errMsg = event.english + '卡片创建成功'
    result.errCode = 0;

  } catch (e) {
    //当发生错误时，如解构FileID等，将执行此代码段，errCode=-1为异常
    console.log(e);
    // 返回执行结果
    result.errCode = -1;
    result.errMsg = e;
  }
  //返回result给前端
  return result;
}
/**
 * 云函数: 删除单词卡片
 * 用途：根据图片地址，将云数据库保存的识别图片进行删除。
 */
async function removeWordCard(db, event, wxContext, _) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  /** 检测是否传入参数 start **/
  if (event.cover == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/

  //声明一个result，用于承载函数执行结果用于返回
  var result = {};
  // 声明一个data，用于承载数据库执行结果用于返回
  var data = {}
  try {
    /*【开始】=====================【代码实战位置C-3】=====================【开始】*/

    //利用数据库where查找，数据集中openid为用户所属的文档，然后使用update进行更新操作
    const userdata = await db.collection('wordCard').where({
      openid: wxContext.OPENID
    }).update({
      data: {
        //_.pull为command能力，含义为将数组中src为event.img的元素删除
        list: _.pull({
          cover: event.cover
        })
      }
    }).then(res => {
      console.log('删除单词卡片成功')
      data.wordcard_id = res._id
    });
    //使用云存储能力，根据列表的fileid地址删除文件
    await cloud.deleteFile({
      fileList: [event.cover]
    })

    /*【结束】=====================【代码实战位置C-3】=====================【结束】*/
    // 返回执行结果
    result.data = data
    //在处理完全后，返回自定义的errCode码，表示一定的逻辑含义；在这里errCode=0为正常成功
    result.errCode = 0;
    result.errMsg = '卡片删除成功'
  } catch (e) {
    //当发生错误时，如解构FileID等，将执行此代码段，errCode=-1为异常
    console.log(e);
    result.errCode = -1;
    result.errMsg = e;
  }
  //返回result给前端
  return result;
}
/**
 * 云函数: 获取单词卡片
 * 用途：根据用户的唯一openid查询数据库文档
 */
async function getWordCard(db, event, wxContext, _) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/

  /** 检测是否传入参数 start **/
  if (event.lesson == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/

  //声明一个result，用于承载函数执行结果用于返回
  var result = {};
  // 声明一个data，用于承载数据库执行结果用于返回
  var data = {}

  try {
    /*【开始】=====================【代码实战位置C-2】=====================【开始】*/
    //利用数据库where查找，数据集中openid为用户所属的文档
    const userdata = (await db.collection('wordCard').where({
      openid: wxContext.OPENID
    }).get()).data;
    //如果length不等于0，则证明存在用户所属文档
    if (userdata.length != 0) {
      // 声明一个数组
      var wordcard = []
      for (var i = 0; i < userdata[0].list.length; i++) {
        if (userdata[0].list[i].lesson == event.lesson) {
          wordcard = wordcard.concat(userdata[0].list[i])
        }
      }
      //将用户的单词卡片列表读取出来
      data.wordcard = wordcard;
      //将文档id取出，用于小程序端上传图片时的文件夹命名。由于安全性，不可以将openid传给小程序端
      data.wordcard_id = userdata[0]._id;
    }
    //如果length等于0，则没有用户文档需要创建
    else {
      //将用户的识别列表读取出来
      data.wordcard = [];
      //将文档id取出，用于小程序端上传图片时的文件夹命名。由于安全性，不可以将openid传给小程序端
      data.wordcard_id = userdata[0]._id;
    }
    /*【结束】=====================【代码实战位置C-2】=====================【结束】*/
    result.data = data
    //在处理完全后，返回自定义的errCode码，表示一定的逻辑含义；在这里errCode=0为正常成功
    result.errCode = 0;
    result.errMsg = '获取单词卡片成功'
  } catch (e) {
    //当发生错误时，如解构FileID等，将执行此代码段，errCode=-1为异常
    console.log(e);
    result.errCode = -1;
    result.errMsg = e;
  }
  //返回result给前端
  return result;
}
/**
 * 云函数: 搜索相应单词卡片
 * 用途：根据用户的唯一openid查询数据库文档
 */
async function findWordCard(db, event, wxContext, _) {
  /** 检测用户的openid start*/
  console.log("获取用户微信信息成功")
  if (wxContext.OPENID == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 1
    result.errMsg = '未正确获取用户信息的openid,请退出小程序重试'
    var data = {}
    result.data = data
    return result
  }
  /** 检测用户的openid end*/
  /** 检测是否传入参数 start **/
  if (event.lesson == undefined || event.query_word == undefined) {
    // 返回执行结果
    var result = {}
    result.errCode = 2
    result.errMsg = '未传入必要参数'
    var data = {}
    result.data = data
    return result
  }
  /** 检测是否传入参数 end **/
  // 定义一个s数组接收返回查询结果
  var items = []
  // 每次至多查询多少个单词
  const MAX_LIMIT = 10

  var query_word = event.query_word.toString()
  await db.collection('wordCard')
    .where(
      _.or([{
        english: query_word.toString()
      }, {
        "translation.0.chinese": query_word.toString()
      }, {
        "translation.1.chinese": query_word.toString()
      }, {
        "translation.2.chinese": query_word.toString()
      }, {
        "translation.3.chinese": query_word.toString()
      }])
    )
    .limit(MAX_LIMIT)
    .get()
    .then(res => {
      console.log('操作成功')
      console.log(res.data)
      items = res.data
    })
  // 返回执行结果
  var result = {}
  result.errCode = 0
  result.errMsg = "查找单词卡片成功"
  var data = {}
  data.wordcard = items
  result.data = data
  return result
}